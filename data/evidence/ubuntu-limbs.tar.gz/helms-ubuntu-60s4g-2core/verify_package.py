"""Read-only verification of all shipped bytes, input identities and profile."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1024**2),b''):h.update(data)
    return h.hexdigest()
def read(path):return json.loads(path.read_bytes())
def checked(relative):
    relative=Path(relative)
    if relative.is_absolute() or '..' in relative.parts:raise ValueError('Invalid inventory path')
    path=(ROOT/relative).resolve()
    if not path.is_relative_to(ROOT):raise ValueError('Inventory path escapes package')
    return path
def main():
    inventory=read(ROOT/'PACKAGE_FILES_SHA256.json')
    for relative,item in inventory['files'].items():
        path=checked(relative)
        if not path.is_file() or path.stat().st_size!=item['bytes'] or sha(path)!=item['sha256']:
            raise ValueError('Package file is missing or changed: '+relative)
    lock=read(ROOT/'SOURCE_LOCK.json');effective=read(ROOT/'effective_inputs.json')
    for relative,item in lock['files'].items():
        if sha(checked('artifact/'+relative))!=item['sha256']:raise ValueError('Solver source mismatch: '+relative)
    original={row['case_id']:row for row in lock['inputs']}
    if len(original)!=2260 or len(effective)!=2260 or {r['case_id'] for r in effective}!=set(original):
        raise ValueError('Unexpected/duplicate input population')
    if Counter(row['benchmark'] for row in effective)!=Counter({'SMTLIB':2139,'RandInst':100,'SpecInst':21}):
        raise ValueError('Unexpected benchmark counts')
    for row in original.values():
        if sha(checked(row['input_path']))!=row['input_sha256']:raise ValueError('Original input mismatch: '+row['case_id'])
    for row in effective:
        if row.get('original_snapshot_sha256',row['input_sha256'])!=original[row['case_id']]['input_sha256']:
            raise ValueError('Input adapter identity mismatch: '+row['case_id'])
        if sha(checked(row['input_path']))!=row['input_sha256']:raise ValueError('Effective input mismatch: '+row['case_id'])
    if sha(ROOT/'artifact/solvers/paper solvers/HELMS.wl')!='301bd11659be3a07a16e130514eca3a71060619c3808f1ab3873e73ad08b5215':
        raise ValueError('Frozen current HELMS source differs')
    helms=read(ROOT/'artifact/config/helms_config.json')['worker']
    variants=read(ROOT/'artifact/config/variants_config.json')['worker']
    if helms!=variants:raise ValueError('Variant configuration must match current HELMS')
    if read(ROOT/'artifact/config/2dls_config.json')['worker']['standalone_restarts']!=64:
        raise ValueError('Unexpected standalone 2D-LS restart configuration')
    if read(ROOT/'artifact/config/lswl_config.json')['worker']['ls_wl_restarts']!=64:
        raise ValueError('Unexpected standalone LS-WL restart configuration')
    if any(b'\r' in (ROOT/name).read_bytes() for name in ['start.sh','run.sh','status.sh','stop.sh','install.sh']):
        raise ValueError('Shell scripts must retain LF line endings')
    print(json.dumps({'package_files_verified':len(inventory['files']),'source_files_verified':len(lock['files']),
        'inputs_verified':2260,'default_jobs':22600,'seconds_per_job':60,'GiB_per_job':4,
        'max_physical_core_workers':2,'result':'passed'},indent=2))
if __name__=='__main__':
    try:main()
    except (OSError,ValueError,KeyError) as error:
        print('VERIFICATION FAILED:',error,file=sys.stderr);raise SystemExit(2)
