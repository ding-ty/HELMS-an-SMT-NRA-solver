"""Linux-only solver-tree supervisor; stays outside the task's 4 GiB cgroup.

The coordinator invokes this file. It moves the forked child into the already
configured cgroup BEFORE loading Mathematica. Descendants inherit the cap.
"""
from __future__ import annotations
import ctypes
import json
import os
from pathlib import Path
import pwd
import resource
import signal
import sys
import time


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.rename(path)


def main():
    request = json.loads(Path(sys.argv[1]).read_bytes())
    cg = Path(request["cgroup"])
    folder = Path(request["attempt_path"])

    def cleanup(*_):
        try:
            (cg / "cgroup.kill").write_text("1")
        except FileNotFoundError:
            pass
        raise SystemExit(143)

    signal.signal(signal.SIGTERM, cleanup)
    signal.signal(signal.SIGINT, cleanup)
    parent = os.getppid()
    if ctypes.CDLL(None).prctl(1, signal.SIGTERM, 0, 0, 0) != 0:
        raise OSError("PR_SET_PDEATHSIG failed")
    if os.getppid() != parent:
        cleanup()
    pid = os.fork()
    if pid == 0:
        try:
            os.setsid()
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            (cg / "cgroup.procs").write_text(str(os.getpid()))
            os.sched_setaffinity(0, {request["cpu"]})
            for descriptor, name in ((1, "stdout.log"), (2, "stderr.log")):
                fd = os.open(folder / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
                os.dup2(fd, descriptor)
                os.close(fd)
            environment = os.environ.copy()
            for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                        "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
                environment[key] = "1"
            uid, gid = request["run_uid"], request["run_gid"]
            account = pwd.getpwuid(uid)
            environment.update(HOME=account.pw_dir, USER=account.pw_name,
                               LOGNAME=account.pw_name)
            # Root only configures cgroups. The licensed solver runs as the
            # invoking account, using that account's ordinary Wolfram license.
            if os.geteuid() == 0 and uid != 0:
                os.initgroups(account.pw_name, gid)
                os.setgid(gid)
                os.setuid(uid)
            os.chdir(request["cwd"])
            atomic(folder / "process_started.json", {
                "pid": os.getpid(), "start_monotonic_ns": time.monotonic_ns(),
                "cpu": request["cpu"], "uid": os.getuid(), "gid": os.getgid(),
                "cgroup": str(cg)})
            os.execve(request["command"][0], request["command"], environment)
        except BaseException as error:
            os.write(2, ("solver exec/bootstrap failure: " + str(error) + "\n").encode())
            os._exit(125)
    _, status, usage = os.wait4(pid, 0)
    atomic(folder / "process_exit.json", {
        "returncode": os.waitstatus_to_exitcode(status),
        "finish_monotonic_ns": time.monotonic_ns(),
        "user_cpu_seconds": usage.ru_utime, "system_cpu_seconds": usage.ru_stime,
        "max_rss_kib": usage.ru_maxrss})


if __name__ == "__main__":
    main()
