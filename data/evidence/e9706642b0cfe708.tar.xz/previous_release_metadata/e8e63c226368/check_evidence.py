#!/usr/bin/env python3
"""Verify the consolidated evidence payload and recompute its result summary."""
import argparse
from collections import Counter
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile


def inspect(path):
    seen, casefold, identities, saved = set(), set(), {}, {}
    wanted = {'CHECKSUMS.json', 'SOURCE_MAP.json', 'INDEX.json', 'results/summary.csv',
              *('results/' + b + '/results.csv' for b in ('SMTLIB','RandInst','SpecInst'))}
    with tarfile.open(path, 'r|gz') as archive:
        for member in archive:
            name = member.name
            p = PurePosixPath(name)
            if (not member.isfile() or p.is_absolute() or '..' in p.parts or
                    '\\' in name or ':' in name or p.as_posix()!=name or
                    name in seen or name.casefold() in casefold):
                raise ValueError('Unsafe, duplicate or non-file member: ' + name)
            seen.add(name);casefold.add(name.casefold())
            digest=hashlib.sha256(); size=0; chunks=[]
            stream=archive.extractfile(member)
            for chunk in iter(lambda: stream.read(1024*1024), b''):
                digest.update(chunk);size+=len(chunk)
                if name in wanted:chunks.append(chunk)
            if size!=member.size:raise ValueError('Truncated member: '+name)
            identities[name]={'bytes':size,'sha256':digest.hexdigest()}
            if name in wanted:saved[name]=b''.join(chunks)
    checks=json.loads(saved['CHECKSUMS.json'])['files']
    expected={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in checks}
    if len(expected)!=len(checks):raise ValueError('Duplicate checksum entry')
    actual={n:r for n,r in identities.items() if n!='CHECKSUMS.json'}
    if actual!=expected:raise ValueError('Payload inventory/hash mismatch')
    source=json.loads(saved['SOURCE_MAP.json'])
    copies=0
    for origin in source['archives']:
        if origin['file_count']!=len(origin['files']):raise ValueError('Source inventory count mismatch')
        for row in origin['files']:
            name=origin['prefix']+'/'+row['member']
            if identities.get(name)!={'bytes':row['bytes'],'sha256':row['sha256']}:
                raise ValueError('Original evidence file mismatch: '+name)
            copies+=1
    expanded=0
    for origin in source['expansions']:
        for row in origin['files']:
            name=origin['prefix']+'/'+row['member']
            if identities.get(name)!={'bytes':row['bytes'],'sha256':row['sha256']}:
                raise ValueError('Expanded payload mismatch: '+name)
            expanded+=1
    summary=list(csv.DictReader(io.StringIO(saved['results/summary.csv'].decode('utf-8-sig'))))
    total=Counter();pairs=set()
    for benchmark in ('SMTLIB','RandInst','SpecInst'):
        rows=list(csv.DictReader(io.StringIO(saved['results/'+benchmark+'/results.csv'].decode('utf-8-sig'))))
        for row in rows:
            key=row['case_id'],row['solver']
            if key in pairs:raise ValueError('Duplicate result pair')
            pairs.add(key)
            if row['status']=='not_applicable':continue
            total['applicable']+=1;total[row['status']]+=1
            total['solved']+=row['solved']=='true'
            if row['solved']=='true' and row['status']!=row['expected_status']:
                raise ValueError('Answer/benchmark label conflict')
        for s in [r for r in summary if r['benchmark']==benchmark]:
            rr=[r for r in rows if r['solver']==s['solver'] and r['status']!='not_applicable']
            counts={'sat_cases':sum(r['expected_status']=='sat' for r in rr),
                    'unsat_cases':sum(r['expected_status']=='unsat' for r in rr),
                    'recorded':len(rr),'applicable':len(rr),
                    'sat_solved':sum(r['solved']=='true' and r['status']=='sat' for r in rr),
                    'unsat_solved':sum(r['solved']=='true' and r['status']=='unsat' for r in rr),
                    'total_solved':sum(r['solved']=='true' for r in rr),
                    **{k:sum(r['status']==k for r in rr) for k in ('unknown','timeout','error')},
                    'memout':sum(r['failure_kind']=='resource_exhausted' for r in rr),'missing':0}
            if any(int(s[k])!=v for k,v in counts.items()):raise ValueError('Summary mismatch: '+benchmark+'/'+s['solver'])
    index=json.loads(saved['INDEX.json'])
    for series in index['series']:
        for field in ('results','raw_results','record_index','run_plan','source_csv','configuration_record'):
            if series.get(field) and series[field] not in identities:
                raise ValueError('Index target absent: '+series[field])
    return {'passed':True,'payload_files_verified':len(actual),'original_evidence_files_verified':copies,
            'expanded_files_verified':expanded,'summary_rows_recomputed':len(summary),'counts':dict(total),
            'scope':'File integrity, evidence mapping and numerical aggregation. This check does not rerun solvers or independently certify answers, timings or execution history.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive',type=Path,nargs='?',default=Path(__file__).with_name('evidence.tar.gz'))
    args=parser.parse_args()
    print(json.dumps(inspect(args.archive),indent=2))


if __name__=='__main__':
    main()
