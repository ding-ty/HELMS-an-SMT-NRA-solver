# Experimental evidence

This is the single evidence archive for all experiment data currently published
in this artifact: HELMS, 2D-LS, V1-V5, LS-WL and LiMbS on SMTLIB, RandInst and
SpecInst. SOTA and standalone OpenCAD observations are outside this archive.

Start with `INDEX.json`: each of its 27 solver/benchmark entries links the exact
published CSV to its detailed records, plan or source CSV. `results/summary.csv`
contains the counts; the three per-instance CSVs are under `results/`.

`records/` preserves every original evidence file byte-for-byte under separate
directory roots. Original embedded checksum inventories and record indices remain
unchanged. Use INDEX.json for the selected series and SOURCE_MAP.json for each
original bundle/member location. This includes
additional preserved attempts/observations not selected in the current tables.
They must not be selected by best outcome or fastest time.

`expanded/` additionally exposes the nested compressed records from `records/`
as directly readable files. No further archive extraction is required to inspect
those records. The embedded compressed originals are retained for byte checks.
`SOURCE_MAP.json` records original container SHA-256, every original member and
the additional decompression/extraction mappings. Outer packaging has changed;
the original observations, times, answers, models and logs have not.

`CHECKSUMS.json` covers every payload file except itself. Run the standard-library
checker supplied beside the archive, without extracting the archive:

    python check_evidence.py evidence.tar.gz

Or extract this archive and run its identical `check_evidence.py` against the
original archive path. The checker verifies payload hashes, complete source-member
mapping and summary counts. The independent final publication review also checks
the expanded bytes against decompression of the retained original containers.
Checksums detect byte changes; they do not independently prove real execution,
solver correctness or the authenticity of reported timings.

`benchmarks/` contains the exact published input manifest and unpacked input
files. `code/` contains the supplied solver, component, configuration and runner
files. Its `config/measurement_identity.json` maps supplied code to measured
implementations, including reversible namespace-only adapters. This packaging
does not change solver rules or recorded configurations. LS-WL observations
remain the eight-round measurements; no LS-WL64 results have been added.

LiMbS is supplied at upstream commit 7e1457b528c848343c6997bafb019ed4b39af413.
Its RandInst/SpecInst measurements identify a different library with three endpoint
corrections; the exact library identity of the retained SMTLIB CSV is unavailable.
These limits are preserved in the identity mapping; observations are not relabeled.

For a small exact-answer check, open the SpecInst 2D-LS entry in INDEX.json and
find SpecInst/C_3_64 in its record index. Compare the CSV and raw final record,
follow the request and worker-result paths, and substitute that worker's exact
model into the original input. Inspect the full CNF, not just a verification flag.
UNSAT without a separately checkable certificate requires an independent rerun
or cross-check. UNKNOWN, TIMEOUT and MEMOUT are unsolved; environment interruptions
without a final answer are not inferred to be solver TIMEOUT or MEMOUT.
