#!/usr/bin/env python3
"""Produce checked CDF/scatter CSVs; optionally render them with matplotlib."""
from __future__ import annotations

import argparse
import collections
import csv
import json
from pathlib import Path
import sys
import tempfile
from typing import Any

try:
    from .run_experiments import read_json, sha256_file, write_json
    from .summarize_results import summarize, write_csv
except ImportError:
    from run_experiments import read_json, sha256_file, write_json
    from summarize_results import summarize, write_csv


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def is_solved(row: dict[str, str]) -> bool:
    return row["count_as_solved"].lower() == "true"


def make_cdf_rows(per_case: list[dict[str, str]], summary: dict[str, Any],
                  solvers: list[str], timeout: float, scope: str) -> list[dict[str, Any]]:
    """The final point is the independently checked corresponding summary count."""
    expected_by_solver = {row["solver"]: row for row in summary["by_solver"]}
    result = []
    for solver in solvers:
        values = [float(row["cdf_seconds"]) for row in per_case
                  if row["solver"] == solver and is_solved(row)
                  and (scope == "all" or row["actual_status"] == scope)]
        expected = expected_by_solver[solver]["solved" if scope == "all" else scope]
        if len(values) != expected:
            raise ValueError(f"CDF {scope}/{solver}: {len(values)} successful times != summary count {expected}")
        if any(value < 0 or value > timeout for value in values):
            raise ValueError(f"CDF {scope}/{solver}: successful runtime outside the solver timeout")
        counts = collections.Counter(values)
        count = 0
        points = [(0.0, 0)]
        for seconds, multiplicity in sorted(counts.items()):
            count += multiplicity
            points.append((seconds, count))
        if points[-1][0] != timeout:
            points.append((timeout, count))
        if points[-1][1] != expected:
            raise ValueError(f"CDF {scope}/{solver}: endpoint does not equal the summary count")
        result.extend({"fingerprint": summary["fingerprint"], "scope": scope,
                       "solver": solver, "time_seconds": seconds, "solved_count": solved_count,
                       "is_endpoint": index == len(points) - 1}
                      for index, (seconds, solved_count) in enumerate(points))
    return result


def make_scatter_rows(per_case: list[dict[str, str]], solvers: list[str], timeout: float
                      ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    # Preserve source identities: the source-derived LS-WL baseline takes
    # priority over legacy LS and the separate reconstructed 1D control.
    baseline = next((name for name in ("LS-WL", "LS", "1D-control") if name in solvers), "LS-WL")
    pair = ("2D-LS", baseline)
    if any(solver not in solvers for solver in pair):
        return [], {"status": "unavailable", "reason": "the same run plan must contain 2D-LS and LS-WL, LS, or 1D-control",
                    "pair": list(pair), "included_cases": 0}
    cases: dict[str, dict[str, dict[str, str]]] = collections.defaultdict(dict)
    for row in per_case:
        cases[row["case_id"]][row["solver"]] = row
    output = []
    excluded = collections.Counter()
    for case_id, records in cases.items():
        if any(row["effective_status"] in {"conflict", "invalid"} for row in records.values()):
            excluded["conflict_or_invalid"] += 1
            continue
        x, y = records[pair[0]], records[pair[1]]
        if any(row["effective_status"] == "not_applicable" for row in (x, y)):
            excluded["not_applicable"] += 1
            continue
        expected = x["expected_status"]
        if expected == "unsat":
            excluded["unsat"] += 1
            continue
        known_sat = expected == "sat" or any(is_solved(row) and row["actual_status"] == "sat"
                                               for row in records.values())
        if not known_sat:
            excluded["unknown_truth"] += 1
            continue
        x_solved = is_solved(x) and x["actual_status"] == "sat"
        y_solved = is_solved(y) and y["actual_status"] == "sat"
        output.append({
            "fingerprint": x["fingerprint"], "case_id": case_id,
            "benchmark": x["benchmark"], "family": x["family"], "expected_status": expected,
            "x_solver": pair[0], "y_solver": pair[1],
            "x_seconds": float(x["solve_seconds"]) if x_solved else timeout,
            "y_seconds": float(y["solve_seconds"]) if y_solved else timeout,
            "x_solved": x_solved, "y_solved": y_solved,
            "x_actual_status": x["actual_status"], "y_actual_status": y["actual_status"],
            "x_effective_status": x["effective_status"], "y_effective_status": y["effective_status"],
            "x_boundary": not x_solved, "y_boundary": not y_solved,
            "point_kind": "both_solved" if x_solved and y_solved else "x_unsolved" if not x_solved and y_solved
                          else "y_unsolved" if x_solved and not y_solved else "both_unsolved",
            "timeout_seconds": timeout,
        })
    return output, {"status": "available", "pair": list(pair), "included_cases": len(output),
                    "baseline_profile": {"LS-WL": "source_derived_wolfram_ls",
                                         "1D-control": "same_source_control",
                                         "LS": "external_or_legacy_LS_label"}[pair[1]],
                    "excluded_cases": dict(excluded),
                    "unsolved_policy": "unknown,error,timeout,not_run are placed at the timeout boundary and explicitly marked"}


def render_plots(output_dir: Path, cdfs: dict[str, list[dict[str, Any]]],
                 scatter: list[dict[str, Any]], solvers: list[str], timeout: float) -> list[str]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise ValueError("--render requires matplotlib; checked data CSVs have already been written") from exc
    outputs = []
    for scope, rows in cdfs.items():
        figure, axis = plt.subplots(figsize=(6.4, 4.2))
        for solver in solvers:
            points = [row for row in rows if row["solver"] == solver]
            axis.step([row["time_seconds"] for row in points],
                      [row["solved_count"] for row in points], where="post", label=solver)
        axis.set(xlabel="Solver time (seconds; startup excluded)", ylabel="Number of solved instances",
                 title=f"{scope.upper()} instances", xlim=(0, timeout))
        axis.set_xscale("symlog", linthresh=1e-3)
        axis.grid(alpha=0.25)
        axis.legend()
        figure.tight_layout()
        name = f"cdf_{scope}.pdf"
        figure.savefig(output_dir / name, metadata={"CreationDate": None, "ModDate": None})
        plt.close(figure)
        outputs.append(name)
    if scatter:
        figure, axis = plt.subplots(figsize=(5.3, 5.0))
        x_solver, y_solver = scatter[0]["x_solver"], scatter[0]["y_solver"]
        styles = {"both_solved": ("o", "Both solved"), "x_unsolved": (">", f"{x_solver} unsolved"),
                  "y_unsolved": ("^", f"{y_solver} unsolved"), "both_unsolved": ("x", "Both unsolved")}
        for kind, (marker, label) in styles.items():
            points = [row for row in scatter if row["point_kind"] == kind]
            if points:
                axis.scatter([row["x_seconds"] for row in points], [row["y_seconds"] for row in points],
                             marker=marker, s=22, alpha=0.55, label=label)
        axis.plot([0, timeout], [0, timeout], color="black", linewidth=0.7)
        axis.set(xlabel=f"{x_solver} solver time (seconds)", ylabel=f"{y_solver} solver time (seconds)",
                 xlim=(0, timeout * 1.05), ylim=(0, timeout * 1.05),
                 title=f"SAT instances; unsolved at {timeout:g}-second boundary")
        axis.set_xscale("symlog", linthresh=1e-3)
        axis.set_yscale("symlog", linthresh=1e-3)
        axis.grid(alpha=0.25)
        axis.legend()
        figure.tight_layout()
        name = "ls_2dls_scatter.pdf"
        figure.savefig(output_dir / name, metadata={"CreationDate": None, "ModDate": None})
        plt.close(figure)
        outputs.append(name)
    return outputs


def prepare_plot_data(results_path: Path, summary_dir: Path, output_dir: Path,
                      plan_path: Path | None = None, render: bool = False) -> dict[str, Any]:
    results_path = results_path.resolve()
    plan_path = (plan_path or results_path.parent / "run_plan.json").resolve()
    saved_summary = read_json(summary_dir / "summary.json")
    if saved_summary.get("results_sha256") != sha256_file(results_path):
        raise ValueError("summary does not describe this exact results.jsonl; regenerate the summary first")
    if saved_summary.get("run_plan_sha256") != sha256_file(plan_path):
        raise ValueError("summary does not describe this exact run_plan.json; regenerate the summary first")
    # Revalidate the raw records and derive rows afresh. A hand-edited per_case
    # CSV or a stale summary must never silently change a figure.
    with tempfile.TemporaryDirectory(prefix="helms-plot-validation-") as temporary:
        verification_dir = Path(temporary)
        summary = summarize(results_path, plan_path, verification_dir)
        if summary != saved_summary:
            raise ValueError("saved summary differs from a fresh validation of the raw records")
        per_case = load_csv(verification_dir / "per_case.csv")
    plan = read_json(plan_path)
    if summary["fingerprint"] != plan["fingerprint"]:
        raise ValueError("summary and run plan fingerprints differ")
    timeout = float(plan["timeout_seconds"])
    solvers = plan["solvers"]
    cdfs = {scope: make_cdf_rows(per_case, summary, solvers, timeout, scope)
            for scope in ("all", "sat", "unsat")}
    scatter, scatter_report = make_scatter_rows(per_case, solvers, timeout)
    output_dir.mkdir(parents=True, exist_ok=True)
    for scope, rows in cdfs.items():
        write_csv(output_dir / f"cdf_{scope}.csv", rows,
                  ["fingerprint", "scope", "solver", "time_seconds", "solved_count", "is_endpoint"])
    scatter_fields = ["fingerprint", "case_id", "benchmark", "family", "expected_status", "x_solver", "y_solver",
                      "x_seconds", "y_seconds", "x_solved", "y_solved", "x_actual_status", "y_actual_status",
                      "x_effective_status", "y_effective_status", "x_boundary", "y_boundary", "point_kind", "timeout_seconds"]
    write_csv(output_dir / "ls_2dls_scatter.csv", scatter, scatter_fields)
    endpoints = {scope: {row["solver"]: row["solved_count"] for row in rows if row["is_endpoint"]}
                 for scope, rows in cdfs.items()}
    report = {"schema_version": 1, "fingerprint": summary["fingerprint"],
              "results_sha256": summary["results_sha256"], "run_plan_sha256": summary["run_plan_sha256"],
              "plotter_sha256": sha256_file(Path(__file__)),
              "case_policy": summary.get("case_policy", "legacy-all"),
              "eligible_jobs": summary["planned_jobs"],
              "not_applicable_pairs": summary.get("not_applicable", 0),
              "eligible_cases_by_solver": {row["solver"]: row["instances"] for row in summary["by_solver"]},
              "source_violations": summary["violations"], "cdf_endpoints": endpoints,
              "cdf_endpoint_check": "passed", "scatter": scatter_report,
              "solver_labels": solvers, "rendered_files": []}
    write_json(output_dir / "plot_validation.json", report)
    if render:
        report["rendered_files"] = render_plots(output_dir, cdfs, scatter, solvers, timeout)
        write_json(output_dir / "plot_validation.json", report)
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", required=True, type=Path)
    parser.add_argument("--summary-dir", required=True, type=Path)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--render", action="store_true", help="Optional matplotlib PDF rendering")
    args = parser.parse_args(argv)
    try:
        report = prepare_plot_data(args.results, args.summary_dir, args.output_dir, args.plan, args.render)
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 1 if report["source_violations"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
