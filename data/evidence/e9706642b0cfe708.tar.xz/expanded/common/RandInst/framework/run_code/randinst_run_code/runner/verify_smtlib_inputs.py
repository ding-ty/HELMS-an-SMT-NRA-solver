"""Verify the fixed SMTLIB-only manifests and unchanged exact input bytes."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def rows(name):
    return [json.loads(line) for line in (ROOT / 'benchmarks' / name).read_text(encoding='utf-8').splitlines() if line.strip()]


def verify():
    source = {row['case_id']: row for row in rows('experiment_all.jsonl') if row['benchmark_group'] == 'SMTLIB'}
    chosen = rows('experiment_smtlib_all.jsonl')
    by_id = {row['case_id']: row for row in chosen}
    if len(chosen) != 2050 or len(by_id) != 2050 or by_id != source:
        raise ValueError('SMTLIB selection differs from the original fixed snapshot')
    status_counts = Counter(row['expected_status'] for row in chosen)
    family_counts = Counter(row['family'] for row in chosen)
    if status_counts != {'sat': 1503, 'unsat': 547} or family_counts != {'hong':20, 'meti-tarski':2030}:
        raise ValueError('SMTLIB status/family counts differ from the fixed snapshot')
    for status in ('sat','unsat'):
        partition = rows(f'experiment_smtlib_{status}.jsonl')
        if len(partition) != status_counts[status] or {row['case_id']:row for row in partition} != {
                key:row for key,row in by_id.items() if row['expected_status']==status}:
            raise ValueError(f'SMTLIB {status} partition is incorrect')
    for row in chosen:
        path = (ROOT / row['input_path']).resolve()
        if (not path.is_relative_to((ROOT / 'benchmarks/inputs/SMTLIB').resolve())
                or hashlib.sha256(path.read_bytes()).hexdigest() != row['input_sha256']):
            raise ValueError('SMTLIB input path or SHA256 mismatch: '+row['case_id'])
        if set(json.loads(path.read_text(encoding='utf-8'))) != {'variables','polynomials','clauses'}:
            raise ValueError('SMTLIB formula does not have the exact input schema')
    return {'benchmark':'SMTLIB','instances':2050,'statuses':dict(status_counts),
            'families':dict(family_counts),'all_input_hashes_verified':True,
            'status_evidence':'status labels from the preserved SMT-LIB source snapshot'}


if __name__ == '__main__':
    print(json.dumps(verify(),ensure_ascii=False,indent=2))
