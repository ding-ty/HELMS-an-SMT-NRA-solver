"""Verify distributed input hashes, SAT/UNSAT partitions and exact SAT models."""
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read_rows(name):
    return [json.loads(line) for line in (ROOT / "benchmarks" / name).read_text(encoding="utf-8").splitlines() if line.strip()]


def value(node, model):
    op = node["op"]
    if op == "int":
        return Fraction(node["value"])
    if op == "rat":
        return Fraction(int(node["numerator"]), int(node["denominator"]))
    if op == "var":
        return model[node["name"]]
    if op == "add":
        return sum((value(a, model) for a in node["args"]), Fraction(0))
    if op == "mul":
        result = Fraction(1)
        for a in node["args"]:
            result *= value(a, model)
        return result
    if op == "pow" and type(node["exponent"]) is int and node["exponent"] >= 0:
        return value(node["base"], model) ** node["exponent"]
    raise ValueError("invalid polynomial node")


def verify():
    cases = read_rows("experiment_all.jsonl")
    by_id = {r["case_id"]: r for r in cases}
    if len(cases) != len(by_id) or len(cases) != 2171:
        raise ValueError("incorrect or duplicate distributed input set")
    sat, unsat = read_rows("experiment_sat.jsonl"), read_rows("experiment_unsat.jsonl")
    if ({r["case_id"] for r in sat} != {k for k, r in by_id.items() if r["expected_status"] == "sat"}
            or {r["case_id"] for r in unsat} != {k for k, r in by_id.items() if r["expected_status"] == "unsat"}
            or len(sat) != 1610 or len(unsat) != 561):
        raise ValueError("SAT/UNSAT partitions differ from the distributed set")
    for row in cases:
        path = (ROOT / row["input_path"]).resolve()
        if not path.is_relative_to(ROOT) or hashlib.sha256(path.read_bytes()).hexdigest() != row["input_sha256"]:
            raise ValueError("input path or SHA256 mismatch: " + row["case_id"])
        if set(json.loads(path.read_text(encoding="utf-8"))) != {"variables", "polynomials", "clauses"}:
            raise ValueError("formula must have exactly three input fields")
    verified = 0
    for filename in ("rand_status_certificates.json", "spec_status_certificates.json"):
        evidence = json.loads((ROOT / "benchmarks/provenance" / filename).read_text(encoding="utf-8"))
        for record in evidence["records"]:
            row = by_id[record["case_id"]]
            if record["input_sha256"] != row["input_sha256"] or record["status"] != row["expected_status"]:
                raise ValueError("status evidence is for a different input")
            if record["status"] != "sat":
                continue
            data = json.loads((ROOT / row["input_path"]).read_text(encoding="utf-8"))
            model = {v: Fraction(int(x["numerator"]), int(x["denominator"])) for v, x in record["model"].items()}
            if set(model) != set(data["variables"]):
                raise ValueError("SAT model is incomplete")
            values = [value(p, model) for p in data["polynomials"]]
            if not all(any(s * values[i - 1] > 0 for i, s in clause) for clause in data["clauses"]):
                raise ValueError("exact SAT model fails original formula")
            verified += 1
    if verified != 107:
        raise ValueError("expected 107 exact SAT witnesses")
    return {"instances": len(cases), "statuses": dict(Counter(r["expected_status"] for r in cases)),
            "exact_sat_witnesses_verified": verified}


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2))
