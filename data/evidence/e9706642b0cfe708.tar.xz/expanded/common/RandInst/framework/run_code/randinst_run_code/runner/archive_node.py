"""Archive a stopped shard, including complete attempts and logs."""
import argparse
import hashlib
import shutil
from pathlib import Path
import zipfile

FIXED_ZIP_TIME = (1980, 1, 1, 0, 0, 0)  # Format placeholder, not experiment time.


def digest_file(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def archive(run_dir, destination):
    run_dir, destination = Path(run_dir).resolve(), Path(destination).resolve()
    if not (run_dir / 'run_plan.json').is_file():
        raise ValueError('No run_plan.json in this directory')
    if (run_dir / '.runner.lock').exists():
        raise ValueError('Stop the experiment normally before archiving; .runner.lock exists')
    if destination == run_dir or run_dir in destination.parents:
        raise ValueError('Archive destination must be outside the run directory')
    files = sorted(p for p in run_dir.rglob('*') if p.is_file())
    if any(p.is_symlink() for p in files):
        raise ValueError('Refusing symlinks in experiment records')
    before = {p: digest_file(p) for p in files}
    destination.parent.mkdir(parents=True, exist_ok=True)
    created = False
    try:
        with zipfile.ZipFile(destination, 'x', zipfile.ZIP_DEFLATED, allowZip64=True) as stream:
            created = True
            for path in files:
                info = zipfile.ZipInfo((Path(run_dir.name) / path.relative_to(run_dir)).as_posix(), FIXED_ZIP_TIME)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 0
                with path.open('rb') as source, stream.open(info, 'w', force_zip64=True) as target:
                    shutil.copyfileobj(source, target, length=1024 * 1024)
        if ((run_dir / '.runner.lock').exists()
                or set(files) != {p for p in run_dir.rglob('*') if p.is_file()}
                or any(digest_file(p) != digest for p, digest in before.items())):
            raise ValueError('Run directory changed during archiving; stop it and retry')
        with zipfile.ZipFile(destination) as stream:
            if stream.testzip():
                raise ValueError('ZIP verification failed')
        return destination
    except BaseException:
        if created:
            destination.unlink(missing_ok=True)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    try:
        print(archive(args.run_dir, args.destination))
    except (OSError, ValueError) as exc:
        parser.exit(2, str(exc) + '\n')
