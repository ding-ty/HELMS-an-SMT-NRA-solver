#!/usr/bin/env python3
"""Conservatively reuse completed, single full-budget Windows legacy attempts.

The stopped source is never modified. Its complete directory is archived under
the new, plan-only run before equivalent single-attempt records are imported.
Any job with retries, resource aborts, interruption, errors, shortened budgets,
or uncertain attempt artifacts must run again under the new timing protocol.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import copy
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

try:
    from . import merge_parallel_results as merger
    from . import parallel_plan as protocol
    from . import run_experiments as serial
except ImportError:
    import merge_parallel_results as merger
    import parallel_plan as protocol
    import run_experiments as serial

OLD_TIMING = "resource_retry_charged_wall_plus_final_solve"
NEW_TIMING = "per_attempt_full_budget_final_solve"
UNCHANGED_FILES = (
    "wolfram/PaperSolvers.wl", "wolfram/MCSATCore.wl",
    "wolfram/WolframLS.wl", "wolfram/entrypoint.wls",
    "runner/windows_resources.py", "runner/parallel_resources.py",
)
LOCK_NAMES = (".runner.lock", ".parallel.lock", ".parallel_runner.lock")


def _check_stopped(directory: Path) -> None:
    for name in LOCK_NAMES:
        if (directory / name).exists():
            raise ValueError(f"run is locked: {directory / name}; stop it normally first")


def _is_link(path: Path) -> bool:
    return path.is_symlink() or bool(getattr(path, "is_junction", lambda: False)())


def _snapshot(directory: Path) -> dict[str, str | None]:
    if _is_link(directory):
        raise ValueError("source/target run must not be a link or junction")
    snapshot = {}
    for path in sorted(directory.rglob("*")):
        if _is_link(path):
            raise ValueError(f"refusing a link or junction in run records: {path}")
        if path.is_dir():
            snapshot[path.relative_to(directory).as_posix() + "/"] = None
        elif path.is_file():
            snapshot[path.relative_to(directory).as_posix()] = serial.sha256_file(path)
        else:
            raise ValueError(f"refusing a nonregular run artifact: {path}")
    return snapshot


def _portable_invariants(plan: dict[str, Any]) -> dict[str, Any]:
    payload = copy.deepcopy(protocol.validate_local_campaign(plan)["payload"])
    payload.pop("code")
    policy = payload["resource_policy"]
    policy.pop("revision", None)
    policy.pop("time_accounting", None)
    return payload


def _validate_plans(source: dict[str, Any], target: dict[str, Any]) -> None:
    for plan, timing in ((source, OLD_TIMING), (target, NEW_TIMING)):
        protocol.validate_local_campaign(plan)
        policy = plan["parallel"]["resource_policy"]
        if policy.get("time_accounting") != timing:
            raise ValueError(f"unexpected time_accounting; required {timing}")
        if not str(policy.get("revision", "")).startswith("adaptive-windows-job-"):
            raise ValueError("legacy import only supports protected native Windows runs")
        if plan.get("runner_platform") != "win32":
            raise ValueError("legacy import requires native Windows run plans")
        if not serial.finite_nonnegative(plan.get("timeout_seconds")) or plan["timeout_seconds"] <= 0:
            raise ValueError("invalid full solve budget")
    if _portable_invariants(source) != _portable_invariants(target):
        raise ValueError("campaign mismatch: solver selection, inputs, configuration, seed, runtime or resource policy differ")
    if source["parallel"]["shard_index"] != target["parallel"]["shard_index"]:
        raise ValueError("source and target must describe the same shard")
    old_jobs = {(job["case_id"], job["solver"], job["global_job_index"])
                for job in protocol.assigned_jobs(source)}
    new_jobs = {(job["case_id"], job["solver"], job["global_job_index"])
                for job in protocol.assigned_jobs(target)}
    if old_jobs != new_jobs:
        raise ValueError("source and target assigned job sets differ")
    maps = [{row["path"]: row["sha256"] for row in plan["parallel"]["campaign"]["payload"]["code"]}
            for plan in (source, target)]
    for name in UNCHANGED_FILES:
        if name not in maps[0] or name not in maps[1] or maps[0][name] != maps[1][name]:
            raise ValueError(f"unchanged solver/resource code mismatch: {name}")
        path = Path(target["parallel"]["package_root"]) / name
        if not path.is_file() or serial.sha256_file(path) != maps[1][name]:
            raise ValueError(f"target solver/resource file differs from its plan: {name}")


def _ensure_empty_target(target: Path) -> None:
    if not (target / "run_plan.json").is_file():
        raise ValueError("target needs a run_plan.json generated with the new --plan-only command")
    for name in ("results.jsonl", "attempts.jsonl"):
        path = target / name
        if path.exists() and (not path.is_file() or path.stat().st_size):
            raise ValueError(f"target records must be empty: {path}")
    for name in ("jobs", "legacy_source", "import_report.json"):
        if (target / name).exists():
            raise ValueError(f"target must be an unused plan-only run: {target / name} already exists")
    for name in ("scheduler_events.jsonl", "resource_metrics.jsonl"):
        path = target / name
        if path.exists() and path.stat().st_size:
            raise ValueError("target already contains scheduler activity; use a new plan-only run")


def _inside_file(value: Any, source: Path) -> Path:
    if not isinstance(value, str):
        raise ValueError("missing original request/log path")
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = source / candidate
    candidate = candidate.resolve()
    if source not in candidate.parents or not candidate.is_file():
        raise ValueError(f"original request/log is missing or outside its run: {value}")
    return candidate


def _artifact_taints(source: Path, attempts: list[dict[str, Any]]) -> set[tuple[str, str]]:
    """Unjournaled starts or extra attempt directories preclude automatic reuse."""
    tainted = set()
    by_prefix = {row["job_key"][:24]: (row["case_id"], row["solver"]) for row in attempts}
    identities = {(row["job_key"], row["attempt"]): row for row in attempts}
    for job_directory in (source / "jobs").glob("*"):
        pair = by_prefix.get(job_directory.name)
        if pair is None:
            continue
        directories = list(job_directory.glob("attempt-*"))
        if len(directories) != 1 or directories[0].name != "attempt-0001":
            tainted.add(pair)
            continue
        state_path = directories[0] / "attempt_state.json"
        if not state_path.is_file():
            tainted.add(pair)
            continue
        try:
            state = serial.read_json(state_path)
            record = state["record"]
            if (state.get("state") != "finished"
                    or identities.get((record["job_key"], record["attempt"])) != record
                    or (record.get("case_id"), record.get("solver")) != pair):
                tainted.add(pair)
        except (KeyError, TypeError, ValueError):
            tainted.add(pair)
    return tainted


def _eligible_reason(final: dict[str, Any], rows: list[dict[str, Any]],
                     tainted: bool, source: Path, plan: dict[str, Any]) -> str | None:
    if len(rows) != 1 or final.get("attempt") != 1 or rows[0].get("attempt") != 1:
        return "multiple_or_uncertain_attempts"
    if tainted:
        return "unconfirmed_or_extra_attempt_artifacts"
    budget = plan["timeout_seconds"]
    for row in (rows[0], final):
        if (row.get("charged_prior_wall_seconds") != 0
                or row.get("attempt_timeout_seconds") != budget
                or row.get("resource_retry_count", 0) != 0
                or row.get("resource_aborted") or row.get("exclusive_resource_retry")
                or row.get("no_additional_attempt_launched")):
            return "resource_retry_or_shortened_budget"
        if row.get("actual_status") not in {"sat", "unsat", "timeout", "unknown"}:
            return "error_or_interrupted"
        kind = str(row.get("failure_kind", ""))
        if any(word in kind.lower() for word in ("resource", "memory", "interrupt", "cumulative")):
            return "resource_or_interrupted_failure"
        if row.get("validation_conflict") or row.get("effective_status") == "conflict":
            return "validation_conflict"
    try:
        request_path = _inside_file(final.get("request_path"), source)
        _inside_file(final.get("stdout_log"), source)
        _inside_file(final.get("stderr_log"), source)
        request = serial.read_json(request_path)
    except (OSError, ValueError):
        return "missing_or_uncertain_original_artifacts"
    expected = {key: final[key] for key in ("case_id", "solver", "seed", "input_sha256")}
    expected.update(fingerprint=plan["fingerprint"], timeout_seconds=budget)
    if any(request.get(key) != value for key, value in expected.items()):
        return "original_request_was_not_one_full_budget_attempt"
    if request.get("worker_config") != plan["configuration"].get("worker", plan["configuration"]):
        return "original_worker_configuration_mismatch"
    if request.get("code") != plan["code"]:
        return "original_request_code_manifest_mismatch"
    if final.get("failure_kind") != "process_wall_timeout":
        try:
            raw = serial.read_json(_inside_file(final.get("worker_result_path"), source))
        except (OSError, ValueError):
            return "missing_or_uncertain_original_worker_result"
        if serial.normalize_worker_result(raw, budget) != final.get("worker_result"):
            return "original_worker_result_mismatch"
    return None


def _rebind(final: dict[str, Any], source: Path, target: Path,
            old_plan: dict[str, Any], new_plan: dict[str, Any], job: dict[str, Any]) -> dict[str, Any]:
    archive = target / "legacy_source"
    source_text = str(source).replace("\\", "/").rstrip("/")

    def paths(value):
        if isinstance(value, dict):
            return {key: (copy.deepcopy(item) if key == "worker_result" else paths(item))
                    for key, item in value.items()}
        if isinstance(value, list):
            return [paths(item) for item in value]
        if isinstance(value, str):
            normalized = value.replace("\\", "/")
            if normalized.casefold().startswith(source_text.casefold() + "/"):
                return str(archive / normalized[len(source_text) + 1:])
        return value

    result = paths(final)
    result.update(
        fingerprint=new_plan["fingerprint"],
        job_key=serial.digest_object({"fingerprint": new_plan["fingerprint"],
                                      "case_id": job["case_id"], "solver": job["solver"]}),
        campaign_fingerprint=new_plan["parallel"]["campaign"]["fingerprint"],
        campaign_job_key=job["campaign_job_key"], global_job_index=job["global_job_index"],
        shard_index=job["shard_index"], code_fingerprint=serial.digest_object(new_plan["code"]),
        resource_policy_sha256=serial.digest_object(new_plan["parallel"]["resource_policy"]),
        timing_basis=NEW_TIMING, prior_attempt_wall_seconds=0.0, charged_prior_wall_seconds=0.0,
        attempt_timeout_seconds=new_plan["timeout_seconds"], resource_retry_count=0,
        all_attempt_wall_seconds=final["worker_wall_seconds"],
        solve_seconds=final["final_attempt_solve_seconds"], attempts_journal="attempts.jsonl",
        record_origin="validated_legacy_single_full_attempt",
        source_provenance={
            "archive": "legacy_source", "source_result_file": "legacy_source/results.jsonl",
            "source_result_sha256": serial.digest_object(final),
            "fingerprint": old_plan["fingerprint"],
            "campaign_fingerprint": old_plan["parallel"]["campaign"]["fingerprint"],
            "job_key": final["job_key"], "campaign_job_key": final["campaign_job_key"],
            "code_fingerprint": final["code_fingerprint"], "attempt": final["attempt"],
            "time_accounting": OLD_TIMING,
            "equivalence": "one completed uncharged attempt with the identical full solve budget; unchanged solver and resource implementations",
        })
    result["input_path"] = next(case["input_path"] for case in new_plan["cases"] if case["case_id"] == job["case_id"])
    return result


def _write_lines(path: Path, records: list[dict[str, Any]]) -> None:
    path.write_text("".join(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n" for row in records), encoding="utf-8")


def _remove_owned_tree(path: Path, target: Path) -> None:
    # Every recursive removal must be an importer-owned immediate target child.
    if path.resolve().parent != target.resolve() or _is_link(path):
        raise ValueError("refusing cleanup outside the target run")
    shutil.rmtree(path)


def import_run(source_run: Path, target_run: Path) -> dict[str, Any]:
    source, target = Path(source_run).resolve(), Path(target_run).resolve()
    if source == target or source in target.parents or target in source.parents:
        raise ValueError("source and target must be separate, non-nested run directories")
    _check_stopped(source)
    _check_stopped(target)
    _ensure_empty_target(target)
    lock = target / ".runner.lock"
    descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    os.write(descriptor, f"importer pid={os.getpid()}\n".encode("ascii"))
    os.close(descriptor)
    stage = None
    committed = []
    originals = {name: (target / name).exists() for name in ("results.jsonl", "attempts.jsonl")}
    try:
        before = _snapshot(source)
        target_plan_sha = serial.sha256_file(target / "run_plan.json")
        old_plan = serial.read_json(source / "run_plan.json")
        new_plan = serial.read_json(target / "run_plan.json")
        _validate_plans(old_plan, new_plan)
        if not (source / "results.jsonl").is_file():
            raise ValueError("source results.jsonl is required")
        finals = merger._records(source, old_plan)
        attempts = merger._attempts(source, old_plan, finals)
        history = defaultdict(list)
        for row in attempts:
            history[(row["case_id"], row["solver"])].append(row)
        tainted = _artifact_taints(source, attempts)
        jobs = protocol.assigned_jobs(new_plan)
        job_map = {(job["case_id"], job["solver"]): job for job in jobs}
        retained, rejected = [], []
        for final in finals:
            pair = (final["case_id"], final["solver"])
            reason = _eligible_reason(final, history[pair], pair in tainted, source, old_plan)
            if reason:
                rejected.append({"case_id": pair[0], "solver": pair[1], "reason": reason})
            else:
                retained.append(_rebind(final, source, target, old_plan, new_plan, job_map[pair]))
        report = {
            "schema_version": 1, "protocol": "validated-legacy-single-full-attempt-v1",
            "source_fingerprint": old_plan["fingerprint"], "target_fingerprint": new_plan["fingerprint"],
            "source_campaign_fingerprint": old_plan["parallel"]["campaign"]["fingerprint"],
            "target_campaign_fingerprint": new_plan["parallel"]["campaign"]["fingerprint"],
            "shard_index": new_plan["parallel"]["shard_index"], "assigned_jobs": len(jobs),
            "imported_jobs": len(retained), "jobs_to_run": len(jobs) - len(retained),
            "source_final_records": len(finals), "source_attempt_records": len(attempts),
            "rejected_completed_jobs": rejected,
            "rejection_counts": dict(Counter(row["reason"] for row in rejected)),
            "source_archive": "legacy_source", "source_archive_files_sha256": before,
            "source_modified": False, "original_timing_policy": OLD_TIMING,
            "target_timing_policy": NEW_TIMING,
            "note": "Only completed single full-budget attempts are reused; every retried, interrupted, resource-aborted, shortened or erroneous job runs again from scratch.",
        }
        stage = Path(tempfile.mkdtemp(prefix=".legacy-import-", dir=target))
        shutil.copytree(source, stage / "legacy_source", copy_function=shutil.copyfile)
        if _snapshot(stage / "legacy_source") != before:
            raise ValueError("source archive copy verification failed")
        serial.write_json(stage / "run_plan.json", new_plan)
        _write_lines(stage / "results.jsonl", retained)
        _write_lines(stage / "attempts.jsonl", retained)
        serial.write_json(stage / "import_report.json", report)
        checked = merger._records(stage, new_plan)
        merger._attempts(stage, new_plan, checked)
        _check_stopped(source)
        if _snapshot(source) != before:
            raise ValueError("source changed during import; no imported results are committed")
        if serial.sha256_file(target / "run_plan.json") != target_plan_sha:
            raise ValueError("target plan changed during import")
        _ensure_empty_target(target)
        for name in ("legacy_source", "attempts.jsonl", "results.jsonl", "import_report.json"):
            (stage / name).replace(target / name)
            committed.append(name)
        return report
    except BaseException:
        for name in reversed(committed):
            path = target / name
            if path.is_dir():
                _remove_owned_tree(path, target)
            elif originals.get(name):
                path.write_bytes(b"")
            else:
                path.unlink(missing_ok=True)
        raise
    finally:
        if stage is not None and stage.exists():
            _remove_owned_tree(stage, target)
        lock.unlink(missing_ok=True)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-run", required=True, type=Path)
    parser.add_argument("--target-run", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        report = import_run(args.source_run, args.target_run)
        print(f"Imported {report['imported_jobs']} verified single full-budget jobs; {report['jobs_to_run']} jobs must run. Original stopped run preserved in legacy_source.")
        return 0
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.exit(2, "ERROR: " + str(exc) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())
