"""Read-only status, including environmental interruptions and memory failures."""
from collections import Counter
import argparse
import json
from pathlib import Path


def rows(path):
    if not path.exists():
        return []
    data = path.read_bytes()
    # A running writer may be appending one line. Do not mutate/truncate it.
    lines = data.splitlines(keepends=True)
    if lines and not lines[-1].endswith(b"\n"):
        lines.pop()
    return [json.loads(line) for line in lines if line.strip()]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    root = args.output_dir.resolve()
    print('Directory:', root)
    if not (root / 'run_plan.json').exists():
        print('No campaign plan yet.')
        return
    plan = json.loads((root / 'run_plan.json').read_bytes())
    final, attempts = rows(root / 'results.jsonl'), rows(root / 'attempts.jsonl')
    print('Final jobs:', len(final), '/', len(plan['jobs']))
    print('SAT/UNSAT:', sum(r['actual_status'] in {'sat', 'unsat'} for r in final))
    print('TIMEOUT:', sum(r['actual_status'] == 'timeout' for r in final))
    print('MEMOUT/resource_exhausted:', sum(r.get('failure_kind') == 'resource_exhausted' for r in final))
    print('Other final errors:', sum(r['actual_status'] == 'error' and r.get('failure_kind') != 'resource_exhausted' for r in final))
    print('Environmental interruptions:', sum(r.get('failure_kind') == 'environment_memory_pressure' for r in attempts))
    print('Final jobs by solver:', dict(Counter(r['solver'] for r in final)))
    known = {(r['job_key'], r['attempt']) for r in attempts}
    unfinalized = []
    for path in root.glob('jobs/*/attempt-*/attempt_state.json'):
        data = json.loads(path.read_bytes())
        row = data['record']
        if (row['job_key'], row['attempt']) not in known:
            unfinalized.append((row['solver'], row['case_id'], row['attempt'], data['state']))
    print('Unjournaled active/crash states:', unfinalized)
    print('Lock present (not proof of a live process):', (root / '.runner.lock').exists())


if __name__ == '__main__':
    main()
