"""Run selected paper solvers serially, then save checked local tables/plots.

The paper case policy is mandatory here: local-search modes run confirmed SAT
only, while decision modes run confirmed SAT+UNSAT. Use run_experiments.py
directly for explicitly separate diagnostic policies.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import sys

try:
    from .run_experiments import DEFAULT_SOLVERS, SOLVERS, event_stamp
except ImportError:
    from run_experiments import DEFAULT_SOLVERS, SOLVERS, event_stamp

ROOT = Path(__file__).resolve().parents[1]


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--solvers", default="all", help="all means the default eight modes; or comma-separated solver IDs")
    p.add_argument("--manifest", type=Path, default=ROOT / "benchmarks/experiment_smtlib_all.jsonl")
    p.add_argument("--output-dir", type=Path, default=ROOT / "results/paper_run")
    p.add_argument("--config", type=Path, default=ROOT / "config/run_config.json")
    p.add_argument("--wolfram-command", help="Mathematica kernel executable path, or use WOLFRAM_COMMAND/PATH")
    p.add_argument("--runtime-args", default='["-noinit"]', help="JSON runtime argument array; use [] for wolframscript if needed")
    p.add_argument("--launch-mode", choices=("script", "file"), default="script")
    p.add_argument("--timeout", type=float, default=1200)
    p.add_argument("--seed", type=int, default=314159)
    p.add_argument("--startup-grace", type=float, default=60)
    p.add_argument("--benchmark", action="append", default=[])
    p.add_argument("--case-id", action="append", default=[])
    p.add_argument("--max-cases", type=int)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--dry-run", action="store_true", help="Print the actual planned job counts without launching Mathematica")
    p.add_argument("--render", action="store_true", help="Also render PDF figures; requires matplotlib")
    return p


def commands(args):
    solvers = list(DEFAULT_SOLVERS) if args.solvers == "all" else [s.strip() for s in args.solvers.split(",")]
    if not solvers or len(set(solvers)) != len(solvers) or any(s not in SOLVERS for s in solvers):
        raise ValueError("invalid or repeated solver ID; available: " + ", ".join(SOLVERS))
    run = [sys.executable, str(ROOT / "runner/run_experiments.py"), "run",
           "--manifest", str(args.manifest.resolve()), "--output-dir", str(args.output_dir.resolve()),
           "--config", str(args.config.resolve()), "--solvers", ",".join(solvers),
           "--case-policy", "paper", "--seed", str(args.seed), "--timeout", str(args.timeout),
           "--startup-grace", str(args.startup_grace), "--launch-mode", args.launch_mode,
           "--runtime-args", args.runtime_args, "--code", str(Path(__file__).resolve())]
    if args.wolfram_command:
        run.extend(["--wolfram-command", args.wolfram_command])
    for name in ("benchmark", "case_id"):
        for value in getattr(args, name):
            run.extend(["--" + name.replace("_", "-"), value])
    if args.max_cases is not None:
        run.extend(["--max-cases", str(args.max_cases)])
    for name in ("resume", "dry_run"):
        if getattr(args, name):
            run.append("--" + name.replace("_", "-"))
    output = args.output_dir.resolve()
    summary = [sys.executable, str(ROOT / "runner/summarize_results.py"),
               "--results", str(output / "results.jsonl"), "--output-dir", str(output / "summary")]
    plots = [sys.executable, str(ROOT / "runner/plot_results.py"),
             "--results", str(output / "results.jsonl"), "--summary-dir", str(output / "summary"),
             "--output-dir", str(output / "plots")]
    if args.render:
        plots.append("--render")
    return run, summary, plots


def main(argv=None):
    p = parser()
    args = p.parse_args(argv)
    try:
        pipeline = commands(args)
    except ValueError as exc:
        p.error(str(exc))
    print("Selection: paper; LS-WL/2D-LS confirmed SAT only, decision modes confirmed SAT+UNSAT.", flush=True)
    print("Output directory: " + str(args.output_dir.resolve()), flush=True)
    codes = []
    try:
        for index, command in enumerate(pipeline):
            if args.dry_run and index > 0:
                break
            print("RUN: " + subprocess.list2cmdline(command), flush=True)
            code = subprocess.run(command, cwd=ROOT, check=False).returncode
            codes.append(code)
            if index == 0 and code not in (0, 1):
                return code
            if index > 0 and code != 0:
                return code
    except KeyboardInterrupt:
        print("Interrupted. Completed records are retained; repeat the SAME command with --resume.", file=sys.stderr)
        return 130
    if args.dry_run:
        return codes[0]
    completion = {"finished_event": event_stamp(),
                  "commands": pipeline, "return_codes": codes,
                  "case_policy": "paper", "note": "Use summary/violations.csv before counting solved cases."}
    destination = args.output_dir.resolve() / "batch_completion.json"
    destination.write_text(json.dumps(completion, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print("Saved raw results, checked CSV tables and plot data to " + str(args.output_dir.resolve()), flush=True)
    return codes[0]


if __name__ == "__main__":
    raise SystemExit(main())
