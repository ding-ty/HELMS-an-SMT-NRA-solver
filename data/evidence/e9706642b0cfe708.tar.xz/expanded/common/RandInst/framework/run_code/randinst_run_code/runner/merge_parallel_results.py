#!/usr/bin/env python3
"""Validate and archive disjoint machine runs, then derive a common summary.

Never concatenate incompatible runs or silently turn missing/resource-aborted
attempts into timeouts.  Original plans, raw records and all job/event logs are
copied into ``sources`` before creating the normalized derived results file.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Any

try:
    from . import parallel_plan as protocol
    from . import run_experiments as serial
    from . import summarize_results as summaries
except ImportError:
    import parallel_plan as protocol
    import run_experiments as serial
    import summarize_results as summaries


def _finite_seconds(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def _strict_policy(plan: dict[str, Any]) -> bool:
    policy = plan["parallel"]["resource_policy"]
    return (policy.get("revision", policy.get("version")) == "adaptive-cgroup-v1"
            or policy.get("time_accounting") in {
                "per-attempt-wall-unpaused", "resource_retry_charged_wall_plus_final_solve",
                "per_attempt_full_budget_final_solve"})


def _full_attempt_policy(plan: dict[str, Any]) -> bool:
    return (plan["parallel"]["resource_policy"].get("time_accounting")
            == "per_attempt_full_budget_final_solve")


def _validate_full_attempt_timing(record: dict[str, Any], plan: dict[str, Any], prefix: str) -> None:
    """Validate one final result; previous attempts are audit data, not solve time."""
    budget = plan["timeout_seconds"]
    if record.get("timing_basis") != "per_attempt_full_budget_final_solve":
        raise ValueError(f"{prefix}: missing or unsupported full-attempt timing_basis")
    prior = record.get("prior_attempt_wall_seconds")
    charged = record.get("charged_prior_wall_seconds")
    attempt_budget = record.get("attempt_timeout_seconds")
    worker_wall = record.get("worker_wall_seconds")
    all_wall = record.get("all_attempt_wall_seconds")
    if not all(_finite_seconds(value) for value in (prior, charged, attempt_budget, worker_wall, all_wall)):
        raise ValueError(f"{prefix}: full-attempt timing fields must be finite and nonnegative")
    if charged != 0 or abs(attempt_budget - budget) > 1e-6:
        raise ValueError(f"{prefix}: every attempt must receive the full solve timeout without prior charges")
    if abs(all_wall - prior - worker_wall) > 1e-6:
        raise ValueError(f"{prefix}: all_attempt_wall_seconds omits audited attempt time")
    if (record.get("failure_kind") == "resource_retry_budget_exhausted"
            or record.get("no_additional_attempt_launched")):
        raise ValueError(f"{prefix}: prior attempts cannot synthesize a timeout without a final attempt")
    retries = record.get("resource_retry_count")
    if type(retries) is not int or retries < 0 or retries > plan["parallel"]["resource_policy"].get("max_resource_retries", retries):
        raise ValueError(f"{prefix}: invalid resource_retry_count")
    worker = record.get("worker_result")
    final_solve = record.get("final_attempt_solve_seconds")
    if (not isinstance(worker, dict) or worker.get("solve_seconds") != final_solve
            or record.get("solve_seconds") != final_solve
            or (final_solve is not None and not _finite_seconds(final_solve))):
        raise ValueError(f"{prefix}: solve timing must equal the final attempt's preserved worker timing")
    if record["actual_status"] in {"sat", "unsat"} and (
            not _finite_seconds(final_solve) or final_solve > budget + 1e-6
            or record.get("resource_aborted") or record.get("failure_kind") == "interrupted"):
        raise ValueError(f"{prefix}: successful result is not a completed in-budget final attempt")


def _validate_cumulative_timing(record: dict[str, Any], plan: dict[str, Any], prefix: str) -> None:
    """Dispatch by the recorded protocol, preserving historical budget validation."""
    if _full_attempt_policy(plan):
        _validate_full_attempt_timing(record, plan, prefix)
        return
    policy = plan["parallel"]["resource_policy"]
    strict = _strict_policy(plan)
    if not strict and "timing_basis" not in record:
        return
    if record.get("timing_basis") != "resource_retry_charged_wall_plus_final_solve":
        raise ValueError(f"{prefix}: missing or unsupported cumulative timing_basis")
    budget = plan["timeout_seconds"]
    prior = record.get("charged_prior_wall_seconds")
    remaining = record.get("attempt_timeout_seconds")
    all_wall = record.get("all_attempt_wall_seconds")
    final_solve = record.get("final_attempt_solve_seconds")
    retries = record.get("resource_retry_count")
    if not all(_finite_seconds(value) for value in (prior, remaining, all_wall)):
        raise ValueError(f"{prefix}: cumulative retry timing fields must be finite and nonnegative")
    if remaining > budget:
        raise ValueError(f"{prefix}: a resource retry exceeds the original timeout budget")
    if remaining <= 0 or abs(remaining - (budget - prior)) > 1e-6:
        raise ValueError(f"{prefix}: attempt timeout is not the unspent original job budget")
    if type(retries) is not int or retries < 0 or retries > policy.get("max_resource_retries", retries):
        raise ValueError(f"{prefix}: invalid resource_retry_count")
    if final_solve is not None and not _finite_seconds(final_solve):
        raise ValueError(f"{prefix}: invalid final_attempt_solve_seconds")
    worker_wall = record.get("worker_wall_seconds")
    if not _finite_seconds(worker_wall) or abs(all_wall - prior - worker_wall) > 1e-6:
        raise ValueError(f"{prefix}: all_attempt_wall_seconds omits charged/last attempt time")
    worker = record.get("worker_result")
    if isinstance(worker, dict) and worker.get("solve_seconds") != final_solve:
        raise ValueError(f"{prefix}: final solve timing differs from preserved worker result")
    if record["actual_status"] in {"sat", "unsat"}:
        solve = record.get("solve_seconds")
        if (not _finite_seconds(final_solve) or not _finite_seconds(solve) or prior > budget + 1e-6
                or remaining <= 0 or final_solve > remaining + 1e-6
                or solve > budget + 1e-6 or abs(solve - prior - final_solve) > 1e-6):
            raise ValueError(f"{prefix}: solved retry timing is inconsistent with its cumulative budget")


def _records(run_dir: Path, plan: dict[str, Any]) -> list[dict[str, Any]]:
    records = serial.read_results(run_dir / "results.jsonl", plan["fingerprint"])
    campaign = protocol.validate_local_campaign(plan)
    jobs = {(row["case_id"], row["solver"]): row for row in protocol.assigned_jobs(plan)}
    cases = {case["case_id"]: case for case in plan["cases"]}
    previous = {}
    for line, record in enumerate(records, 1):
        prefix = f"{run_dir}/results.jsonl:{line}"
        pair = (record.get("case_id"), record.get("solver"))
        if pair not in jobs:
            raise ValueError(f"{prefix}: job is outside this machine's shard")
        expected_key = serial.digest_object({"fingerprint": plan["fingerprint"],
                                             "case_id": pair[0], "solver": pair[1]})
        if record.get("job_key") != expected_key:
            raise ValueError(f"{prefix}: local job key mismatch")
        job = jobs[pair]
        policy = plan["parallel"]["resource_policy"]
        strict = _strict_policy(plan)
        for key in ("campaign_job_key", "global_job_index"):
            if (strict or key in record) and record.get(key) != job[key]:
                raise ValueError(f"{prefix}: {key} differs from its campaign job")
        for key, expected in (("campaign_fingerprint", campaign["fingerprint"]),
                              ("shard_index", plan["parallel"]["shard_index"]),
                              ("resource_policy_sha256", serial.digest_object(policy))):
            if (strict or key in record) and record.get(key) != expected:
                raise ValueError(f"{prefix}: {key} differs from its parallel run plan")
        case = cases[pair[0]]
        for key in ("input_sha256", "expected_status", "benchmark", "family"):
            if record.get(key) != case.get(key):
                raise ValueError(f"{prefix}: {key} differs from its run plan")
        for field, expected in (
                ("seed", plan["seed"]), ("timeout_seconds", plan["timeout_seconds"]),
                ("configuration_sha256", plan["configuration_sha256"]),
                ("code_fingerprint", serial.digest_object(plan["code"]))):
            if record.get(field) != expected:
                raise ValueError(f"{prefix}: {field} differs from its run plan")
        attempt = record.get("attempt")
        if type(attempt) is not int or attempt < 1 or attempt <= previous.get(pair, 0):
            raise ValueError(f"{prefix}: duplicate/out-of-order attempt")
        previous[pair] = attempt
        if record.get("actual_status") not in serial.ACTUAL_STATUSES:
            raise ValueError(f"{prefix}: unsupported actual_status")
        _validate_cumulative_timing(record, plan, prefix)
        # The unchanged entrypoint verifies SAT witnesses before publishing them.
        # Refuse to elevate a malformed/unverified model to a solved merged row.
        if record["actual_status"] == "sat":
            metadata = record.get("solver_metadata")
            if not isinstance(metadata, dict) or metadata.get("model_verified") is not True:
                raise ValueError(f"{prefix}: SAT model_verified must be true")
            worker = record.get("worker_result")
            if isinstance(worker, dict) and worker.get("model_verified") is False:
                raise ValueError(f"{prefix}: worker contradicts SAT model verification")
        identity = plan.get("runtime_identity")
        if identity and record["actual_status"] in {"sat", "unsat"}:
            metadata = record.get("solver_metadata")
            if not isinstance(metadata, dict) or any(metadata.get(k) != v for k, v in identity.items()):
                raise ValueError(f"{prefix}: successful result runtime identity differs")
    return records


def _attempts(run_dir: Path, plan: dict[str, Any], finals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Validate the complete journal under its original time-accounting protocol."""
    strict = _strict_policy(plan)
    path = run_dir / "attempts.jsonl"
    if not path.is_file():
        if strict:
            raise ValueError(f"missing required attempts journal: {path}")
        return []
    attempts = serial.read_results(path, plan["fingerprint"])
    if not strict:
        return attempts
    jobs = {(job["case_id"], job["solver"]): job for job in protocol.assigned_jobs(plan)}
    cases = {case["case_id"]: case for case in plan["cases"]}
    history: dict[tuple[str, str], list[dict[str, Any]]] = {}
    campaign = plan["parallel"]["campaign"]
    for line, record in enumerate(attempts, 1):
        prefix = f"{path}:{line}"
        pair = (record.get("case_id"), record.get("solver"))
        if pair not in jobs:
            raise ValueError(f"{prefix}: attempt is outside its assigned shard")
        prior_rows = history.setdefault(pair, [])
        attempt = record.get("attempt")
        if type(attempt) is not int or attempt < 1 or (prior_rows and attempt <= prior_rows[-1]["attempt"]):
            raise ValueError(f"{prefix}: duplicate/out-of-order attempt journal entry")
        case, job = cases[pair[0]], jobs[pair]
        for field, expected in (
                ("job_key", serial.digest_object({"fingerprint": plan["fingerprint"], "case_id": pair[0], "solver": pair[1]})),
                ("campaign_fingerprint", campaign["fingerprint"]),
                ("campaign_job_key", job["campaign_job_key"]), ("global_job_index", job["global_job_index"]),
                ("shard_index", plan["parallel"]["shard_index"]),
                ("resource_policy_sha256", serial.digest_object(plan["parallel"]["resource_policy"])),
                ("configuration_sha256", plan["configuration_sha256"]),
                ("code_fingerprint", serial.digest_object(plan["code"])),
                ("timeout_seconds", plan["timeout_seconds"]), ("seed", plan["seed"])):
            if record.get(field) != expected:
                raise ValueError(f"{prefix}: attempt {field} differs from plan")
        for field in ("input_sha256", "expected_status", "benchmark", "family"):
            if record.get(field) != case.get(field):
                raise ValueError(f"{prefix}: attempt {field} differs from input metadata")
        if record.get("actual_status") not in serial.ACTUAL_STATUSES:
            raise ValueError(f"{prefix}: attempt has an invalid status")
        prior = sum(row["worker_wall_seconds"] for row in prior_rows)
        full_attempt = _full_attempt_policy(plan)
        remaining = plan["timeout_seconds"] if full_attempt else plan["timeout_seconds"] - prior
        if full_attempt:
            if (prior_rows and not prior_rows[-1].get("resource_aborted")
                    and prior_rows[-1].get("failure_kind") != "interrupted"):
                raise ValueError(f"{prefix}: only resource-aborted or interrupted attempts may be retried")
            if (record.get("timing_basis") != "per_attempt_full_budget_final_solve"
                    or not _finite_seconds(record.get("charged_prior_wall_seconds"))
                    or record["charged_prior_wall_seconds"] != 0
                    or not _finite_seconds(record.get("prior_attempt_wall_seconds"))
                    or abs(record["prior_attempt_wall_seconds"] - prior) > 1e-6
                    or not _finite_seconds(record.get("attempt_timeout_seconds"))
                    or abs(record["attempt_timeout_seconds"] - remaining) > 1e-6
                    or not _finite_seconds(record.get("worker_wall_seconds"))):
                raise ValueError(f"{prefix}: attempt must preserve prior audit time and receive a full uncharged budget")
            if (record.get("failure_kind") == "resource_retry_budget_exhausted"
                    or record.get("no_additional_attempt_launched")):
                raise ValueError(f"{prefix}: prior attempts cannot synthesize a timeout without a final attempt")
        elif (not _finite_seconds(record.get("charged_prior_wall_seconds"))
                or abs(record["charged_prior_wall_seconds"] - prior) > 1e-6
                or not _finite_seconds(record.get("attempt_timeout_seconds"))
                or remaining <= 0 or abs(record["attempt_timeout_seconds"] - remaining) > 1e-6
                or not _finite_seconds(record.get("worker_wall_seconds"))):
            raise ValueError(f"{prefix}: attempt omits previous elapsed cost or exceeds remaining budget")
        worker = record.get("worker_result")
        final_solve = record.get("final_attempt_solve_seconds")
        if (not isinstance(worker, dict) or worker.get("solve_seconds") != final_solve
                or (final_solve is not None and not _finite_seconds(final_solve))):
            raise ValueError(f"{prefix}: attempt worker timing was not preserved")
        if full_attempt and record.get("solve_seconds") != final_solve:
            raise ValueError(f"{prefix}: attempt solve timing must exclude prior audit time")
        if record["actual_status"] in {"sat", "unsat"}:
            metadata = record.get("solver_metadata")
            identity = plan.get("runtime_identity") or {}
            if (not isinstance(metadata, dict) or any(metadata.get(k) != v for k, v in identity.items())
                    or (record["actual_status"] == "sat" and metadata.get("model_verified") is not True)
                    or not _finite_seconds(final_solve) or final_solve > remaining + 1e-6
                    or not _finite_seconds(record.get("solve_seconds"))
                    or (full_attempt and (record.get("resource_aborted") or record.get("failure_kind") == "interrupted"))
                    or abs(record["solve_seconds"] - (0 if full_attempt else prior) - final_solve) > 1e-6):
                raise ValueError(f"{prefix}: successful attempt has invalid verification or timing")
        prior_rows.append(record)
    seen_finals = set()
    for record in finals:
        pair = (record["case_id"], record["solver"])
        if pair in seen_finals:
            raise ValueError(f"{path}: duplicate final job result")
        seen_finals.add(pair)
        rows = history.get(pair, [])
        if not rows or rows[-1]["attempt"] != record["attempt"]:
            raise ValueError(f"{path}: final result lacks its last completed journal attempt")
        last = rows[-1]
        matching_fields = ["job_key", "worker_result", "worker_wall_seconds", "charged_prior_wall_seconds",
                           "attempt_timeout_seconds", "final_attempt_solve_seconds"]
        if _full_attempt_policy(plan):
            matching_fields.extend(("prior_attempt_wall_seconds", "timing_basis", "solve_seconds"))
        for field in matching_fields:
            if record.get(field) != last.get(field):
                raise ValueError(f"{path}: final {field} differs from its last journal attempt")
        total_wall = sum(row["worker_wall_seconds"] for row in rows)
        retry_count = sum(bool(row.get("resource_aborted")) for row in rows[:-1])
        if abs(record["all_attempt_wall_seconds"] - total_wall) > 1e-6 or record["resource_retry_count"] != retry_count:
            raise ValueError(f"{path}: final result omits prior attempt cost or resource retries")
        exhausted = (not _full_attempt_policy(plan)
                     and record.get("failure_kind") == "resource_retry_budget_exhausted")
        if exhausted:
            if total_wall < plan["timeout_seconds"] or record["actual_status"] != "timeout":
                raise ValueError(f"{path}: resource retry budget was not actually exhausted")
        elif record["actual_status"] != last["actual_status"]:
            raise ValueError(f"{path}: final status differs from its completed attempt")
    return attempts


def _check_stopped(run_dir: Path) -> None:
    for name in (".runner.lock", ".parallel.lock", ".parallel_runner.lock"):
        if (run_dir / name).exists():
            raise ValueError(f"run is locked: {run_dir / name}; stop it normally before merging")


def merge_runs(run_dirs: list[Path], output_dir: Path, allow_missing_shards: bool = False
               ) -> dict[str, Any]:
    if not run_dirs:
        raise ValueError("at least one --run-dir is required")
    output_dir = output_dir.resolve()
    if output_dir.exists():
        raise ValueError("output directory already exists; use a new directory to preserve prior data")
    sources = []
    seen_shards = set()
    campaign = None
    for value in run_dirs:
        run_dir = Path(value).resolve()
        if run_dir == output_dir or run_dir in output_dir.parents:
            raise ValueError("merged output must not be inside an input run")
        _check_stopped(run_dir)
        plan_digest = serial.sha256_file(run_dir / "run_plan.json")
        plan = serial.read_json(run_dir / "run_plan.json")
        current = protocol.validate_local_campaign(plan)
        if campaign is None:
            campaign = current
        elif current != campaign:
            raise ValueError("campaign mismatch: code, inputs, configuration, runtime or resource policy differ")
        shard = plan["parallel"]["shard_index"]
        if shard in seen_shards:
            raise ValueError(f"duplicate shard {shard}: do not combine duplicate copies of a machine run")
        seen_shards.add(shard)
        # A never-started shard may have a plan and an empty results file.  Missing
        # job records stay not_run; a missing raw file is not silently invented.
        results_path = run_dir / "results.jsonl"
        if not results_path.is_file():
            raise ValueError(f"missing raw results file: {results_path}")
        results_digest = serial.sha256_file(results_path)
        auxiliary_digests = {path.name: serial.sha256_file(path) for path in sorted(run_dir.iterdir())
                             if path.is_file() and path.name not in {"results.jsonl", "run_plan.json"}}
        records = _records(run_dir, plan)
        attempts = _attempts(run_dir, plan, records)
        _check_stopped(run_dir)
        if serial.sha256_file(run_dir / "run_plan.json") != plan_digest or serial.sha256_file(results_path) != results_digest:
            raise ValueError("source plan/results changed while being validated")
        sources.append({"run_dir": run_dir, "plan": plan, "records": records, "attempts": attempts,
                        "shard_index": shard, "plan_sha256": plan_digest,
                        "results_sha256": results_digest, "auxiliary_sha256": auxiliary_digests})
    assert campaign is not None
    expected_shards = set(range(campaign["payload"]["shards"]))
    if not allow_missing_shards and seen_shards != expected_shards:
        raise ValueError(f"missing shards {sorted(expected_shards - seen_shards)}; use --allow-missing-shards for an explicit partial merge")
    sources.sort(key=lambda item: item["shard_index"])
    portable = campaign["payload"]
    # A canonical *derived* serial plan makes the established checked summary and
    # plotting code reusable.  Every source plan and every original record remain
    # available in sources, including their local fingerprints and log paths.
    plan = {
        "schema_version": serial.SCHEMA_VERSION,
        "manifest_path": "campaign-manifest",
        "manifest_sha256": portable["manifest_sha256"],
        "cases": copy.deepcopy(portable["cases"]),
        "solvers": portable["solvers"], "case_policy": portable["case_policy"],
        "eligibility": portable["eligibility"], "jobs": portable["jobs"],
        "seed": portable["seed"], "timeout_seconds": portable["timeout_seconds"],
        "startup_grace_seconds": portable["startup_grace_seconds"],
        "entrypoint": portable["entrypoint"],
        "runtime_command": ["campaign-runtime", *portable["runtime_arguments"]],
        "runtime_identity": portable["runtime_identity"],
        "runtime_executable_sha256": portable["runtime_executable_sha256"],
        "launch_mode": portable["launch_mode"],
        "configuration": portable["configuration"], "configuration_path": "campaign-configuration",
        "configuration_sha256": portable["configuration_sha256"], "code": portable["code"],
        "python_version": portable["python_version"], "runner_platform": portable["runner_platform"],
        "merged_campaign": {
            "fingerprint": campaign["fingerprint"], "shards": portable["shards"],
            "included_shards": sorted(seen_shards), "resource_policy": portable["resource_policy"],
            "sources": [{"shard_index": source["shard_index"],
                         "archive": f"sources/shard-{source['shard_index']:02d}",
                         "local_fingerprint": source["plan"]["fingerprint"],
                         "plan_sha256": source["plan_sha256"],
                         "results_sha256": source["results_sha256"],
                         "auxiliary_sha256": source["auxiliary_sha256"]} for source in sources],
        },
    }
    plan["fingerprint"] = serial.digest_object(plan)
    plan["created_at"] = serial.event_stamp()
    jobs_by_pair = {(job["case_id"], job["solver"]): job for job in campaign["jobs"]}
    records, attempts = [], []
    for source in sources:
        archive = f"sources/shard-{source['shard_index']:02d}"
        for kind, target in (("records", records), ("attempts", attempts)):
            raw_name = "results.jsonl" if kind == "records" else "attempts.jsonl"
            for line, raw in enumerate(source[kind], 1):
                record = copy.deepcopy(raw)
                job = jobs_by_pair[(record["case_id"], record["solver"])]
                record["source_provenance"] = {
                    "shard_index": source["shard_index"], "raw_line": line,
                    "raw_results": f"{archive}/{raw_name}", "source_archive": archive,
                    "fingerprint": record["fingerprint"], "job_key": record["job_key"],
                    "code_fingerprint": record["code_fingerprint"],
                }
                if "source_provenance" in raw:
                    record["source_provenance"]["upstream"] = copy.deepcopy(raw["source_provenance"])
                record["fingerprint"] = plan["fingerprint"]
                record["job_key"] = serial.digest_object({"fingerprint": plan["fingerprint"],
                                                           "case_id": record["case_id"], "solver": record["solver"]})
                record["code_fingerprint"] = serial.digest_object(plan["code"])
                record["global_job_index"] = job["global_job_index"]
                record["campaign_job_key"] = job["campaign_job_key"]
                # Original command/log paths are intentionally untouched.  Their
                # self-contained copied directory is identified by source_archive.
                target.append(record)
    records.sort(key=lambda row: (row["global_job_index"], row["attempt"]))
    attempts.sort(key=lambda row: (row["global_job_index"], row["attempt"]))
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=output_dir.name + ".merging-", dir=output_dir.parent))
    try:
        for source in sources:
            run_dir = source["run_dir"]
            _check_stopped(run_dir)
            target = temporary / "sources" / f"shard-{source['shard_index']:02d}"
            shutil.copytree(run_dir, target)
            if (serial.sha256_file(run_dir / "run_plan.json") != source["plan_sha256"]
                    or serial.sha256_file(run_dir / "results.jsonl") != source["results_sha256"]
                    or serial.sha256_file(target / "run_plan.json") != source["plan_sha256"]
                    or serial.sha256_file(target / "results.jsonl") != source["results_sha256"]):
                raise ValueError("source plan/results changed during merge; stop both runs and retry")
            for name, digest in source["auxiliary_sha256"].items():
                if serial.sha256_file(run_dir / name) != digest or serial.sha256_file(target / name) != digest:
                    raise ValueError(f"source attempt/resource/environment log changed during merge: {name}")
            _check_stopped(run_dir)
        serial.write_json(temporary / "run_plan.json", plan)
        serial.write_json(temporary / "campaign.json", campaign)
        with (temporary / "results.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
            for record in records:
                handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
        with (temporary / "attempts.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
            for record in attempts:
                handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
        summary = summaries.summarize(temporary / "results.jsonl", temporary / "run_plan.json", temporary / "summary")
        memory_attempt_files = sorted(str(path.relative_to(temporary)).replace("\\", "/")
                                     for path in (temporary / "sources").rglob("*")
                                     if path.is_file() and ("attempt" in path.name or "event" in path.name))
        report = {"schema_version": 1, "campaign_fingerprint": campaign["fingerprint"],
                  "fingerprint": plan["fingerprint"], "included_shards": sorted(seen_shards),
                  "raw_records": len(records), "recorded_jobs": len({(r["case_id"], r["solver"]) for r in records}),
                  "raw_attempt_records": len(attempts),
                  "planned_jobs": len(campaign["jobs"]), "violations": summary["violations"],
                  "all_source_logs_archived": True, "attempt_event_files": memory_attempt_files,
                  "missing_results_policy": "not_run; never synthesized as timeout",
                  "resource_attempt_policy": "all raw attempts and source event/job logs retained unchanged"}
        serial.write_json(temporary / "merge_report.json", report)
        temporary.replace(output_dir)
        return report
    except BaseException:
        # This directory is generated solely by this function, never a source run.
        shutil.rmtree(temporary)
        raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", action="append", required=True, type=Path,
                        help="Stopped local run directory; repeat for the second machine")
    parser.add_argument("--output-dir", required=True, type=Path,
                        help="New merged directory; existing directories are never overwritten")
    parser.add_argument("--allow-missing-shards", action="store_true",
                        help="Explicitly permit a partial campaign with an entire shard absent")
    args = parser.parse_args(argv)
    try:
        report = merge_runs(args.run_dir, args.output_dir, args.allow_missing_shards)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if not report["violations"] else 3
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
