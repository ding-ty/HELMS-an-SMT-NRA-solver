"""Check selected manifests and existing exact status evidence; no solver run."""
from collections import Counter
import json
from pathlib import Path
try:
    from . import verify_inputs
except ImportError:
    import verify_inputs

ROOT=Path(__file__).resolve().parents[1]

def read_rows(name):
    return [json.loads(line) for line in (ROOT/'benchmarks'/name).read_text(encoding='utf-8').splitlines() if line.strip()]

def verify():
    full=verify_inputs.verify()
    source=read_rows('experiment_all.jsonl')
    result={}
    for benchmark,expected,tasks in [('RandInst',{'sat':100},800),('SpecInst',{'sat':7,'unsat':14},140)]:
        rows=[r for r in source if r['benchmark_group']==benchmark]
        stem=benchmark.lower()
        if read_rows(f'experiment_{stem}_all.jsonl')!=rows:
            raise ValueError('Selected manifest differs from preserved source: '+benchmark)
        for status in ['sat','unsat']:
            if read_rows(f'experiment_{stem}_{status}.jsonl')!=[r for r in rows if r['expected_status']==status]:
                raise ValueError('Incorrect partition: '+benchmark+' '+status)
        counts=Counter(r['expected_status'] for r in rows)
        if counts!=expected:raise ValueError('Status counts changed: '+benchmark)
        evidence=json.loads((ROOT/'benchmarks/provenance'/('rand_status_certificates.json' if benchmark=='RandInst' else 'spec_status_certificates.json')).read_text(encoding='utf-8'))['records']
        lookup={r['case_id']:r for r in rows}
        if len(evidence)!=len(rows) or len({r['case_id'] for r in evidence})!=len(rows):
            raise ValueError('Missing or duplicate existing status evidence: '+benchmark)
        for record in evidence:
            row=lookup[record['case_id']]
            if record['input_sha256']!=row['input_sha256'] or record['status']!=row['expected_status']:
                raise ValueError('Evidence does not match original input')
        result[benchmark]={'instances':len(rows),'statuses':dict(counts),'eligible_jobs':tasks,
            'status_evidence_methods':dict(Counter(r['evidence_method'] for r in evidence)),
            'input_hashes_verified':True}
    return {'selected_benchmarks':result,'all_original_snapshot_hashes_verified':True,
        'exact_sat_witnesses_verified':full['exact_sat_witnesses_verified'],
        'note':'Prior status evidence is checked, not supplied to the solver. UNSAT evidence is retained; no new UNSAT proof is generated.'}

if __name__=='__main__':print(json.dumps(verify(),ensure_ascii=False,indent=2))
