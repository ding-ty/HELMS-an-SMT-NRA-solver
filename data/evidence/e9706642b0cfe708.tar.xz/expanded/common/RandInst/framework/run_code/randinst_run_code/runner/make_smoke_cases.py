"""Build tiny exact regression inputs; these are NOT experimental benchmarks."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def integer(n: int) -> dict:
    return {"op": "int", "value": str(n)}


def variable(name: str) -> dict:
    return {"op": "var", "name": name}


def add(*args: dict) -> dict:
    return {"op": "add", "args": list(args)}


def power(name: str, n: int) -> dict:
    return {"op": "pow", "base": variable(name), "exponent": n}


def build() -> Path:
    folder = ROOT / "tests" / "smoke_inputs"
    folder.mkdir(exist_ok=True)
    cases = [
        ("sat_linear", ["x", "y"], [add(variable("x"), integer(-1)),
                                    add(variable("y"), integer(-2))], [[[1, 1]], [[2, 1]]], "sat"),
        ("unsat_circle", ["x", "y"], [add(power("x", 2), power("y", 2), integer(1))], [[[1, -1]]], "unsat"),
        ("already_sat", ["x", "y"], [add(power("x", 2), power("y", 2), integer(-1))], [[[1, -1]]], "sat"),
        ("boolean_cnf", ["x", "y", "z"],
         [add(variable("x"), integer(-1)), add(variable("y"), integer(-2)),
          add(variable("z"), integer(2))], [[[1, 1], [2, -1]], [[1, -1], [3, -1]]], "sat"),
        ("partial_ls", ["x", "y", "z", "w"],
         [add(integer(1), {"op": "mul", "args": [integer(-1), variable("x")]}),
          add(variable("y"), integer(-1)), add(variable("z"), integer(-1)),
          add(variable("w"), integer(-1))], [[[1, 1]], [[2, 1]], [[3, 1]], [[4, 1]]], "sat"),
    ]
    manifest = []
    for name, variables, polynomials, clauses, expected in cases:
        target = folder / (name + ".json")
        target.write_text(json.dumps({"variables": variables, "polynomials": polynomials,
                                      "clauses": clauses}, separators=(",", ":")) + "\n", encoding="utf-8")
        digest = hashlib.sha256(target.read_bytes()).hexdigest()
        manifest.append({"case_id": "regression/" + name, "benchmark_group": "Regression",
                         "family": "synthetic-regression", "availability": "ready",
                         "expected_status_hint": expected,
                         "input_path": target.relative_to(ROOT).as_posix(), "input_sha256": digest,
                         "source_path": "runner/make_smoke_cases.py"})
    output = ROOT / "tests" / "smoke_manifest.jsonl"
    output.write_text("".join(json.dumps(row) + "\n" for row in manifest), encoding="utf-8")
    return output


if __name__ == "__main__":
    print(build())
