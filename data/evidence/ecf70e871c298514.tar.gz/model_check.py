"""Exact rational CNF validator. No solver calls, eval, or floating point."""
import ast
from fractions import Fraction
import math

def expression(node, assignment):
    if isinstance(node, str):
        return syntax(ast.parse(node.replace('^','**'), mode='eval').body, assignment)
    op=node['op']
    if op=='int': return Fraction(int(node['value']))
    if op=='rat': return Fraction(int(node['numerator']),int(node['denominator']))
    if op=='var': return assignment[node['name']]
    if op=='add': return sum((expression(a,assignment) for a in node['args']),Fraction(0))
    if op=='mul': return math.prod(expression(a,assignment) for a in node['args'])
    if op=='pow':
        assert isinstance(node['exponent'],int) and node['exponent']>=0
        return expression(node['base'],assignment)**node['exponent']
    raise ValueError('Unsupported polynomial operation: '+op)

def syntax(n,a):
    if isinstance(n,ast.Constant) and type(n.value) is int: return Fraction(n.value)
    if isinstance(n,ast.Name): return a[n.id]
    if isinstance(n,ast.UnaryOp):
        if isinstance(n.op,ast.USub):return -syntax(n.operand,a)
        if isinstance(n.op,ast.UAdd):return syntax(n.operand,a)
    if isinstance(n,ast.BinOp):
        l,r=syntax(n.left,a),syntax(n.right,a)
        if isinstance(n.op,ast.Add):return l+r
        if isinstance(n.op,ast.Sub):return l-r
        if isinstance(n.op,ast.Mult):return l*r
        if isinstance(n.op,ast.Div):return l/r
        if isinstance(n.op,ast.Pow):
            assert r.denominator==1
            return l**int(r)
    raise ValueError('Unsupported expression syntax')

def validate(payload, model):
    assignment={k:expression(v,{}) for k,v in model.items()}
    assert all(v in assignment for v in payload['variables']), 'Incomplete model'
    values=[expression(p,assignment) for p in payload['polynomials']]
    assert all(any(sign*values[index-1]>0 for index,sign in clause) for clause in payload['clauses']), 'False CNF clause'
    return dict(passed=True,variables=len(payload['variables']),polynomials=len(values),clauses=len(payload['clauses']))
