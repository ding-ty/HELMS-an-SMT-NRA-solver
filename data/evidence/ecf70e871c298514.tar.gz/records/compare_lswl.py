#!/usr/bin/env python3
"""Read-only, paired ten-method comparison from immutable raw campaign journals.

No solver is launched. Success-only/derived CSVs are never read. A live journal
is a disclosed byte snapshot; its incomplete last line is ignored, never fixed.
Python 3.10+; standard library only.
"""
from __future__ import annotations

import argparse
import collections
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import sys

ORIGINAL = ("HELMS", "2D-LS", "V1", "V2", "V3", "V4", "V5", "LIMBS", "OpenCAD")
METHODS = (*ORIGINAL, "LS-WL")
NORMAL_STATUSES = {"sat_verified", "sat_unverified", "unsat_reported", "timeout", "memout", "unknown", "error", "adapter_error"}
EXCLUDED_REASONS = {"worker_launch_error", "controller_error", "campaign_deadline", "user_interrupt", "host_memory_pressure", "ancestor_cgroup_pressure"}
FAIR = {"solver_timeout_seconds": 60, "validation_seconds": 10, "attempt_wall_seconds": 75,
        "memory_limit_bytes": 4 * 1024**3, "swap_limit_bytes": 0, "seed": 314159,
        "min_start_workers": 2}
THREAD_KEYS = ("OMP_NUM_THREADS", "OMP_THREAD_LIMIT", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
               "BLIS_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "WOLFRAM_MAX_THREADS")
HASH = re.compile(r"[a-fA-F0-9]{64}\Z")


class AuditError(ValueError):
    pass


def normal_final_attempt(row):
    # Exactly the rule used by the original nine-method controller.
    return row.get("status") in NORMAL_STATUSES and row.get("classification_reason") not in EXCLUDED_REASONS


def encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)


def read_snapshot(path, provenance):
    data = path.read_bytes()
    provenance.append({"path": str(path.resolve()), "snapshot_bytes": len(data),
                       "snapshot_sha256": hashlib.sha256(data).hexdigest()})
    return data


def read_json(path, provenance):
    return json.loads(read_snapshot(path, provenance).decode("utf-8-sig"))


def require_hash(value, description):
    if not isinstance(value, str) or not HASH.fullmatch(value):
        raise AuditError("Missing/invalid SHA-256: " + description)
    return value.lower()


def attempt_metadata(root, row, provenance, evidence):
    """Find portable metadata below attempts/, never follow a copied absolute path."""
    recorded = row.get("raw_directory")
    if not isinstance(recorded, str) or not recorded:
        evidence["missing_attempt_metadata"] += 1
        return
    basename = recorded.replace("\\", "/").rstrip("/").split("/")[-1]
    if basename in {"", ".", ".."}:
        raise AuditError("Unsafe raw_directory basename")
    directory = root / "attempts" / basename
    launch = directory / "launch.json"
    if launch.exists():
        doc = read_json(launch, provenance)
        observed = doc.get("thread_environment")
        if not isinstance(observed, dict) or any(observed.get(k) != "1" for k in THREAD_KEYS):
            raise AuditError(f"Thread policy mismatch: {launch}")
        evidence["checked_launch_thread_policy"] += 1
    else:
        evidence["missing_launch_metadata"] += 1
    cgroup = directory / "cgroup_before.json"
    if cgroup.exists():
        doc = read_json(cgroup, provenance)
        for field, value in (("memory.max", str(FAIR["memory_limit_bytes"])), ("memory.swap.max", "0")):
            if str(doc.get(field, "")).strip() != value:
                raise AuditError(f"Observed resource cap mismatch at {field}: {cgroup}")
        cpus = str(doc.get("cpuset.cpus.effective", "")).strip()
        if not cpus.isdigit():
            raise AuditError(f"Expected exactly one pinned CPU per attempt: {cgroup}")
        evidence["checked_cgroup_caps_and_single_cpu"] += 1
    else:
        evidence["missing_cgroup_metadata"] += 1


def load_campaign(root, expected_methods, provenance):
    identity = read_json(root / "identity.json", provenance)
    profile = read_json(root / "authorized_profile.json", provenance)
    environment = read_json(root / "environment.json", provenance)
    order = read_json(root / "task_order.json", provenance)
    if not all(isinstance(value, dict) for value in (identity, profile, environment)):
        raise AuditError(f"{root}: identity/profile/environment must be JSON objects")
    if not isinstance(order, list) or not order or not all(isinstance(entry, dict) for entry in order):
        raise AuditError(f"{root}: task_order must be a nonempty list of objects")
    for key, value in FAIR.items():
        if profile.get(key) != value or isinstance(profile.get(key), bool):
            raise AuditError(f"{root}: authorized {key} must equal {value!r}; got {profile.get(key)!r}")
    if environment.get("planned_workers") != 2:
        raise AuditError(f"{root}: actual planned worker count is not 2")
    if not isinstance(profile.get("max_workers"), int) or profile["max_workers"] < 2:
        raise AuditError(f"{root}: configured worker ceiling cannot accommodate the observed two workers")
    release = environment.get("os_release", {})
    if not isinstance(release, dict) or release.get("ID") != "ubuntu" or release.get("VERSION_ID") != "24.04":
        raise AuditError(f"{root}: expected observed Ubuntu 24.04 environment")
    manifest = require_hash(identity.get("manifest_sha256"), str(root) + " manifest")
    require_hash(identity.get("source_manifest_sha256"), str(root) + " source manifest")
    require_hash(identity.get("runner_sha256"), str(root) + " runner")
    require_hash(identity.get("worker_sha256"), str(root) + " worker")
    # The config's exact bytes must match the identity recorded at campaign start.
    profile_hash = hashlib.sha256((root / "authorized_profile.json").read_bytes()).hexdigest()
    # authorized_profile.json is a pretty-printed copy, not necessarily original config bytes.
    # Record its hash; never falsely compare it to identity.config_sha256.
    require_hash(identity.get("config_sha256"), str(root) + " original config")
    methods = identity.get("methods", [])
    if not isinstance(methods, list) or not all(isinstance(method, dict) for method in methods):
        raise AuditError(f"{root}: invalid method identity list")
    if {m.get("name") for m in methods} != set(expected_methods) or len(methods) != len(expected_methods):
        raise AuditError(f"{root}: method identities do not match the expected campaign")
    solver_hashes = {m["name"]: require_hash(m.get("solver_sha256"), m["name"] + " solver") for m in methods}
    plan = collections.defaultdict(set)
    case_order = []
    for entry in order:
        case, method = entry.get("case_id"), entry.get("method")
        if not isinstance(case, str) or method not in expected_methods or method in plan[case]:
            raise AuditError(f"{root}: duplicate/invalid task_order entry")
        if not plan[case]:
            case_order.append(case)
        plan[case].add(method)
    if any(value != set(expected_methods) for value in plan.values()):
        raise AuditError(f"{root}: task plan does not contain every expected method for every case")
    if identity.get("cases") != len(plan) or identity.get("total_tasks") != len(order):
        raise AuditError(f"{root}: planned task counts differ from campaign identity")
    raw = read_snapshot(root / "journal.jsonl", provenance)
    lines = raw.splitlines(keepends=True)
    ignored = 0
    if lines and not lines[-1].endswith(b"\n"):
        ignored = len(lines.pop())
    records, identities, path_owners = {}, {}, {}
    ended = False
    versions, systems = set(), set()
    evidence = collections.Counter()
    for number, line in enumerate(lines, 1):
        if not line.strip():
            continue
        event = json.loads(line.decode("utf-8-sig"))
        if not isinstance(event, dict):
            raise AuditError(f"{root}: journal line {number} is not an object")
        if ended:
            raise AuditError(f"{root}: journal has an event after campaign_finished")
        if event.get("event") == "final_integrity_failure":
            raise AuditError(f"{root}: final_integrity_failure is recorded; comparison rejected")
        if event.get("event") == "campaign_finished":
            ended = True
        if event.get("event") != "attempt_finished":
            continue
        row = event.get("result")
        if not isinstance(row, dict):
            raise AuditError(f"{root}: invalid attempt_finished row {number}")
        case, method = row.get("case_id"), row.get("method")
        if case not in plan or method not in plan[case]:
            raise AuditError(f"{root}: result not present in task plan at journal line {number}")
        key = (case, method)
        if key in records:
            raise AuditError(f"{root}: duplicate final attempt for {key}; best-of selection is forbidden")
        path = row.get("original_smt2_path")
        if not isinstance(path, str) or not path:
            raise AuditError(f"{root}: missing original instance path at line {number}")
        instance = (path, require_hash(row.get("input_sha256"), f"{case} input"),
                    require_hash(row.get("source_sha256"), f"{case} source"))
        if case in identities and identities[case] != instance:
            raise AuditError(f"{root}: conflicting original instance identity for {case}")
        if path in path_owners and path_owners[path] != case:
            raise AuditError(f"{root}: original path appears under multiple case IDs")
        if require_hash(row.get("solver_sha256"), f"{method} result solver") != solver_hashes[method]:
            raise AuditError(f"{root}: result solver hash differs from campaign identity")
        identities[case], path_owners[path] = instance, case
        records[key] = {"row": row, "journal_line": number}
        if row.get("kernel_version"):
            versions.add(str(row["kernel_version"]))
        if row.get("system_id"):
            systems.add(str(row["system_id"]))
        attempt_metadata(root, row, provenance, evidence)
    if ignored and ended:
        raise AuditError(f"{root}: incomplete trailing journal bytes after campaign_finished")
    if any(value != "Linux-x86-64" for value in systems):
        raise AuditError(f"{root}: non-Linux-x86-64 worker system observed: {sorted(systems)}")
    if len(versions) > 1:
        raise AuditError(f"{root}: multiple observed Wolfram versions: {sorted(versions)}")
    after = root / "identity_after.json"
    if after.exists():
        final = read_json(after, provenance)
        for key in ("manifest_sha256", "config_sha256", "source_manifest_sha256", "runner_sha256", "worker_sha256"):
            if final.get(key) != identity.get(key):
                raise AuditError(f"{root}: initial/final identity mismatch at {key}")
    elif ended:
        raise AuditError(f"{root}: completed campaign lacks final identity audit")
    return {"root": str(root), "identity": identity, "profile": profile, "environment": environment,
            "manifest": manifest, "records": records, "identities": identities, "plan": dict(plan),
            "case_order": case_order, "finished": ended, "ignored_incomplete_tail_bytes": ignored,
            "observed_kernel_versions": sorted(versions), "observed_system_ids": sorted(systems),
            "attempt_evidence": dict(evidence), "authorized_profile_copy_sha256": profile_hash}


def check_environment(original, lswl):
    differences = []
    for key in ("platform", "wolfram_binary_sha256"):
        a, b = original["environment"].get(key), lswl["environment"].get(key)
        if a is not None and b is not None and a != b:
            differences.append({"field": key, "original": a, "lswl": b})
    a, b = original["observed_kernel_versions"], lswl["observed_kernel_versions"]
    if a and b and a != b:
        differences.append({"field": "observed_kernel_versions", "original": a, "lswl": b})
    if differences:
        raise AuditError("Critical observed environment mismatch: " + encoded(differences))


def csv_write(path, fields, rows):
    with path.open("x", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def compare(original_dir, lswl_dir, output):
    original_dir, lswl_dir, output = (Path(p).expanduser().resolve() for p in (original_dir, lswl_dir, output))
    if output.exists():
        raise AuditError("Refusing existing output directory: " + str(output))
    if (output == original_dir or output == lswl_dir or output in original_dir.parents or output in lswl_dir.parents
            or original_dir in output.parents or lswl_dir in output.parents):
        raise AuditError("Output must be separate from input directories and their ancestors/descendants")
    output.mkdir(parents=True, exist_ok=False)
    provenance = []
    audit = {"created_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(), "ok": False,
             "raw_file_snapshots": provenance,
             "scope_note": "Common complete cases of this one supplied batch only; no whole-BIG evaluation claim. Historical SOTA resource equality is not asserted.",
             "rules": {"required_methods": list(METHODS), "required_profile": FAIR,
                       "normal_statuses": sorted(NORMAL_STATUSES), "excluded_reasons": sorted(EXCLUDED_REASONS),
                       "success_statuses": ["sat_verified", "unsat_reported"],
                       "unsat_reported_is_independent_proof": False,
                       "original_records_modified": False, "unstarted_tasks_count_as_failure": False,
                       "duplicate_attempt_selection": "reject all, never best-of",
                       "required_observed_workers": 2,
                       "full_raw_artifact_hash_audit_performed": False,
                       "live_snapshot_note": "Each source is a separately captured read-only byte snapshot, not an atomic snapshot of a live directory. Partial journal tails are disclosed. No final campaign/input hash audit is implied."}}
    try:
        original = load_campaign(original_dir, ORIGINAL, provenance)
        lswl = load_campaign(lswl_dir, ("LS-WL",), provenance)
        if original["manifest"] != lswl["manifest"]:
            raise AuditError("Original and LS-WL selected manifest SHA-256 differ")
        if set(original["plan"]) != set(lswl["plan"]):
            expected_first89 = set(['bignew-0001', 'bignew-0003', 'bignew-0005', 'bignew-0007', 'bignew-0009', 'bignew-0011', 'bignew-0013', 'bignew-0015', 'bignew-0017', 'bignew-0019', 'bignew-0021', 'bignew-0023', 'bignew-0025', 'bignew-0027', 'bignew-0029', 'bignew-0031', 'bignew-0033', 'bignew-0035', 'bignew-0037', 'bignew-0039', 'bignew-0041', 'bignew-0043', 'bignew-0045', 'bignew-0047', 'bignew-0049', 'bignew-0051', 'bignew-0053', 'bignew-0055', 'bignew-0057', 'bignew-0059', 'bignew-0061', 'bignew-0063', 'bignew-0065', 'bignew-0067', 'bignew-0069', 'bignew-0071', 'bignew-0073', 'bignew-0075', 'bignew-0077', 'bignew-0079', 'bignew-0081', 'bignew-0083', 'bignew-0085', 'bignew-0087', 'bignew-0089', 'bignew-0091', 'bignew-0093', 'bignew-0095', 'bignew-0097', 'bignew-0099', 'bignew-0101', 'bignew-0103', 'bignew-0105', 'bignew-0107', 'bignew-0109', 'bignew-0111', 'bignew-0113', 'bignew-0115', 'bignew-0117', 'bignew-0119', 'bignew-0121', 'bignew-0123', 'bignew-0125', 'bignew-0127', 'bignew-0129', 'bignew-0131', 'bignew-0133', 'bignew-0135', 'bignew-0137', 'bignew-0139', 'bignew-0141', 'bignew-0143', 'bignew-0145', 'bignew-0147', 'bignew-0149', 'bignew-0151', 'bignew-0153', 'bignew-0155', 'bignew-0157', 'bignew-0159', 'bignew-0161', 'bignew-0163', 'bignew-0165', 'bignew-0167', 'bignew-0169', 'bignew-0171', 'bignew-0173', 'bignew-0175', 'bignew-0177'])
            if not (lswl["identity"].get("case_selection") == "batch1-first-per-group-89-v1"
                    and set(lswl["plan"]) == expected_first89
                    and expected_first89.issubset(original["plan"])
                    and len(original["plan"]) == 178):
                raise AuditError("Original and LS-WL planned instance IDs differ outside the frozen first89 subset")
        check_environment(original, lswl)
        for case in original["identities"].keys() & lswl["identities"].keys():
            if original["identities"][case] != lswl["identities"][case]:
                raise AuditError("Original and LS-WL original path/input/source identity mismatch for " + case)
        case_audit, included, excluded = [], [], []
        counts = {m: collections.Counter() for m in METHODS}
        for case in original["case_order"]:
            joined = {m: original["records"].get((case, m)) for m in ORIGINAL}
            joined["LS-WL"] = lswl["records"].get((case, "LS-WL"))
            missing = [m for m, r in joined.items() if r is None]
            abnormal = [m for m, r in joined.items() if r is not None and not normal_final_attempt(r["row"])]
            complete = not missing and not abnormal
            case_audit.append({"case_id": case, "common_complete": complete,
                               "missing_methods": encoded(missing), "abnormal_methods": encoded(abnormal),
                               "original_smt2_path": (original["identities"].get(case) or lswl["identities"].get(case) or (None,))[0]})
            for method, record in joined.items():
                if record is None:
                    continue
                row = dict(record["row"])
                row.update({"source_result_directory": lswl["root"] if method == "LS-WL" else original["root"],
                            "source_journal_line": record["journal_line"], "recorded_result_json": encoded(record["row"])})
                if complete:
                    included.append(row)
                    counts[method][row["status"]] += 1
                else:
                    row["exclusion_note"] = "Case lacks ten normal final attempts; see case_audit.csv"
                    excluded.append(row)
        fields = ["case_id", "method", "group", "original_smt2_path", "input_sha256", "source_sha256", "solver_sha256",
                  "status", "classification_reason", "reported_status", "stage", "kernel_version", "system_id",
                  "solve_seconds", "external_solver_finished_observed_seconds", "attempt_wall_seconds", "validation_seconds",
                  "exit_code", "memory_peak_bytes", "started_at_utc", "finished_at_utc", "raw_directory",
                  "source_result_directory", "source_journal_line", "recorded_result_json"]
        csv_write(output / "common_complete_results.csv", fields, included)
        csv_write(output / "excluded_observations.csv", [*fields, "exclusion_note"], excluded)
        csv_write(output / "case_audit.csv", ["case_id", "original_smt2_path", "common_complete", "missing_methods", "abnormal_methods"], case_audit)
        for label, campaign in (("original", original), ("lswl", lswl)):
            audit[label] = {k: campaign[k] for k in ("root", "finished", "ignored_incomplete_tail_bytes", "observed_kernel_versions", "observed_system_ids", "attempt_evidence", "authorized_profile_copy_sha256")}
            audit[label]["recorded_bundle_identity"] = campaign["identity"]
            audit[label]["authorized_profile"] = campaign["profile"]
        common = len(included) // len(METHODS)
        audit.update({"ok": True, "planned_cases": len(case_audit), "common_complete_cases": common,
                      "excluded_partial_or_unstarted_cases": len(case_audit) - common,
                      "included_observation_rows": len(included), "excluded_observation_rows": len(excluded),
                      "both_campaigns_finished": original["finished"] and lswl["finished"],
                      "per_method": {m: {"status_counts": dict(counts[m]),
                                         "sat_verified": counts[m]["sat_verified"],
                                         "unsat_reported": counts[m]["unsat_reported"],
                                         "solved_reported_or_verified": counts[m]["sat_verified"] + counts[m]["unsat_reported"]} for m in METHODS},
                      "warnings": ["Separate campaigns cannot establish identical transient host load or prove equality of converted CNF and original upstream SMT-LIB.",
                                   "Missing kernel versions (for example killed timeouts) remain unknown; only observed versions are compared.",
                                   "Missing per-attempt metadata is disclosed in attempt_evidence; configured limits alone do not prove every observed enforcement.",
                                   "The first original package allowed up to three workers; this comparison requires observed planned_workers=2 in both campaigns and records each configured ceiling."]})
    except (AuditError, OSError, ValueError, TypeError, KeyError) as error:
        audit["error"] = str(error)
    with (output / "comparison_audit.json").open("x", encoding="utf-8") as stream:
        json.dump(audit, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    return audit


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-results", required=True, type=Path)
    parser.add_argument("--lswl-results", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path, help="New derived-output directory; existing paths refused")
    args = parser.parse_args(argv)
    try:
        result = compare(args.original_results, args.lswl_results, args.output)
    except (AuditError, OSError, ValueError) as error:
        print(encoded({"ok": False, "error": str(error)}), file=sys.stderr)
        return 2
    print(encoded({k: result[k] for k in ("ok", "common_complete_cases", "both_campaigns_finished", "error") if k in result}))
    return 0 if result["ok"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
