#!/usr/bin/env python3
"""Prepare and run only the first ranked case in each of 89 batch1 groups."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent
OVERALL_SECONDS = 72000
STOP_EARLY_SECONDS = 120
SKIP_DIRS = {"inputs", "originals", "smt2", "source", "attempts", "node_modules",
             "prepared", "results", "proc", "sys", "dev"}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_new(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def overlapping(a, b):
    return a == b or a.is_relative_to(b) or b.is_relative_to(a)


def is_controller_process(argv):
    # systemd-run --wait retains the target command in its argv but is a
    # waiting launcher, not another scientific controller.
    if not argv or not re.fullmatch(r"(?:python|pypy)(?:[0-9]+(?:\.[0-9]+)*)?", Path(argv[0]).name):
        return False
    return any(Path(arg).name in {"run_subset.py", "run_lswl.py", "lswl.py"}
               and "run" in argv[i+1:] for i, arg in enumerate(argv[1:], 1))


def refuse_concurrent_experiments():
    """Read /proc only: never stop another experiment or share its two slots."""
    if sys.platform != "linux":
        return
    running = []
    for p in Path("/proc").iterdir():
        if not p.name.isdigit() or int(p.name) == os.getpid():
            continue
        try:
            argv = [s.decode(errors="replace") for s in (p / "cmdline").read_bytes().split(b"\0") if s]
        except OSError:
            continue
        if is_controller_process(argv):
            running.append(p.name)
    if running:
        raise ValueError("Another experiment controller is active (PIDs " + ",".join(running)
                         + "). Finish and save it before running this independent supplement.")


def controller():
    name = "lswl_controller"
    spec = importlib.util.spec_from_file_location(name, ROOT / "runner/run_lswl.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def verify_delivery():
    catalog = read(ROOT / "PACKAGE_INTEGRITY.json")
    for item in catalog["files"]:
        p = (ROOT / item["path"]).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file():
            raise ValueError("Missing/unsafe supplement file: " + item["path"])
        if p.stat().st_size != item["bytes"] or digest(p) != item["sha256"]:
            raise ValueError("Supplement file changed: " + item["path"])
    return catalog


def matches(base, metadata):
    try:
        return all(digest(base / path) == expected for path, expected in metadata["base_files"].items())
    except OSError:
        return False


def discover(metadata, explicit=None):
    if explicit:
        base = explicit.expanduser().resolve()
        if not matches(base, metadata):
            raise ValueError(f"Wrong or changed original package for {metadata['batch']}: {base}")
        return base
    found = set()
    starts = [Path.cwd(), Path("/root/helms-experiments"), Path("/root"), Path("/home"),
              Path("/mnt/d/helms-experiment")]
    visited = set()
    for start in starts:
        if not start.is_dir():
            continue
        for directory, dirs, files in os.walk(start):
            p = Path(directory).resolve()
            depth = len(p.relative_to(start.resolve()).parts)
            if p in visited:
                dirs[:] = []
                continue
            visited.add(p)
            dirs[:] = [d for d in dirs if not d.startswith(".") and d not in SKIP_DIRS] if depth < 5 else []
            if "selected_manifest.jsonl" in files and (p / "inputs").is_dir():
                if matches(p, metadata):
                    found.add(p)
                dirs[:] = []
    if len(found) != 1:
        raise ValueError(f"Need exactly one original {metadata['batch']} package; found {len(found)}: "
                         + ", ".join(map(str, sorted(found)))
                         + f". Supply --{metadata['batch']} /absolute/original/package/path to prepare.")
    return found.pop()


def prepare(args):
    verify_delivery()
    work = args.work.expanduser().resolve()
    if work.exists():
        raise ValueError(f"Refusing existing prepared directory: {work}. Do not repeat prepare after success.")
    metadata = [read(ROOT / f"templates/{b}/metadata.json") for b in ("batch1",)]
    bases = [discover(m, getattr(args, m["batch"])) for m in metadata]
    if any(overlapping(work, base) for base in bases):
        raise ValueError("Prepared stages must be separate from both read-only original packages")
    runtime = controller()
    source_manifest = read(ROOT / "templates/source_manifest.json")
    for entry in source_manifest["files"]:
        if digest(ROOT / "templates" / entry["path"]) != entry["sha256"]:
            raise ValueError("Changed frozen supplemental source")
    for m, base in zip(metadata, bases):
        old = read(base / "source_manifest.json")
        for entry in old["files"]:
            if digest(base / entry["path"]) != entry["sha256"]:
                raise ValueError("Original source changed: " + str(base / entry["path"]))
    work.mkdir(parents=True, exist_ok=False)
    plan = {"schema_version": 1, "created_at_utc": now(), "method": "LS-WL",
            "overall_campaign_seconds": OVERALL_SECONDS,
            "stop_launching_before_overall_deadline_seconds": STOP_EARLY_SECONDS,
            "strict_batch_barrier": True, "batches": [],
            "scope_note": "Supplementary independent observations; never rewrite either nine-method batch. Compare only common complete cases across all ten methods."}
    for m, base in zip(metadata, bases):
        batch = m["batch"]
        selected_count = len(runtime.select_manifest_cases(ROOT / "templates" / batch / "selected_manifest.jsonl", {"case_selection": "batch1-first-per-group-89-v1"}))
        stage = work / batch
        stage.mkdir()
        shutil.copytree(ROOT / "templates/source", stage / "source")
        (stage / "runner").mkdir()
        for name in ("run_lswl.py", "worker.wls"):
            shutil.copyfile(ROOT / "runner" / name, stage / "runner" / name)
        for name in ("selected_manifest.jsonl", "original_config.json", "metadata.json"):
            shutil.copyfile(ROOT / "templates" / batch / name, stage / name)
        shutil.copyfile(ROOT / "templates/source_manifest.json", stage / "source_manifest.json")
        original = read(stage / "original_config.json")
        config = dict(original)
        config.update({
            "profile": f"big-{batch}-lswl-first89-supplement-60s-4gib-v1",
            "case_selection": "batch1-first-per-group-89-v1",
            "max_workers": 2, "min_start_workers": 2,
            "solvers": {"LS-WL": {
                "solver_file": "source/solvers/baseline solvers/LSwolfram.wl",
                "solver_sha256": "93de61ff5a34779270baa56879c9ee281477a215e8a63c87355a09a28bf2885a",
                "config_file": "source/config/lswl_config.json",
                "config_sha256": "5d48e3a2b476c4986f34ce896b925f453c88c87050c496b70628660af7e26fa7"}},
            "worker_sha256": digest(stage / "runner/worker.wls"),
            "source_manifest_sha256": digest(stage / "source_manifest.json"),
            "input_semantics": "Same hash-pinned provided converted strict CNF as original batch; original converted snapshots retained. Equivalence to upstream SMT-LIB is not established by this supplement.",
            "input_bundle_reference": {"root": str(base),
                "manifest_sha256": m["base_files"]["selected_manifest.jsonl"]},
            "input_verification_strategy": runtime.INPUT_VERIFICATION_STRATEGY,
            "supplement_case_order": "manifest" if batch == "batch1" else "group_round_robin",
            "supplement": {"original_package": str(base), "original_frozen_identity": m,
                "additional_public_loader": "LSwolfram.wl, exact original artifact manifest entry",
                "concurrency_note": "Two independent single-core LS-WL instances; methods are measured in separate campaigns, not simultaneously with the original nine-method run.",
                "paired_comparison": "Use compare_lswl.py and keep all ten methods on common complete cases, including failures."},
        })
        config["scope"] = {**original["scope"], "selected": selected_count, "method_count": 1, "tasks": selected_count}
        config.pop("baseline_implementation_notes", None)
        config["schedule"] = {"case_order": config["supplement_case_order"],
            "parallelism": "two independent single-core cases; launch order fixed; completion order may differ",
            "retain_all_raw_and_partial_cases": True}
        write_new(stage / "config.json", config)
        plan["batches"].append({"batch": batch, "stage": batch, "cases": selected_count, "parent_cases": m["cases"],
            "case_selection": config["case_selection"],
            "original_package": str(base), "manifest_sha256": digest(stage / "selected_manifest.jsonl"),
            "config_sha256": digest(stage / "config.json"), "controller_sha256": digest(stage / "runner/run_lswl.py")})
    write_new(work / "plan.json", plan)
    print(json.dumps(plan, ensure_ascii=False, indent=2))
    print("Preparation finished. No solver was started. Keep the original batch1 input directory in place.")
    return 0


def checked_plan(work):
    verify_delivery()
    plan = read(work / "plan.json")
    if [(b["batch"], b["cases"]) for b in plan["batches"]] != [("batch1", 89)]:
        raise ValueError("Expected only batch1, exactly 89 cases")
    for b in plan["batches"]:
        stage = work / b["stage"]
        for name, field in (("config.json", "config_sha256"), ("selected_manifest.jsonl", "manifest_sha256"),
                            ("runner/run_lswl.py", "controller_sha256")):
            if digest(stage / name) != b[field]:
                raise ValueError(f"Prepared identity changed: {stage / name}")
        if digest(stage / "runner/run_lswl.py") != digest(ROOT / "runner/run_lswl.py"):
            raise ValueError("Prepared controller differs from delivered controller")
    return plan


def run(args):
    work = args.work.expanduser().resolve()
    plan = checked_plan(work)
    output = args.output.expanduser().resolve()
    if overlapping(output, work):
        raise ValueError("Results must be separate from prepared stages, including their parent directory")
    if output.exists():
        raise ValueError("Refusing to overwrite existing results: " + str(output))
    for b in plan["batches"]:
        base = Path(b["original_package"])
        stage = work / b["stage"]
        for protected in (base, stage):
            if output == protected or output in protected.parents or output.is_relative_to(protected):
                raise ValueError("Results must be separate from original inputs and prepared stages")
    refuse_concurrent_experiments()
    output.mkdir(parents=True, exist_ok=False)
    shutil.copytree(work, output / "prepared_provenance", ignore=shutil.ignore_patterns("__pycache__"))
    for name in ("lswl.py", "compare_lswl.py", "PACKAGE_INTEGRITY.json"):
        shutil.copyfile(ROOT / name, output / name)
    write_new(output / "plan.json", plan)
    start = time.monotonic()
    control = {"requested": False, "reason": None}
    active_stop_file = [None]
    log = output / "orchestration.jsonl"

    def event(value):
        with log.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"at_utc": now(), **value}, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())

    def request_stop(reason):
        if not control["requested"]:
            control.update(requested=True, reason=reason)
            event({"event": "stop_requested", "reason": reason})
            print("Stop requested: no new instances will launch; current attempts will finish normally.", flush=True)
        if active_stop_file[0] is not None:
            active_stop_file[0].touch(exist_ok=True)

    def on_signal(signum, frame):
        request_stop("user_signal_" + str(signum))

    previous = {s: signal.signal(s, on_signal) for s in (signal.SIGINT, signal.SIGTERM)}
    completed_batches = []
    exit_code = 2
    process = None
    thread = None
    event({"event": "supplement_started", "overall_campaign_seconds": OVERALL_SECONDS,
           "time_origin": "before first batch controller startup; includes its input audit and both batches"})
    try:
        for b in plan["batches"]:
            if control["requested"]:
                break
            if time.monotonic() - start >= OVERALL_SECONDS - STOP_EARLY_SECONDS:
                request_stop("overall_campaign_deadline")
                break
            stage = work / b["stage"]
            batch_output = output / b["batch"]
            stop_file = output / (b["batch"] + "_STOP_REQUESTED")
            active_stop_file[0] = stop_file
            argv = [sys.executable, "-u", str(stage / "runner/run_lswl.py"), "--package", str(stage),
                    "run", "--wolfram-command", args.wolfram_command,
                    "--output", str(batch_output), "--stop-file", str(stop_file)]
            if args.cgroup_parent:
                argv += ["--cgroup-parent", args.cgroup_parent]
            event({"event": "batch_starting", "batch": b["batch"], "argv": argv})
            print(f"Starting {b['batch']}: {b['cases']} LS-WL tasks. Initial full input audit may be quiet.", flush=True)
            process = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       start_new_session=True)
            reader_errors = []

            def reader():
                try:
                    with (output / (b["batch"] + "_console.log")).open("xb") as stream:
                        for line in iter(process.stdout.readline, b""):
                            stream.write(line)
                            stream.flush()
                            print(line.decode("utf-8", errors="replace"), end="", flush=True)
                except BaseException as error:
                    reader_errors.append(repr(error))
                finally:
                    process.stdout.close()

            thread = threading.Thread(target=reader, daemon=True)
            thread.start()
            while process.poll() is None:
                if (output / "STOP_REQUESTED").exists():
                    request_stop("stop_file")
                if time.monotonic() - start >= OVERALL_SECONDS - STOP_EARLY_SECONDS:
                    request_stop("overall_campaign_deadline")
                if reader_errors:
                    request_stop("console_recording_error")
                time.sleep(.25)
            thread.join()
            active_stop_file[0] = None
            code = process.returncode
            write_new(output / (b["batch"] + "_exit_code.json"), {"exit_code": code, "reader_errors": reader_errors})
            summary_path = batch_output / "summary.json"
            summary = read(summary_path) if summary_path.is_file() else None
            event({"event": "batch_finished", "batch": b["batch"], "exit_code": code, "summary": summary})
            if code != 0 or not summary or not summary.get("completed") or reader_errors:
                # Never start batch 2 after an incomplete/error/interrupt batch 1.
                break
            completed_batches.append(b["batch"])
        if len(completed_batches) == len(plan["batches"]) and not control["requested"]:
            exit_code = 0
    finally:
        # An unexpected parent-side exception must not orphan a solver campaign.
        # The ordinary stop path uses the file so current attempts keep their
        # normal time budget. SIGINT is only a fallback if that file cannot be made.
        if process is not None and process.poll() is None:
            try:
                active_stop_file[0].touch(exist_ok=True)
            except (OSError, AttributeError):
                process.send_signal(signal.SIGINT)
            print("Waiting for child controller to save records and finish its integrity audit.", flush=True)
            process.wait()
            if thread is not None:
                thread.join()
        for s, handler in previous.items():
            signal.signal(s, handler)
        summary = {"finished_at_utc": now(), "elapsed_wall_seconds": time.monotonic() - start,
                   "completed_batches": completed_batches, "stop_request": control,
                   "exit_code": exit_code, "all_planned_tasks_final": exit_code == 0,
                   "scope_note": "All final attempts does not mean all instances solved. Use common-case ten-method comparison; retain timeout/error/unknown and all raw logs."}
        write_new(output / "supplement_summary.json", summary)
        event({"event": "supplement_finished", **summary})
    print("Results directory: " + str(output), flush=True)
    return exit_code


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    s = p.add_subparsers(dest="action", required=True)
    q = s.add_parser("prepare", help="Read-only original package identity check; create independent stages")
    q.add_argument("--batch1", type=Path)
    q.add_argument("--work", type=Path, default=ROOT / "prepared")
    q = s.add_parser("run", help="Run only 89 LS-WL batch1 cases, 20h cap, graceful stop")
    q.add_argument("--work", type=Path, default=ROOT / "prepared")
    q.add_argument("--output", type=Path, required=True)
    q.add_argument("--wolfram-command", default="/usr/local/bin/math")
    q.add_argument("--cgroup-parent")
    args = p.parse_args(argv)
    try:
        return prepare(args) if args.action == "prepare" else run(args)
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
