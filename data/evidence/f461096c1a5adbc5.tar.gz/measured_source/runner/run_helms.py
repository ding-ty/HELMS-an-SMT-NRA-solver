#!/usr/bin/env python3
"""Independent HELMS with bounded CAD handoff; one 1200-second solve budget per attempt."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from protocols import safe


def check_package():
    inventory = json.loads((ROOT / 'PACKAGE_SHA256.json').read_bytes())
    for relative, expected in inventory['files'].items():
        path = ROOT / relative
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError('Package file missing or changed: ' + relative)
    config = json.loads((ROOT / 'config/run_config.json').read_bytes())
    if (config['worker'].get('max_restart_stage1'), config['worker'].get('max_restart_stage2')) != (1, 3):
        raise ValueError('HELMS requires stage restart limits 1 and 3')


def controller_arguments(args):
    benchmark = args.benchmark.lower()
    output = (args.output_dir or ROOT / 'results' / ('helms_cad_handoff_' + benchmark)).resolve()
    if output == ROOT.resolve():
        raise ValueError('Output must be separate from the package root')
    for name in ('benchmarks', 'components', 'config', 'solvers', 'runner', 'scripts'):
        protected = (ROOT / name).resolve()
        if output == protected or protected in output.parents:
            raise ValueError('Output must not overwrite package files')
    argv = ['run', '--manifest', str(ROOT / 'benchmarks' / ('experiment_' + benchmark + '.jsonl')),
            '--config', str(ROOT / 'config/run_config.json'), '--solvers', 'HELMS',
            '--shards', '1', '--shard-index', '0', '--workers', '1',
            '--output-dir', str(output), '--timeout', '1200', '--startup-grace', '60',
            '--seed', '314159', '--commit-budget-gib', '8', '--reserve-commit-gib', '4',
            '--reserve-ram-gib', '4', '--pressure-available-gib', '2',
            '--poll-seconds', '0.25', '--max-resource-retries', '0']
    if args.wolfram_command:
        argv += ['--wolfram-command', args.wolfram_command]
    if args.resume:
        argv += ['--resume']
    if args.dry_run:
        argv += ['--dry-run']
    if args.plan_only:
        argv += ['--plan-only']
    for case in args.case_id or []:
        argv += ['--case-id', case]
    return argv


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--benchmark', choices=['All', 'SMTLIB', 'RandInst', 'SpecInst'], default='All')
    parser.add_argument('--wolfram-command', help='Activated Mathematica 14.0 console kernel')
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--plan-only', action='store_true')
    parser.add_argument('--case-id', action='append', help='Exact case ID for a small diagnostic')
    args = parser.parse_args(argv)
    if not args.dry_run and (os.name != 'nt' or sys.maxsize <= 2**32):
        parser.error('Use native 64-bit Windows Python 3.10 or newer')
    if not args.dry_run and not args.wolfram_command:
        parser.error('--wolfram-command is required unless --dry-run is used')
    check_package()
    print('HELMS only; stage restart limits 1/3; total solve budget 1200 seconds per attempt.', flush=True)
    return safe.main(controller_arguments(args))


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError) as exc:
        print('ERROR: ' + str(exc), file=sys.stderr)
        raise SystemExit(2)
