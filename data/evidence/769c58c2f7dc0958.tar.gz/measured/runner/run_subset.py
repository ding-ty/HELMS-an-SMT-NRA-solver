#!/usr/bin/env python3
"""Immutable-attempt runner for the separately selected BIG evaluation.

Python 3.10+, stdlib only.  `verify` is portable and read-only.  `preflight`
is also read-only; `run` requires Ubuntu 24.04 and a writable cgroup-v2
delegation with the memory and cpuset controllers.  No solver is executed
by verify or preflight.  Every actual attempt uses a fresh Wolfram kernel.

Raw requests, worker outputs, and journal/resource observations are retained.
Only results.csv and summary.json are derived, replaceable views.  There is
no resume, retry, best-of selection, expected-status filtering, or correction
of missing/negative timings in this program.
"""

from __future__ import annotations

import argparse
import collections
import csv
import dataclasses
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import subprocess
import sys
import time
import uuid
from typing import Any

GIB = 1024 ** 3
METHODS = ("HELMS", "2D-LS", "V1", "V2", "V3", "V4", "V5", "LIMBS", "OpenCAD")
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,119}\Z")
SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")
VAR = re.compile(r"pilotx[1-9][0-9]*\Z")
POLY_TOKEN = re.compile(r"pilotx[1-9][0-9]*|[0-9]+|[+*/^()\-\s]")
RAW_STATUSES = {"sat_verified", "sat_unverified", "unsat_reported", "timeout", "unknown", "error", "adapter_error"}
THREAD_ENV = {
    "OMP_NUM_THREADS": "1", "OMP_THREAD_LIMIT": "1", "MKL_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1", "BLIS_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1",
    "VECLIB_MAXIMUM_THREADS": "1", "WOLFRAM_MAX_THREADS": "1",
}


class AuditError(RuntimeError):
    pass


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as stream:
        return json.load(stream)


def write_new_json(path: Path, value: Any) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def replace_json(path: Path, value: Any) -> None:
    temporary = path.with_suffix(path.suffix + ".new")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def append_json(path: Path, value: Any, *, sync: bool = True) -> None:
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")) + "\n")
        stream.flush()
        if sync:
            os.fsync(stream.fileno())


def package_path(root: Path, text: str) -> Path:
    """Reject host-specific paths and escapes in the portable bundle."""
    if not isinstance(text, str) or not text or "\\" in text:
        raise AuditError(f"Expected a nonempty portable relative path: {text!r}")
    path = (root / text).resolve()
    if Path(text).is_absolute() or not path.is_relative_to(root):
        raise AuditError(f"Bundle path escapes package: {text!r}")
    if not path.is_file():
        raise AuditError(f"Required bundle file does not exist: {path}")
    return path


def checked_hash(path: Path, expected: str, label: str) -> str:
    if not isinstance(expected, str) or not SHA256.fullmatch(expected):
        raise AuditError(f"{label}: missing/invalid SHA-256")
    actual = sha256(path)
    if actual != expected.lower():
        raise AuditError(f"{label}: SHA-256 mismatch ({actual} != {expected})")
    return actual


@dataclasses.dataclass(frozen=True)
class Method:
    name: str
    solver_file: Path
    solver_sha256: str
    config_file: Path | None = None
    config_sha256: str | None = None


def verify_source_tree(root: Path, config: dict) -> dict:
    manifest_path = package_path(root, config.get("source_manifest"))
    digest = checked_hash(manifest_path, config.get("source_manifest_sha256"), "source manifest")
    document = read_json(manifest_path)
    entries = document.get("files") if isinstance(document, dict) else None
    if not isinstance(entries, list) or not entries:
        raise AuditError("Source manifest must contain a nonempty files list")
    declared = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise AuditError("Invalid source manifest entry")
        relative = entry.get("path")
        if not isinstance(relative, str) or not relative.startswith("source/") or relative in declared:
            raise AuditError("Source manifest has a duplicate path or a path outside source/")
        path = package_path(root, relative)
        checked_hash(path, entry.get("sha256"), "source dependency " + relative)
        if "bytes" in entry and path.stat().st_size != entry["bytes"]:
            raise AuditError("Source dependency byte-size mismatch: " + relative)
        declared.add(relative)
    actual = set()
    for path in (root / "source").rglob("*"):
        if path.is_symlink():
            raise AuditError("Source snapshot must not contain symbolic links")
        if path.is_file():
            actual.add(path.relative_to(root).as_posix())
    if declared != actual:
        raise AuditError(f"Source manifest does not exactly cover source/: missing={sorted(actual-declared)}, stale={sorted(declared-actual)}")
    return {"source_manifest": config["source_manifest"], "source_manifest_sha256": digest,
            "source_files": len(declared), "release_commit": document.get("release_commit")}


def load_bundle(root: Path) -> tuple[dict, list[dict], list[Method], dict]:
    root = root.resolve()
    config_path = root / "config.json"
    config = read_json(config_path)
    if not isinstance(config, dict):
        raise AuditError("config.json must contain an object")
    # These caps are the authorized profile, shared by every method.
    required = {
        "solver_timeout_seconds": 60, "validation_seconds": 10,
        "attempt_wall_seconds": 75, "campaign_seconds": 72000,
        "stop_launching_before_deadline_seconds": 120,
        "memory_limit_bytes": 4 * GIB, "seed": 314159,
        "max_workers": 3, "min_start_workers": 2,
    }
    for key, expected in required.items():
        if config.get(key) != expected:
            raise AuditError(f"config.{key} must be {expected!r} for this authorized profile")
    for key, expected in (("reserve_ram_gib", 3.0), ("admission_headroom_gib", 1.5), ("poll_seconds", .1)):
        if config.get(key) != expected:
            raise AuditError(f"config.{key} must be {expected}")
    source_identity = verify_source_tree(root, config)
    solver_defs = config.get("solvers")
    if not isinstance(solver_defs, dict) or set(solver_defs) != set(METHODS):
        raise AuditError("config.solvers must map precisely " + ", ".join(METHODS))
    methods: list[Method] = []
    for name in METHODS:
        item = solver_defs[name]
        if not isinstance(item, dict):
            raise AuditError(f"config.solvers[{name!r}] must contain solver_file and solver_sha256")
        solver = package_path(root, item.get("solver_file"))
        solver_digest = checked_hash(solver, item.get("solver_sha256"), name)
        method_config = None
        config_digest = None
        if item.get("config_file") is not None:
            method_config = package_path(root, item["config_file"])
            config_digest = checked_hash(method_config, item.get("config_sha256"), name + " config")
        methods.append(Method(name, solver, solver_digest, method_config, config_digest))
    worker = package_path(root, "runner/worker.wls")
    worker_digest = checked_hash(worker, config.get("worker_sha256"), "worker.wls")
    manifest_path = root / "selected_manifest.jsonl"
    cases: list[dict] = []
    ids: set[str] = set()
    paths: set[str] = set()
    for line_number, line in enumerate(manifest_path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        case = json.loads(line)
        if not isinstance(case, dict):
            raise AuditError(f"Manifest line {line_number} is not an object")
        case_id = case.get("case_id")
        if not isinstance(case_id, str) or not IDENTIFIER.fullmatch(case_id) or case_id in ids:
            raise AuditError(f"Manifest has invalid/duplicate case_id: {case_id!r}")
        original = case.get("original_smt2_path")
        if not isinstance(original, str) or not original or original in paths:
            raise AuditError(f"Manifest has missing/duplicate original_smt2_path for {case_id}")
        if not isinstance(case.get("group"), str) or not case["group"]:
            raise AuditError(f"Manifest has no group for {case_id}")
        if "expected_status" in case:
            raise AuditError("This new-corpus runner refuses expected-status filtering metadata")
        payload_path = package_path(root, case.get("input_path"))
        checked_hash(payload_path, case.get("input_sha256"), case_id + " input")
        if not isinstance(case.get("source_sha256"), str) or not SHA256.fullmatch(case["source_sha256"]):
            raise AuditError(f"{case_id}: missing source_sha256")
        payload = read_json(payload_path)
        for field in ("case_id", "group", "original_smt2_path", "source_sha256"):
            if payload.get(field) != case[field]:
                raise AuditError(f"{case_id}: payload/manifest mismatch at {field}")
        validate_payload(payload, case_id)
        if case.get("source_path"):
            source = package_path(root, case["source_path"])
            checked_hash(source, case["source_sha256"], case_id + " source snapshot")
        ids.add(case_id)
        paths.add(original)
        cases.append(case)
    if not cases:
        raise AuditError("No selected cases")
    identity = {
        "verified_at_utc": utc_now(), "package": str(root),
        "config_sha256": sha256(config_path), "manifest_sha256": sha256(manifest_path),
        "runner_sha256": sha256(Path(__file__).resolve()), "worker_sha256": worker_digest,
        **source_identity,
        "cases": len(cases), "groups": len({c["group"] for c in cases}),
        "methods": [dataclasses.asdict(m) for m in methods],
        "total_tasks": len(cases) * len(methods),
        "input_semantics": "Provided converted strict CNF; original SMT-LIB conversion equivalence is not independently established by this runner.",
    }
    for item in identity["methods"]:
        item["solver_file"] = str(item["solver_file"].relative_to(root))
        if item["config_file"] is not None:
            item["config_file"] = str(item["config_file"].relative_to(root))
    return config, cases, methods, identity


def validate_payload(payload: dict, case_id: str) -> None:
    variables = payload.get("variables")
    polynomials = payload.get("polynomials")
    clauses = payload.get("clauses")
    if not isinstance(variables, list) or any(not isinstance(v, str) or not VAR.fullmatch(v) for v in variables):
        raise AuditError(f"{case_id}: unsafe/missing mapped variable names")
    if len(variables) != len(set(variables)):
        raise AuditError(f"{case_id}: duplicate variables")
    varset = set(variables)
    if not isinstance(polynomials, list) or not all(isinstance(p, str) and p for p in polynomials):
        raise AuditError(f"{case_id}: invalid polynomial strings")
    for polynomial in polynomials:
        cursor = 0
        for token in POLY_TOKEN.finditer(polynomial):
            if token.start() != cursor:
                raise AuditError(f"{case_id}: unapproved polynomial token")
            value = token.group()
            if value.startswith("pilotx") and value not in varset:
                raise AuditError(f"{case_id}: polynomial uses unmapped variable")
            cursor = token.end()
        if cursor != len(polynomial):
            raise AuditError(f"{case_id}: unapproved polynomial token")
    if not isinstance(clauses, list):
        raise AuditError(f"{case_id}: invalid pair CNF")
    for clause in clauses:
        if not isinstance(clause, list):
            raise AuditError(f"{case_id}: invalid clause")
        for literal in clause:
            if (not isinstance(literal, list) or len(literal) != 2 or
                type(literal[0]) is not int or not 1 <= literal[0] <= len(polynomials) or
                type(literal[1]) is not int or literal[1] not in (-1, 1)):
                raise AuditError(f"{case_id}: invalid polynomial index/sign")


def parse_cpu_list(value: str) -> set[int]:
    result: set[int] = set()
    for chunk in value.strip().split(","):
        if not chunk:
            continue
        if "-" in chunk:
            left, right = map(int, chunk.split("-", 1))
            result.update(range(left, right + 1))
        else:
            result.add(int(chunk))
    return result


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8").strip()


def parse_key_values(text: str) -> dict[str, int]:
    values: dict[str, int] = {}
    for line in text.splitlines():
        key, value = line.split()[:2]
        values[key] = int(value)
    return values


def meminfo() -> dict[str, int]:
    result = {}
    for line in Path("/proc/meminfo").read_text().splitlines():
        key, rest = line.split(":", 1)
        fields = rest.split()
        result[key] = int(fields[0]) * (1024 if len(fields) > 1 and fields[1] == "kB" else 1)
    if "MemAvailable" not in result:
        raise AuditError("/proc/meminfo has no MemAvailable; refusing to guess available memory")
    return result


def cgroup_mount() -> Path:
    for line in Path("/proc/self/mountinfo").read_text().splitlines():
        left, separator, right = line.partition(" - ")
        if separator and right.split()[0] == "cgroup2":
            fields = left.split()
            # mountinfo uses octal escapes for whitespace; support these without shell parsing.
            name = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m[1], 8)), fields[4])
            return Path(name).resolve()
    raise AuditError("Unified cgroup v2 is not mounted")


def current_cgroup(mount: Path) -> Path:
    for line in Path("/proc/self/cgroup").read_text().splitlines():
        if line.startswith("0::"):
            path = (mount / line[3:].lstrip("/")).resolve()
            if path.is_relative_to(mount) and (path / "cgroup.procs").is_file():
                return path
    raise AuditError("Cannot resolve current cgroup under the cgroup-v2 mount")


def ancestor_memory(parent: Path, mount: Path) -> list[dict]:
    """Limits AND current usage at every visible ancestor, not host RAM alone."""
    rows = []
    path = parent
    while True:
        max_file = path / "memory.max"
        current_file = path / "memory.current"
        if max_file.is_file() and current_file.is_file():
            maximum = read_text(max_file)
            current = int(read_text(current_file))
            limit = None if maximum == "max" else int(maximum)
            rows.append({"path": str(path), "memory_max": limit, "memory_current": current,
                         "headroom": None if limit is None else max(0, limit - current)})
        if path == mount:
            return rows
        path = path.parent
        if not path.is_relative_to(mount):
            raise AuditError("Cgroup ancestry escaped its mount")


def memory_snapshot(parent: Path, mount: Path) -> dict:
    host = meminfo()
    ancestors = ancestor_memory(parent, mount)
    available = min([host["MemAvailable"]] + [a["headroom"] for a in ancestors if a["headroom"] is not None])
    return {"host_mem_available": host["MemAvailable"], "host_mem_total": host["MemTotal"],
            "host_swap_total": host.get("SwapTotal"), "host_swap_free": host.get("SwapFree"),
            "ancestor_limits": ancestors, "effective_available": available}


def physical_cpu_representatives(parent: Path) -> tuple[list[int], list[dict]]:
    allowed = set(os.sched_getaffinity(0))
    effective = parent / "cpuset.cpus.effective"
    if not effective.is_file():
        raise AuditError("Parent cgroup has no cpuset.cpus.effective")
    allowed &= parse_cpu_list(read_text(effective))
    cores: dict[tuple[int, int], list[int]] = {}
    rows = []
    for cpu in sorted(allowed):
        topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        # Fail closed rather than silently allocate two SMT siblings.
        package_id = int(read_text(topology / "physical_package_id"))
        core_id = int(read_text(topology / "core_id"))
        siblings = sorted(parse_cpu_list(read_text(topology / "thread_siblings_list")))
        if cpu not in siblings:
            raise AuditError(f"Invalid physical topology for CPU {cpu}")
        cores.setdefault((package_id, core_id), []).append(cpu)
        rows.append({"cpu": cpu, "package_id": package_id, "core_id": core_id, "siblings": siblings})
    representatives = [min(group) for _, group in sorted(cores.items())]
    for index, cpu in enumerate(representatives):
        siblings = next(set(r["siblings"]) for r in rows if r["cpu"] == cpu)
        if siblings.intersection(representatives[index + 1:]):
            raise AuditError("Physical-core representatives contain SMT siblings")
    return representatives, rows


def resolve_command(command: str) -> Path:
    executable = shutil.which(command)
    if executable is None:
        candidate = Path(command).expanduser()
        if candidate.is_file():
            executable = str(candidate)
    if executable is None:
        raise AuditError(f"Wolfram command not found: {command!r}")
    path = Path(executable).resolve()
    if not os.access(path, os.X_OK):
        raise AuditError(f"Wolfram command is not executable: {path}")
    return path


def preflight(root: Path, config: dict, command: str, parent_text: str | None) -> dict:
    if sys.platform != "linux":
        raise AuditError("Execution/preflight requires Ubuntu 24.04 Linux with cgroup v2; use verify on this OS")
    release = {}
    for line in Path("/etc/os-release").read_text().splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            release[key] = value.strip('"')
    if release.get("ID") != "ubuntu" or release.get("VERSION_ID") != "24.04":
        raise AuditError(f"Authorized target is Ubuntu 24.04; observed {release.get('PRETTY_NAME', release)}")
    mount = cgroup_mount()
    parent = Path(parent_text).expanduser().resolve() if parent_text else current_cgroup(mount)
    if not parent.is_relative_to(mount) or not (parent / "cgroup.controllers").is_file():
        raise AuditError("--cgroup-parent must be a cgroup-v2 directory under its mounted hierarchy")
    if read_text(parent / "cgroup.type") != "domain":
        raise AuditError("Memory enforcement requires a domain cgroup parent")
    controllers = set(read_text(parent / "cgroup.controllers").split())
    enabled = set(read_text(parent / "cgroup.subtree_control").split())
    if not {"memory", "cpuset"}.issubset(controllers | enabled):
        raise AuditError("Parent delegation does not expose both memory and cpuset controllers")
    need_enable = {"memory", "cpuset"} - enabled
    if need_enable and read_text(parent / "cgroup.procs"):
        raise AuditError("Parent contains processes and lacks enabled controllers; provide an empty delegated cgroup parent")
    if not os.access(parent, os.W_OK) or (need_enable and not os.access(parent / "cgroup.subtree_control", os.W_OK)):
        raise AuditError("Cgroup parent is not writable/delegated to this user; no solver was started")
    cpus, topology = physical_cpu_representatives(parent)
    memory = memory_snapshot(parent, mount)
    reserve = int(config["reserve_ram_gib"] * GIB)
    possible = max(0, (memory["effective_available"] - reserve) // config["memory_limit_bytes"])
    slots = min(config["max_workers"], len(cpus), possible)
    if slots < config["min_start_workers"]:
        raise AuditError(f"Only {slots} protected workers fit available RAM/ancestor cgroups/physical cores; need at least {config['min_start_workers']}")
    executable = resolve_command(command)
    return {"preflight_at_utc": utc_now(), "read_only": True,
            "os_release": release, "platform": platform.platform(), "python": sys.version,
            "cgroup_mount": str(mount), "cgroup_parent": str(parent),
            "controllers": sorted(controllers), "enabled_controllers": sorted(enabled),
            "controllers_to_enable_at_run": sorted(need_enable),
            "effective_memory": memory, "planned_workers": slots,
            "physical_cpu_representatives": cpus[:slots], "allowed_cpu_topology": topology,
            "wolfram_command": str(executable), "wolfram_binary_sha256": sha256(executable),
            "wolfram_version": "not executed by read-only preflight; each worker must record actual version",
            "cgroup_write_enforcement": "will be round-trip verified by run before any kernel starts"}


def cg_write(path: Path, value: str, *, exact: bool = True) -> None:
    with path.open("w", encoding="ascii") as stream:
        stream.write(value)
    if exact and read_text(path) != value:
        raise AuditError(f"Cgroup control did not retain required value: {path}")


def cgroup_snapshot(path: Path) -> dict:
    sample: dict[str, Any] = {"path": str(path)}
    for name in ("memory.current", "memory.peak", "memory.events", "memory.events.local", "memory.stat",
                 "memory.pressure", "memory.max", "memory.swap.max", "memory.swap.current",
                 "memory.oom.group", "cpuset.cpus", "cpuset.cpus.effective", "cpuset.mems.effective",
                 "cgroup.events", "cgroup.procs", "pids.current", "cpu.stat"):
        file = path / name
        if file.is_file():
            text = read_text(file)
            sample[name] = text
    return sample


def cgroup_event_counts(sample: dict) -> dict[str, int]:
    return parse_key_values(sample.get("memory.events", ""))


def make_campaign_cgroup(environment: dict, config: dict, tag: str) -> Path:
    parent = Path(environment["cgroup_parent"])
    for controller in environment["controllers_to_enable_at_run"]:
        # This is the explicit delegated hierarchy only; never move or kill unrelated PIDs.
        cg_write(parent / "cgroup.subtree_control", "+" + controller, exact=False)
    if not {"memory", "cpuset"}.issubset(set(read_text(parent / "cgroup.subtree_control").split())):
        raise AuditError("Failed to enable delegated memory/cpuset controllers")
    campaign = parent / ("helms-big-" + tag)
    campaign.mkdir()
    try:
        cg_write(campaign / "cpuset.mems", read_text(parent / "cpuset.mems.effective"))
        cg_write(campaign / "cpuset.cpus", ",".join(map(str, environment["physical_cpu_representatives"])), exact=False)
        if parse_cpu_list(read_text(campaign / "cpuset.cpus")) != set(environment["physical_cpu_representatives"]):
            raise AuditError("Campaign cpuset did not retain its required physical-core representatives")
        aggregate = environment["planned_workers"] * config["memory_limit_bytes"]
        # The collective hard cap never undercuts N * the per-attempt cap.
        cg_write(campaign / "memory.max", str(aggregate))
        cg_write(campaign / "memory.swap.max", "0")
        cg_write(campaign / "memory.oom.group", "1")
        cg_write(campaign / "cgroup.subtree_control", "+memory +cpuset", exact=False)
        if not {"memory", "cpuset"}.issubset(set(read_text(campaign / "cgroup.subtree_control").split())):
            raise AuditError("Campaign child controllers unavailable")
        if not os.access(campaign / "cgroup.kill", os.W_OK):
            raise AuditError("Writable cgroup.kill is required for process-tree termination")
        return campaign
    except BaseException:
        campaign.rmdir()
        raise


def create_worker_cgroup(campaign: Path, name: str, cpu: int, config: dict) -> Path:
    path = campaign / name
    path.mkdir()
    try:
        cg_write(path / "cpuset.mems", read_text(campaign / "cpuset.mems.effective"))
        cg_write(path / "cpuset.cpus", str(cpu))
        cg_write(path / "memory.max", str(config["memory_limit_bytes"]))
        cg_write(path / "memory.swap.max", "0")
        cg_write(path / "memory.oom.group", "1")
        if parse_cpu_list(read_text(path / "cpuset.cpus.effective")) != {cpu}:
            raise AuditError("Worker effective cpuset does not contain exactly its assigned CPU")
        if not os.access(path / "cgroup.kill", os.W_OK):
            raise AuditError("Worker cgroup.kill is not writable")
        return path
    except BaseException:
        path.rmdir()
        raise


def tree_kill(path: Path) -> None:
    # cgroup.kill is recursive and includes subprocesses that created another session.
    cg_write(path / "cgroup.kill", "1", exact=False)


@dataclasses.dataclass
class Attempt:
    ordinal: int
    case: dict
    method: Method
    directory: Path
    cgroup: Path
    cpu: int
    process: subprocess.Popen
    started: float
    started_utc: str
    stdout_file: Any
    stderr_file: Any
    marker: dict | None = None
    marker_observed: float | None = None
    latest: dict = dataclasses.field(default_factory=dict)
    force_reason: str | None = None


def task_order(cases: list[dict], methods: list[Method]) -> list[tuple[dict, Method]]:
    tasks = []
    for index, case in enumerate(cases):
        rotation = index % len(methods)
        # Instance-major; rotating method order prevents systematic cutoff preference.
        tasks.extend((case, method) for method in methods[rotation:] + methods[:rotation])
    return tasks


def finite_nonnegative(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0


def status_from_observations(worker: dict | None, marker: dict | None, marker_seconds: float | None,
                             reason: str | None, returncode: int | None, events: dict[str, int],
                             solve_limit: float) -> tuple[str, str]:
    """Classification never replaces a raw worker status or invents a timing."""
    if reason in {"host_memory_pressure", "ancestor_cgroup_pressure", "campaign_deadline", "user_interrupt", "controller_error"}:
        return "interrupted_environment", reason
    if events.get("oom_kill", 0) > 0 or events.get("oom_group_kill", 0) > 0:
        return "memout", "cgroup_oom_kill_confirmed"
    if reason in {"solve_deadline", "marker_observed_after_deadline"}:
        return "timeout", reason
    if reason == "attempt_wall_deadline":
        # If the solve finished in time, a validation overrun is not a solver timeout.
        if marker is not None and marker_seconds is not None and marker_seconds <= solve_limit:
            if str(marker.get("reported_status", marker.get("status", ""))).lower() == "sat":
                return "sat_unverified", "verification_or_serialization_wall_deadline"
            return "error", "postsolve_wall_deadline"
        return "timeout", reason
    if reason == "worker_launch_error":
        return "error", reason
    if worker is None:
        return "error", "missing_or_invalid_worker_result"
    status = worker.get("status")
    if status not in RAW_STATUSES:
        return "error", "invalid_worker_status"
    if marker is None or marker_seconds is None:
        return "error", "missing_solver_finished_marker"
    if marker_seconds > solve_limit:
        return "timeout", "marker_observed_after_deadline"
    if worker.get("reported_status") != marker.get("reported_status"):
        return "error", "worker_marker_reported_status_mismatch"
    if worker.get("stage") != marker.get("stage"):
        return "error", "worker_marker_stage_mismatch"
    if not finite_nonnegative(worker.get("solve_seconds")) or not finite_nonnegative(marker.get("solve_seconds")):
        return "error", "invalid_or_missing_worker_solve_timing"
    if not math.isclose(worker["solve_seconds"], marker["solve_seconds"], rel_tol=1e-12, abs_tol=1e-9):
        return "error", "worker_marker_solve_timing_mismatch"
    if returncode != 0:
        return "error", "nonzero_worker_exit"
    expected_report = {"sat_verified": "sat", "sat_unverified": "sat", "unsat_reported": "unsat",
                       "timeout": "timeout", "unknown": "unknown", "error": "error"}
    if status in expected_report and worker.get("reported_status") != expected_report[status]:
        return "error", "worker_status_reported_status_mismatch"
    if status == "sat_verified":
        # The worker provides exact per-CNF validation; never promote SAT merely from its label.
        verification = worker.get("verification")
        passed = (verification is True or verification == "exact_cnf_passed" or
                  isinstance(verification, dict) and verification.get("passed") is True)
        if not passed:
            return "sat_unverified", "sat_verification_evidence_missing"
    return ("error", "worker_adapter_error") if status == "adapter_error" else (status, "worker_result")


def maybe_json(path: Path) -> dict | None:
    try:
        value = read_json(path)
        return value if isinstance(value, dict) else None
    except (OSError, ValueError):
        return None


def spawn_attempt(root: Path, output: Path, campaign: Path, config: dict, environment: dict,
                  ordinal: int, case: dict, method: Method, cpu: int) -> Attempt:
    name = f"{ordinal:06d}_{case['case_id']}_{method.name}"
    directory = output / "attempts" / name
    directory.mkdir()
    path = create_worker_cgroup(campaign, name, cpu, config)
    request = {
        "case_id": case["case_id"], "method": method.name,
        "input_path": str(package_path(root, case["input_path"])),
        "input_sha256": case["input_sha256"], "source_sha256": case["source_sha256"],
        "solver_file": str(method.solver_file), "solver_sha256": method.solver_sha256,
        "config_file": str(method.config_file) if method.config_file is not None else None,
        "config_sha256": method.config_sha256,
        "output_directory": str(directory), "seed": config["seed"],
        "solver_budget_seconds": config["solver_timeout_seconds"],
        "validation_budget_seconds": config["validation_seconds"],
    }
    write_new_json(directory / "request.json", request)
    write_new_json(directory / "cgroup_before.json", cgroup_snapshot(path))
    argv = [environment["wolfram_command"], "-noinit", "-script", str(root / "runner" / "worker.wls"),
            "--", "--request", str(directory / "request.json")]
    env = dict(os.environ)
    env.update(THREAD_ENV)
    stdout_file = (directory / "stdout.txt").open("xb")
    stderr_file = (directory / "stderr.txt").open("xb")
    procs = str(path / "cgroup.procs")

    def protected_child() -> None:
        # This code runs in the child BEFORE exec; no unprotected Wolfram startup.
        os.sched_setaffinity(0, {cpu})
        with open(procs, "w", encoding="ascii") as stream:
            stream.write(str(os.getpid()))

    write_new_json(directory / "launch.json", {"argv": argv, "prepared_at_utc": utc_now(),
                   "cpu": cpu, "thread_environment": THREAD_ENV, "cgroup": str(path),
                   "time_origin": "parent monotonic immediately before subprocess.Popen"})
    start_utc = utc_now()
    started = time.monotonic()
    try:
        process = subprocess.Popen(argv, cwd=directory, env=env, stdout=stdout_file,
                                   stderr=stderr_file, preexec_fn=protected_child,
                                   start_new_session=True, close_fds=True)
    except BaseException as error:
        stdout_file.close()
        stderr_file.close()
        tree_kill(path)
        write_new_json(directory / "cgroup_after.json", cgroup_snapshot(path))
        path.rmdir()
        measured_wall = time.monotonic() - started
        write_new_json(directory / "launch_error.json", {"exception": repr(error), "at_utc": utc_now(),
                       "attempt_wall_seconds": measured_wall})
        error.attempt_wall_seconds = measured_wall
        error.raw_directory = str(directory)
        raise
    return Attempt(ordinal, case, method, directory, path, cpu, process, started, start_utc,
                   stdout_file, stderr_file)


def stop_attempt(attempt: Attempt, reason: str) -> None:
    if attempt.force_reason is None:
        attempt.force_reason = reason
    tree_kill(attempt.cgroup)


def finalize_attempt(attempt: Attempt, config: dict, reason: str | None = None) -> dict:
    if reason is not None:
        stop_attempt(attempt, reason)
    elif attempt.process.poll() is None:
        raise AuditError("Tried to finalize a live worker without a termination reason")
    # Reap after recursive cgroup kill; a successful parent may still have helper processes.
    events_before_cleanup = cgroup_snapshot(attempt.cgroup)
    if read_text(attempt.cgroup / "cgroup.procs"):
        tree_kill(attempt.cgroup)
    try:
        returncode = attempt.process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        tree_kill(attempt.cgroup)
        returncode = attempt.process.poll()
        attempt.force_reason = attempt.force_reason or "controller_error"
    attempt.stdout_file.close()
    attempt.stderr_file.close()
    after = cgroup_snapshot(attempt.cgroup)
    write_new_json(attempt.directory / "cgroup_after.json", {"before_cleanup": events_before_cleanup, "after_cleanup": after})
    wall = time.monotonic() - attempt.started
    worker = maybe_json(attempt.directory / "result.json")
    if worker is not None and (worker.get("case_id") != attempt.case["case_id"] or worker.get("method") != attempt.method.name):
        append_json(attempt.directory / "observations.jsonl", {"event": "worker_identity_mismatch", "at_utc": utc_now()})
        worker = None
    counts = cgroup_event_counts(after)
    status, classification_reason = status_from_observations(worker, attempt.marker, attempt.marker_observed,
                 attempt.force_reason, returncode, counts, config["solver_timeout_seconds"])
    solve_seconds = None
    if worker is not None and finite_nonnegative(worker.get("solve_seconds")):
        solve_seconds = worker["solve_seconds"]
    elif attempt.marker is not None and finite_nonnegative(attempt.marker.get("solve_seconds")):
        solve_seconds = attempt.marker["solve_seconds"]
    result = {
        "ordinal": attempt.ordinal, "case_id": attempt.case["case_id"], "method": attempt.method.name,
        "group": attempt.case["group"], "original_smt2_path": attempt.case["original_smt2_path"],
        "input_sha256": attempt.case["input_sha256"], "source_sha256": attempt.case["source_sha256"],
        "solver_sha256": attempt.method.solver_sha256,
        "status": status, "classification_reason": classification_reason,
        "worker_status": None if worker is None else worker.get("status"),
        "reported_status": worker.get("reported_status") if worker is not None else (attempt.marker or {}).get("reported_status"),
        "stage": worker.get("stage") if worker is not None else (attempt.marker or {}).get("stage"),
        "kernel_version": None if worker is None else worker.get("kernel_version"),
        "system_id": None if worker is None else worker.get("system_id"),
        "solve_seconds": solve_seconds,
        "external_solver_finished_observed_seconds": attempt.marker_observed,
        "attempt_wall_seconds": wall, "validation_seconds": None if worker is None else worker.get("validation_seconds"),
        "exit_code": returncode, "cpu": attempt.cpu, "started_at_utc": attempt.started_utc,
        "finished_at_utc": utc_now(), "memory_events": counts,
        "memory_limit_evidence": {"max_events": counts.get("max", 0), "oom_events": counts.get("oom", 0),
                                  "oom_kill_confirmed": counts.get("oom_kill", 0) > 0 or counts.get("oom_group_kill", 0) > 0},
        "memory_peak_bytes": int(after["memory.peak"]) if after.get("memory.peak", "").isdigit() else None,
        "verification": None if worker is None else worker.get("verification"),
        "raw_directory": str(attempt.directory),
        "timing_note": "solve_seconds is worker API timing when present; never filled from the configured timeout. External timing includes kernel startup, input parsing, source load, and API call.",
    }
    write_new_json(attempt.directory / "observation.json", result)
    try:
        attempt.cgroup.rmdir()
    except OSError as error:
        append_json(attempt.directory / "observations.jsonl", {"event": "cgroup_cleanup_error", "exception": repr(error), "at_utc": utc_now()})
    return result


def derived_views(output: Path, results: list[dict], tasks: list[tuple[dict, Method]], started: float,
                  stop_reason: str | None, *, finished: bool) -> dict:
    columns = ["ordinal", "case_id", "method", "group", "original_smt2_path", "status", "classification_reason",
               "worker_status", "reported_status", "stage", "solve_seconds", "external_solver_finished_observed_seconds",
               "attempt_wall_seconds", "validation_seconds", "exit_code", "cpu", "memory_peak_bytes",
               "kernel_version", "system_id", "input_sha256", "source_sha256", "solver_sha256", "raw_directory"]
    observed = {(row["case_id"], row["method"]): row for row in results}
    rows = []
    for ordinal, (case, method) in enumerate(tasks, 1):
        row = observed.get((case["case_id"], method.name))
        if row is None:
            row = {"ordinal": ordinal, "case_id": case["case_id"], "method": method.name,
                   "group": case["group"], "original_smt2_path": case["original_smt2_path"],
                   "status": "not_started" if finished else "pending_or_running",
                   "input_sha256": case["input_sha256"], "source_sha256": case["source_sha256"],
                   "solver_sha256": method.solver_sha256}
        rows.append(row)
    temporary = output / "results.csv.new"
    with temporary.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, output / "results.csv")
    by_method = {}
    for method in METHODS:
        by_method[method] = dict(collections.Counter(row["status"] for row in rows if row["method"] == method))
    summary = {"at_utc": utc_now(), "finished": finished,
               "completed": finished and len(results) == len(tasks) and stop_reason is None,
               "planned_tasks": len(tasks), "final_observations": len(results),
               "not_started": len(tasks) - len(results) if finished else None,
               "elapsed_wall_seconds": time.monotonic() - started, "stop_reason": stop_reason,
               "by_method": by_method,
               "claims": {"SAT": "Only sat_verified is counted as exact-model checked SAT.",
                          "UNSAT": "unsat_reported is a solver report, not an independently checked proof.",
                          "timeout": "External monotonic 60-second deadline includes startup, parsing and solver source load.",
                          "historical_sota": "No resource equivalence with historical SOTA timings is claimed."}}
    replace_json(output / "summary.json", summary)
    return summary


def launch_headroom(memory: dict, attempts: list[Attempt], config: dict) -> bool:
    remaining_reservations = sum(max(0, config["memory_limit_bytes"] - int(a.latest.get("memory.current", "0"))) for a in attempts)
    required = config["memory_limit_bytes"] + int(max(config["reserve_ram_gib"], config["admission_headroom_gib"]) * GIB)
    return memory["effective_available"] - remaining_reservations >= required


def run_campaign(root: Path, output: Path, command: str, parent_text: str | None) -> int:
    started = time.monotonic()
    config, cases, methods, identity = load_bundle(root)
    environment = preflight(root, config, command, parent_text)
    if output.exists():
        raise AuditError(f"Refusing to overwrite existing output, including an empty directory: {output}")
    if output == root or output in root.parents:
        raise AuditError("Output must not replace the bundle or an ancestor")
    output.mkdir(parents=True, exist_ok=False)
    (output / "attempts").mkdir()
    write_new_json(output / "identity.json", identity)
    write_new_json(output / "environment.json", environment)
    write_new_json(output / "authorized_profile.json", config)
    tasks = task_order(cases, methods)
    write_new_json(output / "task_order.json", [{"ordinal": i, "case_id": c["case_id"], "method": m.name}
                                                for i, (c, m) in enumerate(tasks, 1)])
    journal = output / "journal.jsonl"
    append_json(journal, {"event": "campaign_started", "at_utc": utc_now(), "planned_tasks": len(tasks)})
    campaign = None
    active: list[Attempt] = []
    results: list[dict] = []
    cursor = 0
    stop_reason = None
    deadline = started + config["campaign_seconds"]
    launch_cutoff = deadline - config["stop_launching_before_deadline_seconds"]
    next_memory_log = 0.0
    try:
        campaign = make_campaign_cgroup(environment, config, uuid.uuid4().hex[:12])
        write_new_json(output / "campaign_cgroup_before.json", cgroup_snapshot(campaign))
        derived_views(output, results, tasks, started, None, finished=False)
        while active or cursor < len(tasks):
            now = time.monotonic()
            memory = memory_snapshot(Path(environment["cgroup_parent"]), Path(environment["cgroup_mount"]))
            if now >= next_memory_log:
                append_json(output / "host_resources.jsonl", {"at_utc": utc_now(), "campaign_seconds": now - started,
                            "memory": memory, "campaign": cgroup_snapshot(campaign)}, sync=False)
                next_memory_log = now + config["poll_seconds"]
            pressure_limit = int(config["admission_headroom_gib"] * GIB)
            pressure = None
            if memory["host_mem_available"] < pressure_limit:
                pressure = "host_memory_pressure"
            elif memory["effective_available"] < pressure_limit:
                pressure = "ancestor_cgroup_pressure"
            if now >= deadline:
                stop_reason = "campaign_deadline"
            elif pressure:
                stop_reason = pressure
            if stop_reason:
                for attempt in list(active):
                    row = finalize_attempt(attempt, config, stop_reason)
                    results.append(row)
                    append_json(journal, {"event": "attempt_finished", "result": row})
                    active.remove(attempt)
                break
            for attempt in list(active):
                now = time.monotonic()
                attempt.latest = cgroup_snapshot(attempt.cgroup)
                elapsed = now - attempt.started
                append_json(attempt.directory / "resources.jsonl", {"at_utc": utc_now(), "attempt_seconds": elapsed,
                            "sample": attempt.latest}, sync=False)
                marker_path = attempt.directory / "solver_finished.json"
                if attempt.marker is None and marker_path.is_file():
                    marker = maybe_json(marker_path)
                    if marker is not None and marker.get("case_id") == attempt.case["case_id"] and marker.get("method") == attempt.method.name:
                        attempt.marker = marker
                        attempt.marker_observed = time.monotonic() - attempt.started
                        append_json(attempt.directory / "observations.jsonl", {"event": "solver_finished_marker_observed",
                                   "at_utc": utc_now(), "elapsed_seconds": attempt.marker_observed,
                                   "file_mtime_ns": marker_path.stat().st_mtime_ns, "marker": marker})
                reason = None
                if attempt.marker_observed is not None and attempt.marker_observed > config["solver_timeout_seconds"]:
                    reason = "marker_observed_after_deadline"
                elif attempt.marker is None and elapsed >= config["solver_timeout_seconds"]:
                    reason = "solve_deadline"
                elif elapsed >= config["attempt_wall_seconds"]:
                    reason = "attempt_wall_deadline"
                elif attempt.marker_observed is not None and elapsed - attempt.marker_observed >= 15:
                    reason = "attempt_wall_deadline"
                if reason is not None or attempt.process.poll() is not None:
                    row = finalize_attempt(attempt, config, reason)
                    results.append(row)
                    append_json(journal, {"event": "attempt_finished", "result": row})
                    active.remove(attempt)
                    derived_views(output, results, tasks, started, None, finished=False)
                    print(f"[{len(results)}/{len(tasks)}] {row['case_id']} {row['method']}: {row['status']} ({row['attempt_wall_seconds']:.3f}s)", flush=True)
            while cursor < len(tasks) and len(active) < environment["planned_workers"] and time.monotonic() < launch_cutoff:
                memory = memory_snapshot(Path(environment["cgroup_parent"]), Path(environment["cgroup_mount"]))
                if not launch_headroom(memory, active, config):
                    break
                available_cpus = [cpu for cpu in environment["physical_cpu_representatives"] if all(a.cpu != cpu for a in active)]
                if not available_cpus:
                    break
                case, method = tasks[cursor]
                ordinal = cursor + 1
                # Detect file mutations before each attempt instead of silently measuring a new implementation.
                checked_hash(package_path(root, case["input_path"]), case["input_sha256"], case["case_id"])
                checked_hash(method.solver_file, method.solver_sha256, method.name)
                if method.config_file is not None:
                    checked_hash(method.config_file, method.config_sha256, method.name + " config")
                checked_hash(root / "runner" / "worker.wls", config["worker_sha256"], "worker.wls")
                verify_source_tree(root, config)
                try:
                    attempt = spawn_attempt(root, output, campaign, config, environment, ordinal, case, method, available_cpus[0])
                except Exception as error:
                    # This ordinal is consumed exactly once.  No automatic retries.
                    row = {"ordinal": ordinal, "case_id": case["case_id"], "method": method.name,
                           "group": case["group"], "original_smt2_path": case["original_smt2_path"],
                           "status": "error", "classification_reason": "worker_launch_error", "exception": repr(error),
                           "solve_seconds": None, "attempt_wall_seconds": getattr(error, "attempt_wall_seconds", None),
                           "raw_directory": getattr(error, "raw_directory", None),
                           "input_sha256": case["input_sha256"], "source_sha256": case["source_sha256"],
                           "solver_sha256": method.solver_sha256}
                    results.append(row)
                    append_json(journal, {"event": "attempt_finished", "result": row})
                    # A resource/launch problem invalidates further starts until reviewed.
                    stop_reason = "controller_error"
                else:
                    active.append(attempt)
                    append_json(journal, {"event": "attempt_started", "ordinal": ordinal,
                               "case_id": case["case_id"], "method": method.name, "pid": attempt.process.pid,
                               "cpu": attempt.cpu, "at_utc": attempt.started_utc})
                cursor += 1
                if stop_reason:
                    break
            if not active and cursor < len(tasks) and time.monotonic() >= launch_cutoff:
                stop_reason = "stopped_before_campaign_deadline"
                break
            time.sleep(config["poll_seconds"])
    except KeyboardInterrupt:
        stop_reason = "user_interrupt"
    except BaseException as error:
        stop_reason = "controller_error"
        append_json(journal, {"event": "controller_exception", "exception": repr(error), "at_utc": utc_now()})
    finally:
        for attempt in list(active):
            try:
                row = finalize_attempt(attempt, config, stop_reason or "controller_error")
                results.append(row)
                append_json(journal, {"event": "attempt_finished", "result": row})
            except BaseException as error:
                # Keep all existing raw observations even if cleanup itself encounters an OS error.
                append_json(journal, {"event": "attempt_cleanup_exception", "case_id": attempt.case["case_id"],
                           "method": attempt.method.name, "exception": repr(error), "at_utc": utc_now()})
                if campaign is not None:
                    tree_kill(campaign)
            active.remove(attempt)
        if campaign is not None:
            tree_kill(campaign)
            write_new_json(output / "campaign_cgroup_after.json", cgroup_snapshot(campaign))
            try:
                for child in campaign.iterdir():
                    if child.is_dir():
                        child.rmdir()
                campaign.rmdir()
            except OSError as error:
                append_json(journal, {"event": "campaign_cgroup_cleanup_error", "exception": repr(error), "at_utc": utc_now()})
        # A final recheck records whether the measured bundle is still identical.
        try:
            _, _, _, identity_after = load_bundle(root)
            write_new_json(output / "identity_after.json", identity_after)
        except BaseException as error:
            stop_reason = stop_reason or "bundle_integrity_changed"
            append_json(journal, {"event": "final_integrity_failure", "exception": repr(error), "at_utc": utc_now()})
        summary = derived_views(output, results, tasks, started, stop_reason, finished=True)
        append_json(journal, {"event": "campaign_finished", "at_utc": utc_now(), "summary": summary})
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if summary["completed"] and stop_reason is None else 2


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, default=Path(__file__).resolve().parent.parent)
    commands = parser.add_subparsers(dest="action", required=True)
    commands.add_parser("verify", help="Read-only portable source/input/hash/schema verification; no solver launch")
    for name in ("preflight", "run"):
        sub = commands.add_parser(name)
        sub.add_argument("--wolfram-command", required=True, help="Single Wolfram math/WolframKernel executable path")
        sub.add_argument("--cgroup-parent", help="Writable delegated cgroup-v2 directory; defaults to the current cgroup")
        if name == "run":
            sub.add_argument("--output", required=True, type=Path, help="New directory; existing paths are refused")
    args = parser.parse_args(argv)
    try:
        root = args.package.resolve()
        if args.action == "run":
            return run_campaign(root, args.output.expanduser().resolve(), args.wolfram_command, args.cgroup_parent)
        config, _, _, identity = load_bundle(root)
        if args.action == "verify":
            print(json.dumps(identity, ensure_ascii=False, indent=2))
        else:
            print(json.dumps({"bundle": identity, "environment": preflight(root, config, args.wolfram_command, args.cgroup_parent)},
                             ensure_ascii=False, indent=2))
        return 0
    except (AuditError, OSError, ValueError, TypeError, KeyError) as error:
        print(json.dumps({"ok": False, "error": str(error), "solver_started": False if args.action != "run" else "see raw campaign journal if created"}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
