"""No-solver tests: schema/hash integrity, timing classification and fail-closed CLI.

These tests do not claim to test the real Linux cgroup kernel implementation.
Run: python -m unittest discover -s runner -p test_run_subset.py -v
"""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

RUNNER = Path(__file__).with_name("run_subset.py")
spec = importlib.util.spec_from_file_location("tested_subset_runner", RUNNER)
r = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r
spec.loader.exec_module(r)


class BundleFixture(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        (self.root / "inputs").mkdir()
        (self.root / "source").mkdir()
        (self.root / "runner").mkdir()
        self.payload = {"case_id": "case-001", "group": "family/subgroup",
                        "original_smt2_path": "../SMT/test/case.smt2", "source_sha256": "1" * 64,
                        "variables": ["pilotx1"], "polynomials": ["pilotx1^2-2"],
                        "clauses": [[[1, 1]]], "original_variables": ["x_1"]}
        self.input = self.root / "inputs" / "case.json"
        self.input.write_text(json.dumps(self.payload), encoding="utf-8")
        self.worker = self.root / "runner" / "worker.wls"
        self.worker.write_text("(* fixture only: never executed *)", encoding="utf-8")
        self.solver = self.root / "source" / "solver.wl"
        self.solver.write_text("(* immutable fixture only *)", encoding="utf-8")
        self.source_manifest = self.root / "source_manifest.json"
        self.source_manifest.write_text(json.dumps({"files": [
            {"path": "source/solver.wl", "sha256": r.sha256(self.solver), "bytes": self.solver.stat().st_size}
        ]}), encoding="utf-8")
        self.case = {k: self.payload[k] for k in ("case_id", "group", "original_smt2_path", "source_sha256")}
        self.case.update(input_path="inputs/case.json", input_sha256=r.sha256(self.input))
        self.config = {
            "solver_timeout_seconds": 60, "validation_seconds": 10, "attempt_wall_seconds": 75,
            "campaign_seconds": 72000, "stop_launching_before_deadline_seconds": 120,
            "memory_limit_bytes": 4 * r.GIB, "seed": 314159, "max_workers": 3, "min_start_workers": 2,
            "reserve_ram_gib": 3, "admission_headroom_gib": 1.5, "poll_seconds": .1,
            "worker_sha256": r.sha256(self.worker),
            "source_manifest": "source_manifest.json", "source_manifest_sha256": r.sha256(self.source_manifest),
            "solvers": {name: {"solver_file": "source/solver.wl", "solver_sha256": r.sha256(self.solver)} for name in r.METHODS},
        }
        self.write_config_manifest()

    def tearDown(self):
        self.temporary.cleanup()

    def write_config_manifest(self):
        (self.root / "config.json").write_text(json.dumps(self.config), encoding="utf-8")
        (self.root / "selected_manifest.jsonl").write_text(json.dumps(self.case) + "\n", encoding="utf-8")

    def test_valid_bundle_is_read_only_and_cli_verifies(self):
        before = {str(p): (p.stat().st_mtime_ns, r.sha256(p)) for p in self.root.rglob("*") if p.is_file()}
        config, cases, methods, identity = r.load_bundle(self.root)
        self.assertEqual(len(cases), 1)
        self.assertEqual(len(methods), len(r.METHODS))
        self.assertEqual(identity["total_tasks"], len(r.METHODS))
        result = subprocess.run([sys.executable, str(RUNNER), "--package", str(self.root), "verify"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["cases"], 1)
        after = {str(p): (p.stat().st_mtime_ns, r.sha256(p)) for p in self.root.rglob("*") if p.is_file()}
        self.assertEqual(before, after)

    def test_input_tampering_is_rejected(self):
        self.input.write_text(self.input.read_text() + " ", encoding="utf-8")
        with self.assertRaisesRegex(r.AuditError, "SHA-256 mismatch"):
            r.load_bundle(self.root)

    def test_source_tampering_is_rejected(self):
        self.solver.write_text("changed", encoding="utf-8")
        with self.assertRaisesRegex(r.AuditError, "SHA-256 mismatch"):
            r.load_bundle(self.root)

    def test_unlisted_source_dependency_is_rejected(self):
        (self.root / "source" / "unexpected-component.wl").write_text("new dependency", encoding="utf-8")
        with self.assertRaisesRegex(r.AuditError, "exactly cover"):
            r.load_bundle(self.root)

    def test_payload_identity_mismatch_is_rejected_even_with_new_hash(self):
        self.payload["case_id"] = "some-other-case"
        self.input.write_text(json.dumps(self.payload), encoding="utf-8")
        self.case["input_sha256"] = r.sha256(self.input)
        self.write_config_manifest()
        with self.assertRaisesRegex(r.AuditError, "payload/manifest mismatch"):
            r.load_bundle(self.root)

    def test_no_path_escape_or_expected_status_filtering(self):
        self.case["input_path"] = "../outside.json"
        self.write_config_manifest()
        with self.assertRaisesRegex(r.AuditError, "escapes"):
            r.load_bundle(self.root)
        self.case["input_path"] = "inputs/case.json"
        self.case["expected_status"] = "sat"
        self.write_config_manifest()
        with self.assertRaisesRegex(r.AuditError, "expected-status"):
            r.load_bundle(self.root)

    def test_manifest_duplicate_is_rejected(self):
        with (self.root / "selected_manifest.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(self.case) + "\n")
        with self.assertRaisesRegex(r.AuditError, "duplicate case_id"):
            r.load_bundle(self.root)

    def test_unsafe_polynomial_and_bad_literal_are_rejected(self):
        payload = copy.deepcopy(self.payload)
        payload["polynomials"] = ['Run["external"]']
        with self.assertRaisesRegex(r.AuditError, "unapproved polynomial"):
            r.validate_payload(payload, "fixture")
        payload = copy.deepcopy(self.payload)
        payload["clauses"] = [[[2, 1]]]
        with self.assertRaisesRegex(r.AuditError, "index/sign"):
            r.validate_payload(payload, "fixture")

    def test_preflight_other_os_fails_without_start_or_write(self):
        with mock.patch.object(r.sys, "platform", "win32"), mock.patch.object(r.subprocess, "Popen") as popen:
            with self.assertRaisesRegex(r.AuditError, "requires Ubuntu"):
                r.preflight(self.root, self.config, "never-execute", None)
            popen.assert_not_called()

    def test_run_other_os_fails_before_creating_output(self):
        output = self.root / "new-output"
        with mock.patch.object(r.sys, "platform", "win32"), mock.patch.object(r.subprocess, "Popen") as popen:
            with self.assertRaisesRegex(r.AuditError, "requires Ubuntu"):
                r.run_campaign(self.root, output, "never-execute", None)
            popen.assert_not_called()
        self.assertFalse(output.exists())

    def test_order_is_instance_major_and_rotates_methods(self):
        _, cases, methods, _ = r.load_bundle(self.root)
        cases = [dict(cases[0], case_id="first"), dict(cases[0], case_id="second")]
        tasks = r.task_order(cases, methods)
        count = len(r.METHODS)
        self.assertEqual([c["case_id"] for c, _ in tasks[:count]], ["first"] * count)
        self.assertEqual([m.name for _, m in tasks[:count]], list(r.METHODS))
        self.assertEqual([m.name for _, m in tasks[count:]], list(r.METHODS[1:] + r.METHODS[:1]))

    def test_derived_views_never_fill_missing_solve_time(self):
        _, cases, methods, _ = r.load_bundle(self.root)
        output = self.root / "derived"
        output.mkdir()
        tasks = r.task_order(cases, methods)
        summary = r.derived_views(output, [{"ordinal": 1, "case_id": "case-001", "method": "HELMS", "status": "timeout", "solve_seconds": None}],
                                  tasks, r.time.monotonic(), "deadline", finished=True)
        self.assertFalse(summary["completed"])
        self.assertEqual(summary["not_started"], len(r.METHODS) - 1)
        self.assertIn("timeout", (output / "results.csv").read_text(encoding="utf-8-sig"))


class SupervisionLogic(unittest.TestCase):
    def reported(self, status, report, verification=None):
        marker = {"reported_status": report, "stage": "test-stage", "solve_seconds": .5}
        worker = {**marker, "status": status}
        if verification is not None:
            worker["verification"] = verification
        return worker, marker

    def test_physical_cpu_list_ranges(self):
        self.assertEqual(r.parse_cpu_list("0-2,8,10-11"), {0, 1, 2, 8, 10, 11})

    def test_effective_memory_uses_small_ancestor_not_host(self):
        with tempfile.TemporaryDirectory() as temp:
            mount = Path(temp)
            parent = mount / "delegated"
            parent.mkdir()
            (mount / "memory.max").write_text(str(10 * r.GIB))
            (mount / "memory.current").write_text(str(3 * r.GIB))
            (parent / "memory.max").write_text("max")
            (parent / "memory.current").write_text(str(r.GIB))
            with mock.patch.object(r, "meminfo", return_value={"MemAvailable": 15 * r.GIB, "MemTotal": 16 * r.GIB}):
                snapshot = r.memory_snapshot(parent, mount)
            self.assertEqual(snapshot["effective_available"], 7 * r.GIB)

    def test_active_jobs_reserve_their_remaining_caps(self):
        config = {"memory_limit_bytes": 4 * r.GIB, "reserve_ram_gib": 3, "admission_headroom_gib": 1.5}
        active = mock.Mock(latest={"memory.current": str(r.GIB)})
        self.assertFalse(r.launch_headroom({"effective_available": 9 * r.GIB}, [active], config))
        self.assertTrue(r.launch_headroom({"effective_available": 10 * r.GIB}, [active], config))

    def test_timeout_wins_over_late_success_but_raw_label_is_not_changed(self):
        worker = {"status": "sat_verified", "verification": "exact_cnf_passed"}
        status, reason = r.status_from_observations(worker, {"reported_status": "sat"}, 60.01, "marker_observed_after_deadline", 0, {}, 60)
        self.assertEqual(status, "timeout")
        self.assertEqual(worker["status"], "sat_verified")

    def test_sat_needs_verification_evidence(self):
        worker, marker = self.reported("sat_verified", "sat")
        self.assertEqual(r.status_from_observations(worker, marker, 1, None, 0, {}, 60)[0], "sat_unverified")
        worker["verification"] = "exact_cnf_passed"
        self.assertEqual(r.status_from_observations(worker, marker, 1, None, 0, {}, 60)[0], "sat_verified")

    def test_oom_evidence_is_distinct_from_host_pressure(self):
        self.assertEqual(r.status_from_observations(None, None, None, None, -9, {"oom_kill": 1}, 60)[0], "memout")
        self.assertEqual(r.status_from_observations(None, None, None, "host_memory_pressure", -9, {"max": 1}, 60)[0], "interrupted_environment")
        self.assertEqual(r.status_from_observations(None, None, None, None, -9, {}, 60)[0], "error")
        self.assertEqual(r.status_from_observations(None, None, None, None, -9, {"max": 2}, 60)[0], "error")

    def test_success_after_reclaim_is_not_changed_to_memout(self):
        worker, marker = self.reported("unsat_reported", "unsat")
        self.assertEqual(r.status_from_observations(worker, marker, 1, None, 0, {"max": 3}, 60)[0], "unsat_reported")

    def test_marker_report_and_meta_status_must_match(self):
        worker, marker = self.reported("sat_verified", "unsat", "exact_cnf_passed")
        self.assertEqual(r.status_from_observations(worker, marker, 1, None, 0, {}, 60)[1], "worker_status_reported_status_mismatch")
        worker["reported_status"] = "sat"
        self.assertEqual(r.status_from_observations(worker, marker, 1, None, 0, {}, 60)[1], "worker_marker_reported_status_mismatch")

    def test_marker_and_result_timing_must_agree(self):
        worker, marker = self.reported("unsat_reported", "unsat")
        worker["solve_seconds"] = 1.5
        self.assertEqual(r.status_from_observations(worker, marker, 1, None, 0, {}, 60)[1], "worker_marker_solve_timing_mismatch")

    def test_postsolve_validation_timeout_is_not_solver_timeout(self):
        self.assertEqual(r.status_from_observations(None, {"reported_status": "sat"}, 1, "attempt_wall_deadline", -9, {}, 60)[0], "sat_unverified")
        self.assertEqual(r.status_from_observations(None, None, None, "solve_deadline", -9, {}, 60)[0], "timeout")

    def test_invalid_and_unobserved_times_are_not_valid_numbers(self):
        for value in (-1, None, float("nan"), float("inf"), True, "1"):
            self.assertFalse(r.finite_nonnegative(value))
        self.assertTrue(r.finite_nonnegative(0))


if __name__ == "__main__":
    unittest.main()
