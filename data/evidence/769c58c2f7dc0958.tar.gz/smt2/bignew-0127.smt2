(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/polypaver/bench-exp-3d/polypaver-bench-exp-3d-chunk-0068.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 9 var0 var0 var0  ) (* 27 var0 var0 var1  ) (* 27 var0 var0 var2  ) (* 27 var0 var1 var1  ) (* 54 var0 var1 var2  ) (* 27 var0 var2 var2  ) (* 9 var1 var1 var1  ) (* 27 var1 var1 var2  ) (* 27 var1 var2 var2  ) (* 9 var2 var2 var2  ) (* 84 var0 var0  ) (* 168 var0 var1  ) (* 168 var0 var2  ) (* 84 var1 var1  ) (* 168 var1 var2  ) (* 84 var2 var2  ) (* 540 var0  ) (* 540 var1  ) (* 540 var2  ) 840 ) 0 )
)
  (or 
    (> (+ (* 1 var0  ) (* 1 var1  ) (* 1 var2  ) (- 0 2) ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (* 1 var1  ) (* 1 var2  ) (- 0 2) ) 0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
))
(check-sat)
(exit)
