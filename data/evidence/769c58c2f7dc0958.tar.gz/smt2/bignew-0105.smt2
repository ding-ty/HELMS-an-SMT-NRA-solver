(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/cbrt/3/cbrt-problem-3-chunk-0068.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 20 var0 var0 var1  ) (* 20 var0 var1 var1  ) (* 20 var0 var1 var2  ) (* 10 var0 var0  ) (* 148 var0 var1  ) (* 10 var0 var2  ) (* 10 var1 var1  ) (* 10 var1 var2  ) (* 69 var0  ) (* 69 var1  ) (* 5 var2  ) 32 ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (* 1 var1  ) (* 1 var2  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
))
(check-sat)
(exit)
