(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Chua/2/IL/L/Chua-2-IL-L-chunk-0039.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 86400000 var0  ) (* (- 0 2025130727) var1  ) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (< (+ (* 86400000 var0  ) (* (- 0 2025130727) var1  ) ) 0 )
)
  (or 
    (> (+ (* 86400000 var0  ) (* (- 0 2025130727) var1  ) ) 0 )
    (< (+ (* 86400000 var0  ) (* (- 0 2025130727) var1  ) ) 0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 75) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
))
(check-sat)
(exit)
