(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sqrt/problem/13/vars5/sqrt-problem-13-vars5-chunk-0027.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(assert (and
  (or 
    (< (+ (* 1 var1  ) (* 1 var2  ) 4 ) 0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 5 var0  ) (- 0 4) ) 0 )
)
))
(check-sat)
(exit)
