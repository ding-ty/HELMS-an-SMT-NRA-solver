(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20161105-Sturm-MGC/mgc_06.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(declare-fun var8 () Real)
(assert (and
  (or 
    (> (* 1 var8  )  0 )
)
  (or 
    (> (* 1 var7  )  0 )
)
  (or 
    (> (* 1 var6  )  0 )
)
  (or 
    (> (+ (* 6 var0 var3 var4 var7 var7 var7 var7 var7 var8  ) (* 1 var0 var4 var7 var7 var7 var7 var7 var7  ) (* 1 var0 var4  ) ) 0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
  (or 
    (> (* 1 var5  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
))
(check-sat)
(exit)
