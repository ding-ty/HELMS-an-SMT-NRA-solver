(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
kissing/kissing_4_9.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(declare-fun var8 () Real)
(declare-fun var9 () Real)
(declare-fun var10 () Real)
(declare-fun var11 () Real)
(declare-fun var12 () Real)
(declare-fun var13 () Real)
(declare-fun var14 () Real)
(declare-fun var15 () Real)
(declare-fun var16 () Real)
(declare-fun var17 () Real)
(declare-fun var18 () Real)
(declare-fun var19 () Real)
(declare-fun var20 () Real)
(declare-fun var21 () Real)
(declare-fun var22 () Real)
(declare-fun var23 () Real)
(declare-fun var24 () Real)
(declare-fun var25 () Real)
(declare-fun var26 () Real)
(declare-fun var27 () Real)
(declare-fun var28 () Real)
(declare-fun var29 () Real)
(declare-fun var30 () Real)
(declare-fun var31 () Real)
(declare-fun var32 () Real)
(declare-fun var33 () Real)
(declare-fun var34 () Real)
(declare-fun var35 () Real)
(assert (and
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var4  ) (* 1 var1 var1  ) (* (- 0 2) var1 var5  ) (* 1 var2 var2  ) (* (- 0 2) var2 var6  ) (* 1 var3 var3  ) (* (- 0 2) var3 var7  ) (* 1 var4 var4  ) (* 1 var5 var5  ) (* 1 var6 var6  ) (* 1 var7 var7  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var8  ) (* 1 var1 var1  ) (* (- 0 2) var1 var9  ) (* 1 var2 var2  ) (* (- 0 2) var2 var10  ) (* 1 var3 var3  ) (* (- 0 2) var3 var11  ) (* 1 var8 var8  ) (* 1 var9 var9  ) (* 1 var10 var10  ) (* 1 var11 var11  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var12  ) (* 1 var1 var1  ) (* (- 0 2) var1 var13  ) (* 1 var2 var2  ) (* (- 0 2) var2 var14  ) (* 1 var3 var3  ) (* (- 0 2) var3 var15  ) (* 1 var12 var12  ) (* 1 var13 var13  ) (* 1 var14 var14  ) (* 1 var15 var15  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var16  ) (* 1 var1 var1  ) (* (- 0 2) var1 var17  ) (* 1 var2 var2  ) (* (- 0 2) var2 var18  ) (* 1 var3 var3  ) (* (- 0 2) var3 var19  ) (* 1 var16 var16  ) (* 1 var17 var17  ) (* 1 var18 var18  ) (* 1 var19 var19  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var20  ) (* 1 var1 var1  ) (* (- 0 2) var1 var21  ) (* 1 var2 var2  ) (* (- 0 2) var2 var22  ) (* 1 var3 var3  ) (* (- 0 2) var3 var23  ) (* 1 var20 var20  ) (* 1 var21 var21  ) (* 1 var22 var22  ) (* 1 var23 var23  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var24  ) (* 1 var1 var1  ) (* (- 0 2) var1 var25  ) (* 1 var2 var2  ) (* (- 0 2) var2 var26  ) (* 1 var3 var3  ) (* (- 0 2) var3 var27  ) (* 1 var24 var24  ) (* 1 var25 var25  ) (* 1 var26 var26  ) (* 1 var27 var27  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var28  ) (* 1 var1 var1  ) (* (- 0 2) var1 var29  ) (* 1 var2 var2  ) (* (- 0 2) var2 var30  ) (* 1 var3 var3  ) (* (- 0 2) var3 var31  ) (* 1 var28 var28  ) (* 1 var29 var29  ) (* 1 var30 var30  ) (* 1 var31 var31  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 2) var0 var32  ) (* 1 var1 var1  ) (* (- 0 2) var1 var33  ) (* 1 var2 var2  ) (* (- 0 2) var2 var34  ) (* 1 var3 var3  ) (* (- 0 2) var3 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var4 var4  ) (* (- 0 2) var4 var8  ) (* 1 var5 var5  ) (* (- 0 2) var5 var9  ) (* 1 var6 var6  ) (* (- 0 2) var6 var10  ) (* 1 var7 var7  ) (* (- 0 2) var7 var11  ) (* 1 var8 var8  ) (* 1 var9 var9  ) (* 1 var10 var10  ) (* 1 var11 var11  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var4 var4  ) (* (- 0 2) var4 var12  ) (* 1 var5 var5  ) (* (- 0 2) var5 var13  ) (* 1 var6 var6  ) (* (- 0 2) var6 var14  ) (* 1 var7 var7  ) (* (- 0 2) var7 var15  ) (* 1 var12 var12  ) (* 1 var13 var13  ) (* 1 var14 var14  ) (* 1 var15 var15  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var4 var4  ) (* (- 0 2) var4 var16  ) (* 1 var5 var5  ) (* (- 0 2) var5 var17  ) (* 1 var6 var6  ) (* (- 0 2) var6 var18  ) (* 1 var7 var7  ) (* (- 0 2) var7 var19  ) (* 1 var16 var16  ) (* 1 var17 var17  ) (* 1 var18 var18  ) (* 1 var19 var19  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var4 var4  ) (* (- 0 2) var4 var20  ) (* 1 var5 var5  ) (* (- 0 2) var5 var21  ) (* 1 var6 var6  ) (* (- 0 2) var6 var22  ) (* 1 var7 var7  ) (* (- 0 2) var7 var23  ) (* 1 var20 var20  ) (* 1 var21 var21  ) (* 1 var22 var22  ) (* 1 var23 var23  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var4 var4  ) (* (- 0 2) var4 var24  ) (* 1 var5 var5  ) (* (- 0 2) var5 var25  ) (* 1 var6 var6  ) (* (- 0 2) var6 var26  ) (* 1 var7 var7  ) (* (- 0 2) var7 var27  ) (* 1 var24 var24  ) (* 1 var25 var25  ) (* 1 var26 var26  ) (* 1 var27 var27  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var4 var4  ) (* (- 0 2) var4 var28  ) (* 1 var5 var5  ) (* (- 0 2) var5 var29  ) (* 1 var6 var6  ) (* (- 0 2) var6 var30  ) (* 1 var7 var7  ) (* (- 0 2) var7 var31  ) (* 1 var28 var28  ) (* 1 var29 var29  ) (* 1 var30 var30  ) (* 1 var31 var31  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var4 var4  ) (* (- 0 2) var4 var32  ) (* 1 var5 var5  ) (* (- 0 2) var5 var33  ) (* 1 var6 var6  ) (* (- 0 2) var6 var34  ) (* 1 var7 var7  ) (* (- 0 2) var7 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var8 var8  ) (* (- 0 2) var8 var12  ) (* 1 var9 var9  ) (* (- 0 2) var9 var13  ) (* 1 var10 var10  ) (* (- 0 2) var10 var14  ) (* 1 var11 var11  ) (* (- 0 2) var11 var15  ) (* 1 var12 var12  ) (* 1 var13 var13  ) (* 1 var14 var14  ) (* 1 var15 var15  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var8 var8  ) (* (- 0 2) var8 var16  ) (* 1 var9 var9  ) (* (- 0 2) var9 var17  ) (* 1 var10 var10  ) (* (- 0 2) var10 var18  ) (* 1 var11 var11  ) (* (- 0 2) var11 var19  ) (* 1 var16 var16  ) (* 1 var17 var17  ) (* 1 var18 var18  ) (* 1 var19 var19  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var8 var8  ) (* (- 0 2) var8 var20  ) (* 1 var9 var9  ) (* (- 0 2) var9 var21  ) (* 1 var10 var10  ) (* (- 0 2) var10 var22  ) (* 1 var11 var11  ) (* (- 0 2) var11 var23  ) (* 1 var20 var20  ) (* 1 var21 var21  ) (* 1 var22 var22  ) (* 1 var23 var23  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var8 var8  ) (* (- 0 2) var8 var24  ) (* 1 var9 var9  ) (* (- 0 2) var9 var25  ) (* 1 var10 var10  ) (* (- 0 2) var10 var26  ) (* 1 var11 var11  ) (* (- 0 2) var11 var27  ) (* 1 var24 var24  ) (* 1 var25 var25  ) (* 1 var26 var26  ) (* 1 var27 var27  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var8 var8  ) (* (- 0 2) var8 var28  ) (* 1 var9 var9  ) (* (- 0 2) var9 var29  ) (* 1 var10 var10  ) (* (- 0 2) var10 var30  ) (* 1 var11 var11  ) (* (- 0 2) var11 var31  ) (* 1 var28 var28  ) (* 1 var29 var29  ) (* 1 var30 var30  ) (* 1 var31 var31  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var8 var8  ) (* (- 0 2) var8 var32  ) (* 1 var9 var9  ) (* (- 0 2) var9 var33  ) (* 1 var10 var10  ) (* (- 0 2) var10 var34  ) (* 1 var11 var11  ) (* (- 0 2) var11 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var12 var12  ) (* (- 0 2) var12 var16  ) (* 1 var13 var13  ) (* (- 0 2) var13 var17  ) (* 1 var14 var14  ) (* (- 0 2) var14 var18  ) (* 1 var15 var15  ) (* (- 0 2) var15 var19  ) (* 1 var16 var16  ) (* 1 var17 var17  ) (* 1 var18 var18  ) (* 1 var19 var19  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var12 var12  ) (* (- 0 2) var12 var20  ) (* 1 var13 var13  ) (* (- 0 2) var13 var21  ) (* 1 var14 var14  ) (* (- 0 2) var14 var22  ) (* 1 var15 var15  ) (* (- 0 2) var15 var23  ) (* 1 var20 var20  ) (* 1 var21 var21  ) (* 1 var22 var22  ) (* 1 var23 var23  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var12 var12  ) (* (- 0 2) var12 var24  ) (* 1 var13 var13  ) (* (- 0 2) var13 var25  ) (* 1 var14 var14  ) (* (- 0 2) var14 var26  ) (* 1 var15 var15  ) (* (- 0 2) var15 var27  ) (* 1 var24 var24  ) (* 1 var25 var25  ) (* 1 var26 var26  ) (* 1 var27 var27  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var12 var12  ) (* (- 0 2) var12 var28  ) (* 1 var13 var13  ) (* (- 0 2) var13 var29  ) (* 1 var14 var14  ) (* (- 0 2) var14 var30  ) (* 1 var15 var15  ) (* (- 0 2) var15 var31  ) (* 1 var28 var28  ) (* 1 var29 var29  ) (* 1 var30 var30  ) (* 1 var31 var31  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var12 var12  ) (* (- 0 2) var12 var32  ) (* 1 var13 var13  ) (* (- 0 2) var13 var33  ) (* 1 var14 var14  ) (* (- 0 2) var14 var34  ) (* 1 var15 var15  ) (* (- 0 2) var15 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var16 var16  ) (* (- 0 2) var16 var20  ) (* 1 var17 var17  ) (* (- 0 2) var17 var21  ) (* 1 var18 var18  ) (* (- 0 2) var18 var22  ) (* 1 var19 var19  ) (* (- 0 2) var19 var23  ) (* 1 var20 var20  ) (* 1 var21 var21  ) (* 1 var22 var22  ) (* 1 var23 var23  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var16 var16  ) (* (- 0 2) var16 var24  ) (* 1 var17 var17  ) (* (- 0 2) var17 var25  ) (* 1 var18 var18  ) (* (- 0 2) var18 var26  ) (* 1 var19 var19  ) (* (- 0 2) var19 var27  ) (* 1 var24 var24  ) (* 1 var25 var25  ) (* 1 var26 var26  ) (* 1 var27 var27  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var16 var16  ) (* (- 0 2) var16 var28  ) (* 1 var17 var17  ) (* (- 0 2) var17 var29  ) (* 1 var18 var18  ) (* (- 0 2) var18 var30  ) (* 1 var19 var19  ) (* (- 0 2) var19 var31  ) (* 1 var28 var28  ) (* 1 var29 var29  ) (* 1 var30 var30  ) (* 1 var31 var31  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var16 var16  ) (* (- 0 2) var16 var32  ) (* 1 var17 var17  ) (* (- 0 2) var17 var33  ) (* 1 var18 var18  ) (* (- 0 2) var18 var34  ) (* 1 var19 var19  ) (* (- 0 2) var19 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var20 var20  ) (* (- 0 2) var20 var24  ) (* 1 var21 var21  ) (* (- 0 2) var21 var25  ) (* 1 var22 var22  ) (* (- 0 2) var22 var26  ) (* 1 var23 var23  ) (* (- 0 2) var23 var27  ) (* 1 var24 var24  ) (* 1 var25 var25  ) (* 1 var26 var26  ) (* 1 var27 var27  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var20 var20  ) (* (- 0 2) var20 var28  ) (* 1 var21 var21  ) (* (- 0 2) var21 var29  ) (* 1 var22 var22  ) (* (- 0 2) var22 var30  ) (* 1 var23 var23  ) (* (- 0 2) var23 var31  ) (* 1 var28 var28  ) (* 1 var29 var29  ) (* 1 var30 var30  ) (* 1 var31 var31  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var20 var20  ) (* (- 0 2) var20 var32  ) (* 1 var21 var21  ) (* (- 0 2) var21 var33  ) (* 1 var22 var22  ) (* (- 0 2) var22 var34  ) (* 1 var23 var23  ) (* (- 0 2) var23 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var24 var24  ) (* (- 0 2) var24 var28  ) (* 1 var25 var25  ) (* (- 0 2) var25 var29  ) (* 1 var26 var26  ) (* (- 0 2) var26 var30  ) (* 1 var27 var27  ) (* (- 0 2) var27 var31  ) (* 1 var28 var28  ) (* 1 var29 var29  ) (* 1 var30 var30  ) (* 1 var31 var31  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var24 var24  ) (* (- 0 2) var24 var32  ) (* 1 var25 var25  ) (* (- 0 2) var25 var33  ) (* 1 var26 var26  ) (* (- 0 2) var26 var34  ) (* 1 var27 var27  ) (* (- 0 2) var27 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var28 var28  ) (* (- 0 2) var28 var32  ) (* 1 var29 var29  ) (* (- 0 2) var29 var33  ) (* 1 var30 var30  ) (* (- 0 2) var30 var34  ) (* 1 var31 var31  ) (* (- 0 2) var31 var35  ) (* 1 var32 var32  ) (* 1 var33 var33  ) (* 1 var34 var34  ) (* 1 var35 var35  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
