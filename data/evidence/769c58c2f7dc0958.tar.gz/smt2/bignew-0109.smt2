(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/cos/3410/cos-3410-b-chunk-0020.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 100 var0 var0  ) (* (- 0 100) var0 var1  ) (* (- 0 100) var0 var2  ) (* 50 var1 var1  ) (* 50 var2 var2  ) (- 0 251) ) 0 )
)
  (or 
    (> (+ (* 50 var0 var0  ) (* (- 0 100) var0 var2  ) (* 50 var2 var2  ) (- 0 51) ) 0 )
)
  (or 
    (> (+ (* 50 var0 var0  ) (* (- 0 100) var0 var1  ) (* 50 var1 var1  ) (- 0 51) ) 0 )
)
  (or 
    (> (+ (* 2 var2  ) 3 ) 0 )
)
  (or 
    (> (+ (* 2 var1  ) 3 ) 0 )
)
  (or 
    (> (+ (* 2 var0  ) 3 ) 0 )
)
  (or 
    (< (+ (* 2 var2  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 2 var1  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 2 var0  ) (- 0 3) ) 0 )
)
))
(check-sat)
(exit)
