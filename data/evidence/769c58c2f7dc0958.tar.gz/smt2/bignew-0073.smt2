(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Lyapunov/Lyapunov1a-chunk-0005.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 493 var0  ) (* 2540 var1  ) (* (- 0 17200) var2  ) ) 0 )
)
  (or 
    (< (+ (* 14100 var0 var0  ) (* 10500 var0 var1  ) (* (- 0 413) var0 var2  ) (* 26100 var1 var1  ) (* (- 0 2130) var1 var2  ) (* 7200 var2 var2  ) (- 0 1000) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
    (< (* 1 var1  )  0 )
    (> (* 1 var0  )  0 )
    (< (* 1 var0  )  0 )
    (> (* 1 var2  )  0 )
    (< (* 1 var2  )  0 )
)
))
(check-sat)
(exit)
