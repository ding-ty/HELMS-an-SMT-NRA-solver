(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20220314-Uncu/Polynomial_Proof_Calls/ProveIneq_JSC_SUMCracker_19b.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 1 var2  ) 2 ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (+ (* 1 var0  ) 1 ) 0 )
)
  (or 
    (> (+ (* 1 var0  ) 2 ) 0 )
)
  (or 
    (< (+ (* 1 var0 var2  ) (* (- 0 1) var1  ) 1 ) 0 )
)
  (or 
    (< (+ (* 1 var0 var2  ) (* (- 0 1) var1 var2  ) (* (- 0 1) var1  ) (* 1 var2  ) 1 ) 0 )
)
  (or 
    (< (+ (* 1 var1 var2 var2  ) (* (- 0 1) var0 var2  ) (* 2 var1 var2  ) (* 1 var1  ) (* (- 0 2) var2  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
