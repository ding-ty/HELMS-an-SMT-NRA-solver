(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/atan/problem/2/atan-problem-2-chunk-0039.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (* 1 var3  )  0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
    (< (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 2) ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) (* (- 0 1) var2  ) ) 0 )
)
))
(check-sat)
(exit)
