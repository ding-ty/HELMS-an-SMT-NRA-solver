(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20240407-pPDA-Chiari-Pontiggia-Winkler/past/sqrt2by2_bern_PRAY.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(assert (and
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var0 var1  ) (* 1 var0 var2  ) (* (- 0 2) var0  ) 1 ) 0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (< (+ (* 1 var1 var3  ) (* 1 var2 var3  ) (* (- 0 2) var3  ) 1 ) 0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
  (or 
    (< (+ (* 1 var0 var5  ) (* 1 var2 var4  ) (* (- 0 1) var4  ) 2 ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (< (+ (* 1 var0 var3  ) (* 1 var1 var1  ) (* (- 0 2) var1  ) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (< (+ (* 1 var0 var3  ) (* 1 var2 var2  ) (* (- 0 2) var2  ) ) 0 )
)
  (or 
    (> (* 1 var5  )  0 )
)
  (or 
    (< (+ (* 1 var1 var5  ) (* 1 var3 var4  ) (* (- 0 1) var5  ) 2 ) 0 )
)
))
(check-sat)
(exit)
