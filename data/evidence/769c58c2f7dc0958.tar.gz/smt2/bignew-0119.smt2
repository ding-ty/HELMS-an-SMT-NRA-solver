(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/exp/problem/10/2/exp-problem-10-2-chunk-0131.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (< (+ (* 12 var0 var0  ) (* (- 0 6) var0  ) 1 ) 0 )
)
  (or 
    (> (+ (* 1 var3  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (< (+ (* 1 var3  ) (- 0 5) ) 0 )
)
))
(check-sat)
(exit)
