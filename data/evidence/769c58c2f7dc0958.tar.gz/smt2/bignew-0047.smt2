(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/CONVOI2/CONVOI2-chunk-0016.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (< (+ (* 1693827 var0 var0 var1 var3  ) (* 197823825 var0 var0 var2 var3  ) (* 8469135 var0 var0 var1  ) (* 989119125 var0 var0 var2  ) (* 31959000 var0 var1 var3  ) (* 3732525000 var0 var2 var3  ) (* 159795000 var0 var1  ) (* 18662625000 var0 var2  ) (* 201000000 var1 var3  ) (* 23475000000 var2 var3  ) (* 1005000000 var1  ) (* 117375000000 var2  ) ) 0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 50 var3  ) (- 0 151) ) 0 )
)
))
(check-sat)
(exit)
