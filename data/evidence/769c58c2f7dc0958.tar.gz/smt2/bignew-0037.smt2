(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Arthan/1A/Arthan1A-chunk-0019.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (> (+ (* 1 var0 var0 var0 var1  ) (* 2 var0 var0 var0  ) (* 2 var0 var0 var1  ) (* 6 var0 var0 var2  ) (* 1 var0 var1 var1  ) (* 2 var0 var2 var2  ) (* 6 var0 var0  ) (* (- 0 4) var0 var1  ) (* 10 var0 var2  ) (* 1 var1 var1  ) (* (- 0 2) var1 var2  ) (* 2 var2 var2  ) (* (- 0 3) var1  ) (* 2 var2  ) (- 0 2) ) 0 )
)
  (or 
    (< (+ (* 2 var0  ) (* (- 0 1) var3  ) ) 0 )
)
  (or 
    (> (+ (* 5000000 var3  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10000000 var3  ) (- 0 31415927) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (+ (* 1 var0  ) (* (- 0 1) var1  ) ) 0 )
)
))
(check-sat)
(exit)
