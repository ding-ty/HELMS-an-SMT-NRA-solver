(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sqrt/problem/13/sqrt1/sqrt-problem-13-sqrt1-chunk-0042.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0  ) (* 2 var1  ) 10 ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
))
(check-sat)
(exit)
