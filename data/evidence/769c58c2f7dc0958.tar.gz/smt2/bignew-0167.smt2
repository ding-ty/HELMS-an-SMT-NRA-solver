(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sqrt/problem/sqrt-problem-Melquiond2-chunk-0095.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 3539533824 var0 var0 var0 var0 var0 var0 var1  ) (* 1190854656 var0 var0 var0 var0 var0 var1 var1  ) (* 67829760 var0 var0 var0 var0 var1 var1 var1  ) (* 589824 var0 var0 var0 var1 var1 var1 var1  ) (* 3637868155 var0 var0 var0 var0 var0 var0  ) (* (- 0 9663817055) var0 var0 var0 var0 var0 var1  ) (* (- 0 1909712175) var0 var0 var0 var0 var1 var1  ) (* (- 0 53013845) var0 var0 var0 var1 var1 var1  ) (* (- 0 128000) var0 var0 var1 var1 var1 var1  ) ) 0 )
)
  (or 
    (> (+ (* 1 var2  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 2 var1  ) (- 0 3) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 2) ) 0 )
)
  (or 
    (< (+ (* 32 var2  ) (- 0 33) ) 0 )
)
))
(check-sat)
(exit)
