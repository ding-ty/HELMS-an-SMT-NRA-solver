(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20220314-Uncu/Rational_Function_Proof_Calls_With_Disjunctive_Denominator_Simplifications/DDC_ProveIneq_ISSAC10_ex1f.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (+ (* 1 var3  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (> (+ (* 1 var3  ) 1 ) 0 )
)
  (or 
    (> (+ (* 1 var3  ) 2 ) 0 )
)
  (or 
    (> (+ (* 1 var3  ) 3 ) 0 )
)
  (or 
    (> (+ (* 1 var3  ) 4 ) 0 )
)
  (or 
    (> (+ (* 1 var3  ) 5 ) 0 )
)
  (or 
    (> (+ (* 2 var3  ) 13 ) 0 )
    (< (+ (* 2 var3  ) 13 ) 0 )
)
  (or 
    (> (+ (* 2 var3  ) 13 ) 0 )
    (< (+ (* 2 var0 var3  ) (* (- 0 3) var1 var3  ) (* 5 var2 var3  ) (* 7 var0  ) (* (- 0 20) var1  ) (* 22 var2  ) ) 0 )
)
  (or 
    (> (+ (* 2 var0 var3  ) (* (- 0 3) var1 var3  ) (* 5 var2 var3  ) (* 7 var0  ) (* (- 0 20) var1  ) (* 22 var2  ) ) 0 )
    (< (+ (* 2 var3  ) 13 ) 0 )
)
  (or 
    (> (+ (* 2 var0 var3  ) (* (- 0 3) var1 var3  ) (* 5 var2 var3  ) (* 7 var0  ) (* (- 0 20) var1  ) (* 22 var2  ) ) 0 )
    (< (+ (* 2 var0 var3  ) (* (- 0 3) var1 var3  ) (* 5 var2 var3  ) (* 7 var0  ) (* (- 0 20) var1  ) (* 22 var2  ) ) 0 )
)
  (or 
    (> (+ (* 4 var3 var3  ) (* 56 var3  ) 195 ) 0 )
    (< (+ (* 4 var3 var3  ) (* 56 var3  ) 195 ) 0 )
)
  (or 
    (> (+ (* 4 var3 var3  ) (* 56 var3  ) 195 ) 0 )
    (< (+ (* 10 var0 var3 var3  ) (* (- 0 11) var1 var3 var3  ) (* 19 var2 var3 var3  ) (* 89 var0 var3  ) (* (- 0 137) var1 var3  ) (* 160 var2 var3  ) (* 189 var0  ) (* (- 0 423) var1  ) (* 295 var2  ) ) 0 )
)
  (or 
    (> (+ (* 10 var0 var3 var3  ) (* (- 0 11) var1 var3 var3  ) (* 19 var2 var3 var3  ) (* 89 var0 var3  ) (* (- 0 137) var1 var3  ) (* 160 var2 var3  ) (* 189 var0  ) (* (- 0 423) var1  ) (* 295 var2  ) ) 0 )
    (< (+ (* 4 var3 var3  ) (* 56 var3  ) 195 ) 0 )
)
  (or 
    (> (+ (* 10 var0 var3 var3  ) (* (- 0 11) var1 var3 var3  ) (* 19 var2 var3 var3  ) (* 89 var0 var3  ) (* (- 0 137) var1 var3  ) (* 160 var2 var3  ) (* 189 var0  ) (* (- 0 423) var1  ) (* 295 var2  ) ) 0 )
    (< (+ (* 10 var0 var3 var3  ) (* (- 0 11) var1 var3 var3  ) (* 19 var2 var3 var3  ) (* 89 var0 var3  ) (* (- 0 137) var1 var3  ) (* 160 var2 var3  ) (* 189 var0  ) (* (- 0 423) var1  ) (* 295 var2  ) ) 0 )
)
  (or 
    (> (+ (* 8 var3 var3 var3  ) (* 180 var3 var3  ) (* 1342 var3  ) 3315 ) 0 )
    (< (+ (* 8 var3 var3 var3  ) (* 180 var3 var3  ) (* 1342 var3  ) 3315 ) 0 )
)
  (or 
    (> (+ (* 8 var3 var3 var3  ) (* 180 var3 var3  ) (* 1342 var3  ) 3315 ) 0 )
    (< (+ (* 38 var0 var3 var3 var3  ) (* (- 0 37) var1 var3 var3 var3  ) (* 73 var2 var3 var3 var3  ) (* 529 var0 var3 var3  ) (* (- 0 626) var1 var3 var3  ) (* 947 var2 var3 var3  ) (* 2334 var0 var3  ) (* (- 0 3389) var1 var3  ) (* 3517 var2 var3  ) (* 3318 var0  ) (* (- 0 5736) var1  ) (* 3005 var2  ) ) 0 )
)
  (or 
    (> (+ (* 38 var0 var3 var3 var3  ) (* (- 0 37) var1 var3 var3 var3  ) (* 73 var2 var3 var3 var3  ) (* 529 var0 var3 var3  ) (* (- 0 626) var1 var3 var3  ) (* 947 var2 var3 var3  ) (* 2334 var0 var3  ) (* (- 0 3389) var1 var3  ) (* 3517 var2 var3  ) (* 3318 var0  ) (* (- 0 5736) var1  ) (* 3005 var2  ) ) 0 )
    (< (+ (* 8 var3 var3 var3  ) (* 180 var3 var3  ) (* 1342 var3  ) 3315 ) 0 )
)
  (or 
    (> (+ (* 38 var0 var3 var3 var3  ) (* (- 0 37) var1 var3 var3 var3  ) (* 73 var2 var3 var3 var3  ) (* 529 var0 var3 var3  ) (* (- 0 626) var1 var3 var3  ) (* 947 var2 var3 var3  ) (* 2334 var0 var3  ) (* (- 0 3389) var1 var3  ) (* 3517 var2 var3  ) (* 3318 var0  ) (* (- 0 5736) var1  ) (* 3005 var2  ) ) 0 )
    (< (+ (* 38 var0 var3 var3 var3  ) (* (- 0 37) var1 var3 var3 var3  ) (* 73 var2 var3 var3 var3  ) (* 529 var0 var3 var3  ) (* (- 0 626) var1 var3 var3  ) (* 947 var2 var3 var3  ) (* 2334 var0 var3  ) (* (- 0 3389) var1 var3  ) (* 3517 var2 var3  ) (* 3318 var0  ) (* (- 0 5736) var1  ) (* 3005 var2  ) ) 0 )
)
  (or 
    (> (+ (* 16 var3 var3 var3 var3  ) (* 512 var3 var3 var3  ) (* 6104 var3 var3  ) (* 32128 var3  ) 62985 ) 0 )
    (< (+ (* 16 var3 var3 var3 var3  ) (* 512 var3 var3 var3  ) (* 6104 var3 var3  ) (* 32128 var3  ) 62985 ) 0 )
)
  (or 
    (> (+ (* 16 var3 var3 var3 var3  ) (* 512 var3 var3 var3  ) (* 6104 var3 var3  ) (* 32128 var3  ) 62985 ) 0 )
    (> (+ (* 146 var0 var3 var3 var3 var3  ) (* (- 0 143) var1 var3 var3 var3 var3  ) (* 291 var2 var3 var3 var3 var3  ) (* 2843 var0 var3 var3 var3  ) (* (- 0 3178) var1 var3 var3 var3  ) (* 5481 var2 var3 var3 var3  ) (* 19422 var0 var3 var3  ) (* (- 0 24839) var1 var3 var3  ) (* 34717 var2 var3 var3  ) (* 54494 var0 var3  ) (* (- 0 77210) var1 var3  ) (* 80218 var2 var3  ) (* 52794 var0  ) (* (- 0 69993) var1  ) (* 38680 var2  ) ) 0 )
)
  (or 
    (< (+ (* 146 var0 var3 var3 var3 var3  ) (* (- 0 143) var1 var3 var3 var3 var3  ) (* 291 var2 var3 var3 var3 var3  ) (* 2843 var0 var3 var3 var3  ) (* (- 0 3178) var1 var3 var3 var3  ) (* 5481 var2 var3 var3 var3  ) (* 19422 var0 var3 var3  ) (* (- 0 24839) var1 var3 var3  ) (* 34717 var2 var3 var3  ) (* 54494 var0 var3  ) (* (- 0 77210) var1 var3  ) (* 80218 var2 var3  ) (* 52794 var0  ) (* (- 0 69993) var1  ) (* 38680 var2  ) ) 0 )
    (< (+ (* 16 var3 var3 var3 var3  ) (* 512 var3 var3 var3  ) (* 6104 var3 var3  ) (* 32128 var3  ) 62985 ) 0 )
)
  (or 
    (< (+ (* 146 var0 var3 var3 var3 var3  ) (* (- 0 143) var1 var3 var3 var3 var3  ) (* 291 var2 var3 var3 var3 var3  ) (* 2843 var0 var3 var3 var3  ) (* (- 0 3178) var1 var3 var3 var3  ) (* 5481 var2 var3 var3 var3  ) (* 19422 var0 var3 var3  ) (* (- 0 24839) var1 var3 var3  ) (* 34717 var2 var3 var3  ) (* 54494 var0 var3  ) (* (- 0 77210) var1 var3  ) (* 80218 var2 var3  ) (* 52794 var0  ) (* (- 0 69993) var1  ) (* 38680 var2  ) ) 0 )
    (> (+ (* 146 var0 var3 var3 var3 var3  ) (* (- 0 143) var1 var3 var3 var3 var3  ) (* 291 var2 var3 var3 var3 var3  ) (* 2843 var0 var3 var3 var3  ) (* (- 0 3178) var1 var3 var3 var3  ) (* 5481 var2 var3 var3 var3  ) (* 19422 var0 var3 var3  ) (* (- 0 24839) var1 var3 var3  ) (* 34717 var2 var3 var3  ) (* 54494 var0 var3  ) (* (- 0 77210) var1 var3  ) (* 80218 var2 var3  ) (* 52794 var0  ) (* (- 0 69993) var1  ) (* 38680 var2  ) ) 0 )
)
))
(check-sat)
(exit)
