(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Chua/2/VC1/U/Chua-2-VC1-U-chunk-0052.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 117649 var0 var0 var0 var0 var0 var0  ) (* (- 0 50421000) var0 var0 var0 var0 var0  ) (* 12605250000 var0 var0 var0 var0  ) (* (- 0 2058000000000) var0 var0 var0  ) (* 220500000000000 var0 var0  ) (* (- 0 15750000000000000) var0  ) 540225000000000000 ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 75) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
