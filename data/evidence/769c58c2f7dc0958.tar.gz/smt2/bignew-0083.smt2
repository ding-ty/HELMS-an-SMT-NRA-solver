(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/atan/problem/1/atan-problem-1-chunk-0069.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 3 var1  ) (* 1 var2  ) ) 0 )
)
  (or 
    (> (+ (* 1 var0  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 800 var0 var0 var1  ) (* (- 0 471) var0 var1  ) (* (- 0 157) var0 var2  ) (* 300 var1  ) (* 100 var2  ) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
))
(check-sat)
(exit)
