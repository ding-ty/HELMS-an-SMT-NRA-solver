(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/atan/problem/1/weak/atan-problem-1-weak-chunk-0040.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0 var0  ) 3 ) 0 )
)
  (or 
    (< (+ (* 8 var0 var0 var0 var1  ) (* 15 var0 var1  ) (* (- 0 3) var0 var2  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
