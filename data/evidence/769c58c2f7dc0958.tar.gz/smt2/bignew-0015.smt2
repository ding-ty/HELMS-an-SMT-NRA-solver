(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20220314-Uncu/Rational_Function_Proof_Calls_With_Basic_Denominator_Simplifications/BDC_ProveIneq_ISSAC10_ex3f.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(assert (and
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (+ (* 1 var1  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (+ (* 1 var1  ) 1 ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) 2 ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) 3 ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) 4 ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) 5 ) 0 )
)
  (or 
    (> (+ (* 9 var0 var1 var1  ) (* (- 0 99) var0 var1  ) (* 272 var0  ) ) 0 )
)
  (or 
    (> (+ (* 81 var0 var1 var1 var1 var1  ) (* (- 0 1620) var0 var1 var1 var1  ) (* 12105 var0 var1 var1  ) (* (- 0 40050) var0 var1  ) (* 49504 var0  ) ) 0 )
)
  (or 
    (> (+ (* 729 var0 var1 var1 var1 var1 var1 var1  ) (* (- 0 19683) var0 var1 var1 var1 var1 var1  ) (* 219915 var0 var1 var1 var1 var1  ) (* (- 0 1301265) var0 var1 var1 var1  ) (* 4300236 var0 var1 var1  ) (* (- 0 7524252) var0 var1  ) (* 5445440 var0  ) ) 0 )
)
  (or 
    (> (+ (* 6561 var0 var1 var1 var1 var1 var1 var1 var1 var1  ) (* (- 0 209952) var0 var1 var1 var1 var1 var1 var1 var1  ) (* 2905794 var0 var1 var1 var1 var1 var1 var1  ) (* (- 0 22709808) var0 var1 var1 var1 var1 var1  ) (* 109574289 var0 var1 var1 var1 var1  ) (* (- 0 334099728) var0 var1 var1 var1  ) (* 628413516 var0 var1 var1  ) (* (- 0 666402912) var0 var1  ) (* 304944640 var0  ) ) 0 )
)
  (or 
    (> (+ (* 59049 var0 var1 var1 var1 var1 var1 var1 var1 var1 var1 var1  ) (* (- 0 2066715) var0 var1 var1 var1 var1 var1 var1 var1 var1 var1  ) (* 31952070 var0 var1 var1 var1 var1 var1 var1 var1 var1  ) (* (- 0 287043750) var0 var1 var1 var1 var1 var1 var1 var1  ) (* 1657449297 var0 var1 var1 var1 var1 var1 var1  ) (* (- 0 6419599515) var0 var1 var1 var1 var1 var1  ) (* 16867900080 var0 var1 var1 var1 var1  ) (* (- 0 29646785700) var0 var1 var1 var1  ) (* 33305650704 var0 var1 var1  ) (* (- 0 21561563520) var0 var1  ) (* 6098892800 var0  ) ) 0 )
)
  (or 
    (< (+ (* 531441 var0 var1 var1 var1 var1 var1 var1 var1 var1 var1 var1 var1 var1  ) (* (- 0 19131876) var0 var1 var1 var1 var1 var1 var1 var1 var1 var1 var1 var1  ) (* 306287163 var0 var1 var1 var1 var1 var1 var1 var1 var1 var1 var1  ) (* (- 0 2875095810) var0 var1 var1 var1 var1 var1 var1 var1 var1 var1  ) (* 17564341563 var0 var1 var1 var1 var1 var1 var1 var1 var1  ) (* (- 0 73267526808) var0 var1 var1 var1 var1 var1 var1 var1  ) (* 212902394949 var0 var1 var1 var1 var1 var1 var1  ) (* (- 0 431471371050) var0 var1 var1 var1 var1 var1  ) (* 600307727796 var0 var1 var1 var1 var1  ) (* (- 0 553098499416) var0 var1 var1 var1  ) (* 315555408288 var0 var1 var1  ) (* (- 0 98013162240) var0 var1  ) (* 12197785600 var0  ) ) 0 )
)
  (or 
    (> (+ (* 3 var1  ) (- 0 17) ) 0 )
    (< (+ (* 3 var1  ) (- 0 17) ) 0 )
)
  (or 
    (> (+ (* 9 var1 var1  ) (* (- 0 93) var1  ) 238 ) 0 )
    (< (+ (* 9 var1 var1  ) (* (- 0 93) var1  ) 238 ) 0 )
)
  (or 
    (> (+ (* 27 var1 var1 var1  ) (* (- 0 378) var1 var1  ) (* 1737 var1  ) (- 0 2618) ) 0 )
    (< (+ (* 27 var1 var1 var1  ) (* (- 0 378) var1 var1  ) (* 1737 var1  ) (- 0 2618) ) 0 )
)
  (or 
    (> (+ (* 81 var1 var1 var1 var1  ) (* (- 0 1350) var1 var1 var1  ) (* 8235 var1 var1  ) (* (- 0 21750) var1  ) 20944 ) 0 )
    (< (+ (* 81 var1 var1 var1 var1  ) (* (- 0 1350) var1 var1 var1  ) (* 8235 var1 var1  ) (* (- 0 21750) var1  ) 20944 ) 0 )
)
  (or 
    (> (+ (* 243 var1 var1 var1 var1 var1  ) (* (- 0 4455) var1 var1 var1 var1  ) (* 31455 var1 var1 var1  ) (* (- 0 106425) var1 var1  ) (* 171582 var1  ) (- 0 104720) ) 0 )
    (< (+ (* 243 var1 var1 var1 var1 var1  ) (* (- 0 4455) var1 var1 var1 var1  ) (* 31455 var1 var1 var1  ) (* (- 0 106425) var1 var1  ) (* 171582 var1  ) (- 0 104720) ) 0 )
)
  (or 
    (> (+ (* 729 var1 var1 var1 var1 var1 var1  ) (* (- 0 13851) var1 var1 var1 var1 var1  ) (* 103275 var1 var1 var1 var1  ) (* (- 0 382185) var1 var1 var1  ) (* 727596 var1 var1  ) (* (- 0 657324) var1  ) 209440 ) 0 )
    (< (+ (* 729 var1 var1 var1 var1 var1 var1  ) (* (- 0 13851) var1 var1 var1 var1 var1  ) (* 103275 var1 var1 var1 var1  ) (* (- 0 382185) var1 var1 var1  ) (* 727596 var1 var1  ) (* (- 0 657324) var1  ) 209440 ) 0 )
)
))
(check-sat)
(exit)
