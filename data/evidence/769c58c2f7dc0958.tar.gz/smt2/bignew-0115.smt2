(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/exp/361/exp-361-neg-6-e-chunk-0216.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 1 var2  ) (- 0 6) ) 0 )
    (< (+ (* 1 var2  ) (- 0 6) ) 0 )
)
  (or 
    (> (+ (* 9999 var0 var0 var0 var0 var0 var0 var0 var0 var1 var1 var1 var1 var1 var1  ) (* (- 0 60006) var0 var0 var0 var0 var0 var0 var0 var1 var1 var1 var1 var1 var1  ) (* 119988 var0 var0 var0 var0 var0 var0 var1 var1 var1 var1 var1 var1  ) (* (- 0 466560000) var0 var0  ) (* (- 0 2799360000) var0  ) (- 0 5598720000) ) 0 )
)
  (or 
    (< (+ (* 10391023 var1  ) (- 0 28245729) ) 0 )
)
  (or 
    (< (+ (* 18089 var1  ) (- 0 49171) ) 0 )
)
  (or 
    (< (+ (* 71 var1  ) (- 0 193) ) 0 )
)
  (or 
    (< (+ (* 7992538801 var1  ) (- 0 21743271936) ) 0 )
)
  (or 
    (> (+ (* 398959 var1  ) (- 0 1084483) ) 0 )
)
  (or 
    (> (+ (* 1001 var1  ) (- 0 2721) ) 0 )
)
  (or 
    (> (+ (* 48427561125 var1  ) (- 0 131639193503) ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) (- 0 2) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
