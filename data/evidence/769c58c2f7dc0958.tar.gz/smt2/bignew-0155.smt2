(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sin/problem/8/sin-problem-8-chunk-0039.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0 var0 var0 var1  ) (* (- 0 6) var0 var1  ) (* 12 var0  ) ) 0 )
)
  (or 
    (< (* 1 var1  )  0 )
)
  (or 
    (> (+ (* 5000000 var1  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10000000 var1  ) (- 0 31415927) ) 0 )
)
  (or 
    (< (+ (* 2 var0  ) (* (- 0 1) var1  ) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (+ (* 1 var0  ) (* (- 0 1) var2  ) ) 0 )
)
))
(check-sat)
(exit)
