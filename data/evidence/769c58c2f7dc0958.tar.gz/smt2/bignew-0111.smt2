(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/cos/problem/12/cos-problem-12-chunk-0007.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 1 var0 var0 var0 var0  ) (* 12 var0 var0 var1 var1  ) (* 1 var1 var1 var1 var1  ) (* (- 0 12) var0 var0  ) (* (- 0 12) var1 var1  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var0  ) (* 1 var1 var1  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (> (+ (* 5000000 var2  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10000000 var2  ) (- 0 31415927) ) 0 )
)
))
(check-sat)
(exit)
