(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Arthan/KM2/ArthanKM2-chunk-0008.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 2 var0 var0 var0 var1  ) (* 8 var0 var0 var0  ) (* 6 var0 var0 var1  ) (* 12 var0 var0 var2  ) (* 1 var0 var1 var1  ) (* 2 var0 var2 var2  ) (* 24 var0 var0  ) (* (- 0 6) var0 var1  ) (* 24 var0 var2  ) (* 1 var1 var1  ) (* (- 0 2) var1 var2  ) (* 2 var2 var2  ) (* 24 var0  ) (* (- 0 10) var1  ) (* 12 var2  ) 8 ) 0 )
)
  (or 
    (> (+ (* 20 var0  ) (- 0 9) ) 0 )
)
))
(check-sat)
(exit)
