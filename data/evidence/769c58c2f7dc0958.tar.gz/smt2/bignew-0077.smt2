(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/RL-high-pass-circuit/RL-high-pass-circuit-gain-chunk-0005.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 5 var2  ) (- 0 4) ) 0 )
)
  (or 
    (> (+ (* 500 var2  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
