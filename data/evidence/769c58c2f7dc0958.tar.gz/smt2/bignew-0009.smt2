(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20200911-Pine/1599122164633784000.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (> (+ (* 10 var2  ) 7 ) 0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 2) ) 0 )
)
  (or 
    (> (+ (* 10 var3  ) 63 ) 0 )
)
  (or 
    (< (+ (* 1 var3  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 89 var2 var2  ) (* (- 0 12) var2 var3  ) (* 7 var3 var3  ) (* (- 0 100) var2  ) (* 24 var3  ) (- 0 143) ) 0 )
)
  (or 
    (< (+ (* 10 var0  ) 7 ) 0 )
    (> (+ (* 1 var0  ) (- 0 2) ) 0 )
    (< (+ (* 10 var1  ) 63 ) 0 )
    (> (+ (* 1 var1  ) (- 0 3) ) 0 )
    (> (+ (* 89 var0 var0  ) (* (- 0 12) var0 var1  ) (* 7 var1 var1  ) (* (- 0 100) var0  ) (* 24 var1  ) (- 0 143) ) 0 )
)
))
(check-sat)
(exit)
