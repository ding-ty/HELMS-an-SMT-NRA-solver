(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sin/problem/10/sin-problem-10-2-chunk-0027.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (> (* 2 var0 var1  )  0 )
)
  (or 
    (< (* 2 var0 var1  )  0 )
)
  (or 
    (< (+ (* 1 var0 var1  ) (* 50 var0  ) (* 50 var1  ) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (+ (* 5 var3  ) (- 0 7) ) 0 )
)
))
(check-sat)
(exit)
