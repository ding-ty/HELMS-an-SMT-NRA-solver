(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/bottom-plate-mixer/bottom-plate-mixer-chunk-0047.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(assert (and
  (or 
    (> (+ (* 3400 var0  ) (* 7383 var1  ) (- 0 760000) ) 0 )
)
  (or 
    (< (+ (* 10000000 var4  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
))
(check-sat)
(exit)
