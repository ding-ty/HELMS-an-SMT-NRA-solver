(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/polypaver/sqrt43-int/4vars/polypaver-sqrt43-int-4vars-chunk-0031.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0 var0 var0 var2  ) (* 1 var0 var0 var1 var1  ) (* 1 var0 var0 var1 var3  ) (* 3 var0 var0 var2  ) (* 2 var0 var1 var1  ) (* 3 var0 var1 var3  ) (* 3 var0 var2  ) (* (- 0 1) var1 var1  ) (* 4 var1 var3  ) (* 1 var2  ) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (+ (* 1 var2 var2  ) (* (- 0 4) var1  ) 4 ) 0 )
)
  (or 
    (> (+ (* 1 var2 var2  ) (* 4 var1  ) (* (- 0 4) var2  ) ) 0 )
)
  (or 
    (< (+ (* 85070591730234615865843651857942052864 var3  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 32 var0  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 32 var0  ) 1 ) 0 )
)
  (or 
    (> (+ (* 85070591730234615865843651857942052864 var3  ) 1 ) 0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 2) ) 0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 3) ) 0 )
)
  (or 
    (> (+ (* 2 var2  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
))
(check-sat)
(exit)
