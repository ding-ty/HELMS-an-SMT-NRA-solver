(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/polypaver/sqrt43-int/polypaver-sqrt43-int-chunk-0050.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(assert (and
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 4) var1  ) 4 ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (* (- 0 4) var0  ) (* 4 var1  ) ) 0 )
)
  (or 
    (< (+ (* 85070591730234615865843651857942052864 var7  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 85070591730234615865843651857942052864 var6  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 85070591730234615865843651857942052864 var5  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 32 var4  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 32 var3  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 32 var2  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 32 var4  ) 1 ) 0 )
)
  (or 
    (> (+ (* 32 var3  ) 1 ) 0 )
)
  (or 
    (> (+ (* 32 var2  ) 1 ) 0 )
)
  (or 
    (> (+ (* 85070591730234615865843651857942052864 var7  ) 1 ) 0 )
)
  (or 
    (> (+ (* 85070591730234615865843651857942052864 var6  ) 1 ) 0 )
)
  (or 
    (> (+ (* 85070591730234615865843651857942052864 var5  ) 1 ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 2) ) 0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 3) ) 0 )
)
  (or 
    (> (+ (* 2 var0  ) (- 0 1) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
))
(check-sat)
(exit)
