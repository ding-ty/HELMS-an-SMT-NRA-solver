(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sqrt/problem/13/sqrt-problem-13-chunk-0024.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (< (+ (* 500 var0 var2  ) (* 500 var0 var3  ) (* (- 0 957) var1 var2  ) (* 957 var1 var3  ) (* 2000 var0  ) (* (- 0 1914) var2  ) (* 1914 var3  ) ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) 2 ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
