(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/atan/problem/2/sqrt/atan-problem-2-sqrt-chunk-0041.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0 var0 var0 var0  ) (* 1 var0 var0 var1 var1  ) (* 1 var0 var0 var2 var2  ) (* 1 var1 var1 var2 var2  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 2) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
    (< (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
