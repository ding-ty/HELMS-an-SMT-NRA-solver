(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sqrt/1mcosq/8/sqrt-1mcosq-8-chunk-0208.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 182) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 24024 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 2162160) var0 var0 var0 var0 var0 var0 var0 var0  ) (* 121080960 var0 var0 var0 var0 var0 var0  ) (* (- 0 3632428800) var0 var0 var0 var0  ) (* 43589145600 var0 var0  ) (- 0 87178291200) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 364) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 81172 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 13069056) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 1606340736 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 155225790720) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 11902016206080 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 714164561510400) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 32494487548723200 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 1072318089107865600) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 24127157004926976000 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 337780198068977664000) var0 var0 var0 var0 var0 var0  ) (* 2533351485517332480000 var0 var0 var0 var0  ) (* (- 0 7600054456551997440000) var0 var0  ) ) 0 )
)
  (or 
    (> (+ (* 1 var0  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (> (+ (* 10 var2  ) (- 0 1) ) 0 )
)
  (or 
    (< (+ (* 10000000 var1  ) (- 0 31415927) ) 0 )
)
  (or 
    (> (+ (* 5000000 var1  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10 var0  ) (* (- 0 5) var1  ) 2 ) 0 )
)
))
(check-sat)
(exit)
