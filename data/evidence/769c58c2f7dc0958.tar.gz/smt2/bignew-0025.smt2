(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
LassoRanker/CooperatingT2/nested.t2.c_Iteration4_Loop_3-pieceTemplate.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(declare-fun var8 () Real)
(declare-fun var9 () Real)
(declare-fun var10 () Real)
(declare-fun var11 () Real)
(declare-fun var12 () Real)
(declare-fun var13 () Real)
(declare-fun var14 () Real)
(declare-fun var15 () Real)
(declare-fun var16 () Real)
(declare-fun var17 () Real)
(declare-fun var18 () Real)
(declare-fun var19 () Real)
(declare-fun var20 () Real)
(declare-fun var21 () Real)
(declare-fun var22 () Real)
(declare-fun var23 () Real)
(declare-fun var24 () Real)
(declare-fun var25 () Real)
(declare-fun var26 () Real)
(declare-fun var27 () Real)
(declare-fun var28 () Real)
(declare-fun var29 () Real)
(declare-fun var30 () Real)
(declare-fun var31 () Real)
(declare-fun var32 () Real)
(declare-fun var33 () Real)
(declare-fun var34 () Real)
(declare-fun var35 () Real)
(declare-fun var36 () Real)
(declare-fun var37 () Real)
(declare-fun var38 () Real)
(declare-fun var39 () Real)
(declare-fun var40 () Real)
(declare-fun var41 () Real)
(declare-fun var42 () Real)
(declare-fun var43 () Real)
(declare-fun var44 () Real)
(declare-fun var45 () Real)
(declare-fun var46 () Real)
(declare-fun var47 () Real)
(declare-fun var48 () Real)
(declare-fun var49 () Real)
(declare-fun var50 () Real)
(declare-fun var51 () Real)
(declare-fun var52 () Real)
(declare-fun var53 () Real)
(declare-fun var54 () Real)
(declare-fun var55 () Real)
(declare-fun var56 () Real)
(declare-fun var57 () Real)
(declare-fun var58 () Real)
(declare-fun var59 () Real)
(declare-fun var60 () Real)
(declare-fun var61 () Real)
(declare-fun var62 () Real)
(declare-fun var63 () Real)
(declare-fun var64 () Real)
(declare-fun var65 () Real)
(declare-fun var66 () Real)
(declare-fun var67 () Real)
(declare-fun var68 () Real)
(declare-fun var69 () Real)
(declare-fun var70 () Real)
(declare-fun var71 () Real)
(declare-fun var72 () Real)
(declare-fun var73 () Real)
(declare-fun var74 () Real)
(declare-fun var75 () Real)
(declare-fun var76 () Real)
(declare-fun var77 () Real)
(declare-fun var78 () Real)
(declare-fun var79 () Real)
(declare-fun var80 () Real)
(declare-fun var81 () Real)
(declare-fun var82 () Real)
(declare-fun var83 () Real)
(declare-fun var84 () Real)
(declare-fun var85 () Real)
(declare-fun var86 () Real)
(declare-fun var87 () Real)
(declare-fun var88 () Real)
(declare-fun var89 () Real)
(declare-fun var90 () Real)
(declare-fun var91 () Real)
(declare-fun var92 () Real)
(declare-fun var93 () Real)
(declare-fun var94 () Real)
(declare-fun var95 () Real)
(declare-fun var96 () Real)
(declare-fun var97 () Real)
(declare-fun var98 () Real)
(declare-fun var99 () Real)
(declare-fun var100 () Real)
(declare-fun var101 () Real)
(declare-fun var102 () Real)
(declare-fun var103 () Real)
(declare-fun var104 () Real)
(declare-fun var105 () Real)
(declare-fun var106 () Real)
(declare-fun var107 () Real)
(declare-fun var108 () Real)
(declare-fun var109 () Real)
(declare-fun var110 () Real)
(declare-fun var111 () Real)
(declare-fun var112 () Real)
(declare-fun var113 () Real)
(declare-fun var114 () Real)
(declare-fun var115 () Real)
(declare-fun var116 () Real)
(declare-fun var117 () Real)
(declare-fun var118 () Real)
(declare-fun var119 () Real)
(declare-fun var120 () Real)
(declare-fun var121 () Real)
(declare-fun var122 () Real)
(declare-fun var123 () Real)
(declare-fun var124 () Real)
(declare-fun var125 () Real)
(declare-fun var126 () Real)
(declare-fun var127 () Real)
(declare-fun var128 () Real)
(declare-fun var129 () Real)
(declare-fun var130 () Real)
(declare-fun var131 () Real)
(declare-fun var132 () Real)
(declare-fun var133 () Real)
(declare-fun var134 () Real)
(declare-fun var135 () Real)
(declare-fun var136 () Real)
(declare-fun var137 () Real)
(declare-fun var138 () Real)
(declare-fun var139 () Real)
(declare-fun var140 () Real)
(declare-fun var141 () Real)
(declare-fun var142 () Real)
(declare-fun var143 () Real)
(declare-fun var144 () Real)
(declare-fun var145 () Real)
(declare-fun var146 () Real)
(declare-fun var147 () Real)
(declare-fun var148 () Real)
(declare-fun var149 () Real)
(declare-fun var150 () Real)
(declare-fun var151 () Real)
(declare-fun var152 () Real)
(declare-fun var153 () Real)
(declare-fun var154 () Real)
(declare-fun var155 () Real)
(declare-fun var156 () Real)
(declare-fun var157 () Real)
(declare-fun var158 () Real)
(declare-fun var159 () Real)
(declare-fun var160 () Real)
(declare-fun var161 () Real)
(declare-fun var162 () Real)
(declare-fun var163 () Real)
(declare-fun var164 () Real)
(declare-fun var165 () Real)
(declare-fun var166 () Real)
(declare-fun var167 () Real)
(declare-fun var168 () Real)
(declare-fun var169 () Real)
(declare-fun var170 () Real)
(declare-fun var171 () Real)
(declare-fun var172 () Real)
(declare-fun var173 () Real)
(declare-fun var174 () Real)
(declare-fun var175 () Real)
(declare-fun var176 () Real)
(declare-fun var177 () Real)
(declare-fun var178 () Real)
(declare-fun var179 () Real)
(declare-fun var180 () Real)
(declare-fun var181 () Real)
(declare-fun var182 () Real)
(declare-fun var183 () Real)
(declare-fun var184 () Real)
(declare-fun var185 () Real)
(declare-fun var186 () Real)
(declare-fun var187 () Real)
(declare-fun var188 () Real)
(declare-fun var189 () Real)
(declare-fun var190 () Real)
(declare-fun var191 () Real)
(declare-fun var192 () Real)
(declare-fun var193 () Real)
(declare-fun var194 () Real)
(declare-fun var195 () Real)
(declare-fun var196 () Real)
(declare-fun var197 () Real)
(declare-fun var198 () Real)
(declare-fun var199 () Real)
(declare-fun var200 () Real)
(declare-fun var201 () Real)
(declare-fun var202 () Real)
(declare-fun var203 () Real)
(declare-fun var204 () Real)
(declare-fun var205 () Real)
(declare-fun var206 () Real)
(declare-fun var207 () Real)
(declare-fun var208 () Real)
(declare-fun var209 () Real)
(declare-fun var210 () Real)
(declare-fun var211 () Real)
(declare-fun var212 () Real)
(declare-fun var213 () Real)
(declare-fun var214 () Real)
(declare-fun var215 () Real)
(declare-fun var216 () Real)
(declare-fun var217 () Real)
(declare-fun var218 () Real)
(declare-fun var219 () Real)
(declare-fun var220 () Real)
(declare-fun var221 () Real)
(declare-fun var222 () Real)
(declare-fun var223 () Real)
(declare-fun var224 () Real)
(declare-fun var225 () Real)
(declare-fun var226 () Real)
(declare-fun var227 () Real)
(declare-fun var228 () Real)
(declare-fun var229 () Real)
(declare-fun var230 () Real)
(declare-fun var231 () Real)
(declare-fun var232 () Real)
(declare-fun var233 () Real)
(declare-fun var234 () Real)
(declare-fun var235 () Real)
(declare-fun var236 () Real)
(declare-fun var237 () Real)
(declare-fun var238 () Real)
(declare-fun var239 () Real)
(declare-fun var240 () Real)
(declare-fun var241 () Real)
(declare-fun var242 () Real)
(declare-fun var243 () Real)
(declare-fun var244 () Real)
(declare-fun var245 () Real)
(declare-fun var246 () Real)
(declare-fun var247 () Real)
(declare-fun var248 () Real)
(declare-fun var249 () Real)
(declare-fun var250 () Real)
(declare-fun var251 () Real)
(declare-fun var252 () Real)
(declare-fun var253 () Real)
(declare-fun var254 () Real)
(declare-fun var255 () Real)
(declare-fun var256 () Real)
(declare-fun var257 () Real)
(declare-fun var258 () Real)
(declare-fun var259 () Real)
(declare-fun var260 () Real)
(declare-fun var261 () Real)
(declare-fun var262 () Real)
(declare-fun var263 () Real)
(declare-fun var264 () Real)
(declare-fun var265 () Real)
(declare-fun var266 () Real)
(declare-fun var267 () Real)
(declare-fun var268 () Real)
(declare-fun var269 () Real)
(declare-fun var270 () Real)
(declare-fun var271 () Real)
(declare-fun var272 () Real)
(declare-fun var273 () Real)
(declare-fun var274 () Real)
(declare-fun var275 () Real)
(declare-fun var276 () Real)
(declare-fun var277 () Real)
(declare-fun var278 () Real)
(declare-fun var279 () Real)
(declare-fun var280 () Real)
(declare-fun var281 () Real)
(declare-fun var282 () Real)
(declare-fun var283 () Real)
(declare-fun var284 () Real)
(declare-fun var285 () Real)
(declare-fun var286 () Real)
(declare-fun var287 () Real)
(declare-fun var288 () Real)
(declare-fun var289 () Real)
(declare-fun var290 () Real)
(declare-fun var291 () Real)
(declare-fun var292 () Real)
(declare-fun var293 () Real)
(declare-fun var294 () Real)
(declare-fun var295 () Real)
(declare-fun var296 () Real)
(declare-fun var297 () Real)
(declare-fun var298 () Real)
(declare-fun var299 () Real)
(declare-fun var300 () Real)
(declare-fun var301 () Real)
(declare-fun var302 () Real)
(declare-fun var303 () Real)
(declare-fun var304 () Real)
(declare-fun var305 () Real)
(declare-fun var306 () Real)
(declare-fun var307 () Real)
(declare-fun var308 () Real)
(declare-fun var309 () Real)
(declare-fun var310 () Real)
(declare-fun var311 () Real)
(declare-fun var312 () Real)
(declare-fun var313 () Real)
(declare-fun var314 () Real)
(declare-fun var315 () Real)
(declare-fun var316 () Real)
(declare-fun var317 () Real)
(declare-fun var318 () Real)
(declare-fun var319 () Real)
(declare-fun var320 () Real)
(declare-fun var321 () Real)
(declare-fun var322 () Real)
(declare-fun var323 () Real)
(declare-fun var324 () Real)
(declare-fun var325 () Real)
(declare-fun var326 () Real)
(declare-fun var327 () Real)
(declare-fun var328 () Real)
(declare-fun var329 () Real)
(declare-fun var330 () Real)
(declare-fun var331 () Real)
(declare-fun var332 () Real)
(declare-fun var333 () Real)
(declare-fun var334 () Real)
(declare-fun var335 () Real)
(declare-fun var336 () Real)
(declare-fun var337 () Real)
(declare-fun var338 () Real)
(declare-fun var339 () Real)
(declare-fun var340 () Real)
(declare-fun var341 () Real)
(declare-fun var342 () Real)
(declare-fun var343 () Real)
(declare-fun var344 () Real)
(declare-fun var345 () Real)
(declare-fun var346 () Real)
(declare-fun var347 () Real)
(declare-fun var348 () Real)
(declare-fun var349 () Real)
(declare-fun var350 () Real)
(declare-fun var351 () Real)
(declare-fun var352 () Real)
(declare-fun var353 () Real)
(declare-fun var354 () Real)
(declare-fun var355 () Real)
(declare-fun var356 () Real)
(declare-fun var357 () Real)
(declare-fun var358 () Real)
(declare-fun var359 () Real)
(declare-fun var360 () Real)
(declare-fun var361 () Real)
(declare-fun var362 () Real)
(declare-fun var363 () Real)
(declare-fun var364 () Real)
(declare-fun var365 () Real)
(declare-fun var366 () Real)
(declare-fun var367 () Real)
(declare-fun var368 () Real)
(declare-fun var369 () Real)
(declare-fun var370 () Real)
(declare-fun var371 () Real)
(declare-fun var372 () Real)
(declare-fun var373 () Real)
(declare-fun var374 () Real)
(declare-fun var375 () Real)
(declare-fun var376 () Real)
(declare-fun var377 () Real)
(declare-fun var378 () Real)
(declare-fun var379 () Real)
(declare-fun var380 () Real)
(declare-fun var381 () Real)
(declare-fun var382 () Real)
(declare-fun var383 () Real)
(declare-fun var384 () Real)
(declare-fun var385 () Real)
(declare-fun var386 () Real)
(declare-fun var387 () Real)
(declare-fun var388 () Real)
(declare-fun var389 () Real)
(declare-fun var390 () Real)
(declare-fun var391 () Real)
(declare-fun var392 () Real)
(declare-fun var393 () Real)
(declare-fun var394 () Real)
(declare-fun var395 () Real)
(declare-fun var396 () Real)
(declare-fun var397 () Real)
(declare-fun var398 () Real)
(declare-fun var399 () Real)
(declare-fun var400 () Real)
(declare-fun var401 () Real)
(declare-fun var402 () Real)
(declare-fun var403 () Real)
(declare-fun var404 () Real)
(declare-fun var405 () Real)
(assert (and
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var62  )  0 )
)
  (or 
    (> (* 1 var63  )  0 )
)
  (or 
    (> (* 1 var64  )  0 )
)
  (or 
    (> (* 1 var65  )  0 )
)
  (or 
    (> (* 1 var66  )  0 )
)
  (or 
    (> (* 1 var67  )  0 )
)
  (or 
    (> (* 1 var68  )  0 )
)
  (or 
    (> (* 1 var69  )  0 )
)
  (or 
    (> (* 1 var70  )  0 )
)
  (or 
    (> (* 1 var71  )  0 )
)
  (or 
    (> (* 1 var72  )  0 )
)
  (or 
    (> (* 1 var73  )  0 )
)
  (or 
    (> (* 1 var74  )  0 )
)
  (or 
    (< (+ (* 1 var0 var73  ) (* 1 var11 var71  ) (* 1 var11 var72  ) (* 1 var61 var74  ) (* (- 0 1) var62  ) (* 1 var63  ) (* (- 0 1) var64  ) (* 1 var65  ) (* (- 0 1) var66  ) (* 1 var67  ) (* 1 var68  ) (* (- 0 1) var69  ) (* (- 0 1) var70  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var73  ) (* 1 var11 var71  ) (* 1 var11 var72  ) (* 1 var61 var74  ) (* (- 0 1) var62  ) (* 1 var63  ) (* (- 0 1) var64  ) (* 1 var65  ) (* (- 0 1) var66  ) (* 1 var67  ) (* 1 var68  ) (* (- 0 1) var69  ) (* (- 0 1) var70  ) ) 0 )
)
  (or 
    (> (* 1 var76  )  0 )
)
  (or 
    (> (* 1 var77  )  0 )
)
  (or 
    (> (* 1 var78  )  0 )
)
  (or 
    (> (* 1 var79  )  0 )
)
  (or 
    (> (* 1 var80  )  0 )
)
  (or 
    (> (* 1 var81  )  0 )
)
  (or 
    (> (* 1 var82  )  0 )
)
  (or 
    (> (* 1 var83  )  0 )
)
  (or 
    (> (* 1 var84  )  0 )
)
  (or 
    (> (* 1 var85  )  0 )
)
  (or 
    (> (* 1 var86  )  0 )
)
  (or 
    (> (* 1 var87  )  0 )
)
  (or 
    (> (* 1 var88  )  0 )
)
  (or 
    (< (+ (* 1 var0 var87  ) (* (- 0 1) var1 var87  ) (* 1 var11 var85  ) (* 1 var21 var87  ) (* 1 var31 var86  ) (* 1 var75 var88  ) (* (- 0 1) var76  ) (* 1 var77  ) (* (- 0 1) var78  ) (* 1 var79  ) (* (- 0 1) var80  ) (* 1 var81  ) (* 1 var82  ) (* (- 0 1) var83  ) (* (- 0 1) var84  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var87  ) (* (- 0 1) var1 var87  ) (* 1 var11 var85  ) (* 1 var21 var87  ) (* 1 var31 var86  ) (* 1 var75 var88  ) (* (- 0 1) var76  ) (* 1 var77  ) (* (- 0 1) var78  ) (* 1 var79  ) (* (- 0 1) var80  ) (* 1 var81  ) (* 1 var82  ) (* (- 0 1) var83  ) (* (- 0 1) var84  ) ) 0 )
)
  (or 
    (> (* 1 var90  )  0 )
)
  (or 
    (> (* 1 var91  )  0 )
)
  (or 
    (> (* 1 var92  )  0 )
)
  (or 
    (> (* 1 var93  )  0 )
)
  (or 
    (> (* 1 var94  )  0 )
)
  (or 
    (> (* 1 var95  )  0 )
)
  (or 
    (> (* 1 var96  )  0 )
)
  (or 
    (> (* 1 var97  )  0 )
)
  (or 
    (> (* 1 var98  )  0 )
)
  (or 
    (> (* 1 var99  )  0 )
)
  (or 
    (> (* 1 var100  )  0 )
)
  (or 
    (> (* 1 var101  )  0 )
)
  (or 
    (> (* 1 var102  )  0 )
)
  (or 
    (< (+ (* 1 var0 var101  ) (* (- 0 1) var1 var101  ) (* 1 var11 var99  ) (* 1 var41 var101  ) (* 1 var51 var100  ) (* 1 var89 var102  ) (* (- 0 1) var90  ) (* 1 var91  ) (* (- 0 1) var92  ) (* 1 var93  ) (* (- 0 1) var94  ) (* 1 var95  ) (* 1 var96  ) (* (- 0 1) var97  ) (* (- 0 1) var98  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var101  ) (* (- 0 1) var1 var101  ) (* 1 var11 var99  ) (* 1 var41 var101  ) (* 1 var51 var100  ) (* 1 var89 var102  ) (* (- 0 1) var90  ) (* 1 var91  ) (* (- 0 1) var92  ) (* 1 var93  ) (* (- 0 1) var94  ) (* 1 var95  ) (* 1 var96  ) (* (- 0 1) var97  ) (* (- 0 1) var98  ) ) 0 )
)
  (or 
    (> (* 1 var104  )  0 )
)
  (or 
    (> (* 1 var105  )  0 )
)
  (or 
    (> (* 1 var106  )  0 )
)
  (or 
    (> (* 1 var107  )  0 )
)
  (or 
    (> (* 1 var108  )  0 )
)
  (or 
    (> (* 1 var109  )  0 )
)
  (or 
    (> (* 1 var110  )  0 )
)
  (or 
    (> (* 1 var111  )  0 )
)
  (or 
    (> (* 1 var112  )  0 )
)
  (or 
    (> (* 1 var113  )  0 )
)
  (or 
    (> (* 1 var114  )  0 )
)
  (or 
    (> (* 1 var115  )  0 )
)
  (or 
    (> (* 1 var116  )  0 )
)
  (or 
    (< (+ (* 1 var0 var115  ) (* 1 var1 var115  ) (* 1 var11 var114  ) (* (- 0 1) var21 var115  ) (* 1 var31 var113  ) (* 1 var103 var116  ) (* (- 0 1) var104  ) (* 1 var105  ) (* (- 0 1) var106  ) (* 1 var107  ) (* (- 0 1) var108  ) (* 1 var109  ) (* 1 var110  ) (* (- 0 1) var111  ) (* (- 0 1) var112  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var115  ) (* 1 var1 var115  ) (* 1 var11 var114  ) (* (- 0 1) var21 var115  ) (* 1 var31 var113  ) (* 1 var103 var116  ) (* (- 0 1) var104  ) (* 1 var105  ) (* (- 0 1) var106  ) (* 1 var107  ) (* (- 0 1) var108  ) (* 1 var109  ) (* 1 var110  ) (* (- 0 1) var111  ) (* (- 0 1) var112  ) ) 0 )
)
  (or 
    (> (* 1 var118  )  0 )
)
  (or 
    (> (* 1 var119  )  0 )
)
  (or 
    (> (* 1 var120  )  0 )
)
  (or 
    (> (* 1 var121  )  0 )
)
  (or 
    (> (* 1 var122  )  0 )
)
  (or 
    (> (* 1 var123  )  0 )
)
  (or 
    (> (* 1 var124  )  0 )
)
  (or 
    (> (* 1 var125  )  0 )
)
  (or 
    (> (* 1 var126  )  0 )
)
  (or 
    (> (* 1 var127  )  0 )
)
  (or 
    (> (* 1 var128  )  0 )
)
  (or 
    (> (* 1 var129  )  0 )
)
  (or 
    (> (* 1 var130  )  0 )
)
  (or 
    (< (+ (* 1 var0 var129  ) (* 1 var31 var127  ) (* 1 var31 var128  ) (* 1 var117 var130  ) (* (- 0 1) var118  ) (* 1 var119  ) (* (- 0 1) var120  ) (* 1 var121  ) (* (- 0 1) var122  ) (* 1 var123  ) (* 1 var124  ) (* (- 0 1) var125  ) (* (- 0 1) var126  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var129  ) (* 1 var31 var127  ) (* 1 var31 var128  ) (* 1 var117 var130  ) (* (- 0 1) var118  ) (* 1 var119  ) (* (- 0 1) var120  ) (* 1 var121  ) (* (- 0 1) var122  ) (* 1 var123  ) (* 1 var124  ) (* (- 0 1) var125  ) (* (- 0 1) var126  ) ) 0 )
)
  (or 
    (> (* 1 var132  )  0 )
)
  (or 
    (> (* 1 var133  )  0 )
)
  (or 
    (> (* 1 var134  )  0 )
)
  (or 
    (> (* 1 var135  )  0 )
)
  (or 
    (> (* 1 var136  )  0 )
)
  (or 
    (> (* 1 var137  )  0 )
)
  (or 
    (> (* 1 var138  )  0 )
)
  (or 
    (> (* 1 var139  )  0 )
)
  (or 
    (> (* 1 var140  )  0 )
)
  (or 
    (> (* 1 var141  )  0 )
)
  (or 
    (> (* 1 var142  )  0 )
)
  (or 
    (> (* 1 var143  )  0 )
)
  (or 
    (> (* 1 var144  )  0 )
)
  (or 
    (< (+ (* 1 var0 var143  ) (* (- 0 1) var21 var143  ) (* 1 var31 var141  ) (* 1 var41 var143  ) (* 1 var51 var142  ) (* 1 var131 var144  ) (* (- 0 1) var132  ) (* 1 var133  ) (* (- 0 1) var134  ) (* 1 var135  ) (* (- 0 1) var136  ) (* 1 var137  ) (* 1 var138  ) (* (- 0 1) var139  ) (* (- 0 1) var140  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var143  ) (* (- 0 1) var21 var143  ) (* 1 var31 var141  ) (* 1 var41 var143  ) (* 1 var51 var142  ) (* 1 var131 var144  ) (* (- 0 1) var132  ) (* 1 var133  ) (* (- 0 1) var134  ) (* 1 var135  ) (* (- 0 1) var136  ) (* 1 var137  ) (* 1 var138  ) (* (- 0 1) var139  ) (* (- 0 1) var140  ) ) 0 )
)
  (or 
    (> (* 1 var146  )  0 )
)
  (or 
    (> (* 1 var147  )  0 )
)
  (or 
    (> (* 1 var148  )  0 )
)
  (or 
    (> (* 1 var149  )  0 )
)
  (or 
    (> (* 1 var150  )  0 )
)
  (or 
    (> (* 1 var151  )  0 )
)
  (or 
    (> (* 1 var152  )  0 )
)
  (or 
    (> (* 1 var153  )  0 )
)
  (or 
    (> (* 1 var154  )  0 )
)
  (or 
    (> (* 1 var155  )  0 )
)
  (or 
    (> (* 1 var156  )  0 )
)
  (or 
    (> (* 1 var157  )  0 )
)
  (or 
    (> (* 1 var158  )  0 )
)
  (or 
    (< (+ (* 1 var0 var157  ) (* 1 var1 var157  ) (* 1 var11 var156  ) (* (- 0 1) var41 var157  ) (* 1 var51 var155  ) (* 1 var145 var158  ) (* (- 0 1) var146  ) (* 1 var147  ) (* (- 0 1) var148  ) (* 1 var149  ) (* (- 0 1) var150  ) (* 1 var151  ) (* 1 var152  ) (* (- 0 1) var153  ) (* (- 0 1) var154  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var157  ) (* 1 var1 var157  ) (* 1 var11 var156  ) (* (- 0 1) var41 var157  ) (* 1 var51 var155  ) (* 1 var145 var158  ) (* (- 0 1) var146  ) (* 1 var147  ) (* (- 0 1) var148  ) (* 1 var149  ) (* (- 0 1) var150  ) (* 1 var151  ) (* 1 var152  ) (* (- 0 1) var153  ) (* (- 0 1) var154  ) ) 0 )
)
  (or 
    (> (* 1 var160  )  0 )
)
  (or 
    (> (* 1 var161  )  0 )
)
  (or 
    (> (* 1 var162  )  0 )
)
  (or 
    (> (* 1 var163  )  0 )
)
  (or 
    (> (* 1 var164  )  0 )
)
  (or 
    (> (* 1 var165  )  0 )
)
  (or 
    (> (* 1 var166  )  0 )
)
  (or 
    (> (* 1 var167  )  0 )
)
  (or 
    (> (* 1 var168  )  0 )
)
  (or 
    (> (* 1 var169  )  0 )
)
  (or 
    (> (* 1 var170  )  0 )
)
  (or 
    (> (* 1 var171  )  0 )
)
  (or 
    (> (* 1 var172  )  0 )
)
  (or 
    (< (+ (* 1 var0 var171  ) (* 1 var21 var171  ) (* 1 var31 var170  ) (* (- 0 1) var41 var171  ) (* 1 var51 var169  ) (* 1 var159 var172  ) (* (- 0 1) var160  ) (* 1 var161  ) (* (- 0 1) var162  ) (* 1 var163  ) (* (- 0 1) var164  ) (* 1 var165  ) (* 1 var166  ) (* (- 0 1) var167  ) (* (- 0 1) var168  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var171  ) (* 1 var21 var171  ) (* 1 var31 var170  ) (* (- 0 1) var41 var171  ) (* 1 var51 var169  ) (* 1 var159 var172  ) (* (- 0 1) var160  ) (* 1 var161  ) (* (- 0 1) var162  ) (* 1 var163  ) (* (- 0 1) var164  ) (* 1 var165  ) (* 1 var166  ) (* (- 0 1) var167  ) (* (- 0 1) var168  ) ) 0 )
)
  (or 
    (> (* 1 var174  )  0 )
)
  (or 
    (> (* 1 var175  )  0 )
)
  (or 
    (> (* 1 var176  )  0 )
)
  (or 
    (> (* 1 var177  )  0 )
)
  (or 
    (> (* 1 var178  )  0 )
)
  (or 
    (> (* 1 var179  )  0 )
)
  (or 
    (> (* 1 var180  )  0 )
)
  (or 
    (> (* 1 var181  )  0 )
)
  (or 
    (> (* 1 var182  )  0 )
)
  (or 
    (> (* 1 var183  )  0 )
)
  (or 
    (> (* 1 var184  )  0 )
)
  (or 
    (> (* 1 var185  )  0 )
)
  (or 
    (> (* 1 var186  )  0 )
)
  (or 
    (< (+ (* 1 var0 var185  ) (* 1 var51 var183  ) (* 1 var51 var184  ) (* 1 var173 var186  ) (* (- 0 1) var174  ) (* 1 var175  ) (* (- 0 1) var176  ) (* 1 var177  ) (* (- 0 1) var178  ) (* 1 var179  ) (* 1 var180  ) (* (- 0 1) var181  ) (* (- 0 1) var182  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var185  ) (* 1 var51 var183  ) (* 1 var51 var184  ) (* 1 var173 var186  ) (* (- 0 1) var174  ) (* 1 var175  ) (* (- 0 1) var176  ) (* 1 var177  ) (* (- 0 1) var178  ) (* 1 var179  ) (* 1 var180  ) (* (- 0 1) var181  ) (* (- 0 1) var182  ) ) 0 )
)
  (or 
    (> (* 1 var188  )  0 )
)
  (or 
    (> (* 1 var189  )  0 )
)
  (or 
    (> (* 1 var190  )  0 )
)
  (or 
    (> (* 1 var191  )  0 )
)
  (or 
    (> (* 1 var192  )  0 )
)
  (or 
    (> (* 1 var193  )  0 )
)
  (or 
    (> (* 1 var194  )  0 )
)
  (or 
    (> (* 1 var195  )  0 )
)
  (or 
    (> (* 1 var196  )  0 )
)
  (or 
    (> (* 1 var197  )  0 )
)
  (or 
    (> (* 1 var198  )  0 )
)
  (or 
    (> (+ (* 1 var1 var197  ) (* (- 0 1) var187 var198  ) (* 1 var188  ) (* (- 0 1) var189  ) (* 1 var190  ) (* (- 0 1) var191  ) (* 1 var192  ) (* (- 0 1) var193  ) (* (- 0 1) var194  ) (* 1 var195  ) (* 1 var196  ) ) 0 )
)
  (or 
    (> (+ (* 1 var1 var197  ) (* (- 0 1) var187 var198  ) (* 1 var188  ) (* (- 0 1) var189  ) (* 1 var190  ) (* (- 0 1) var191  ) (* 1 var192  ) (* (- 0 1) var193  ) (* (- 0 1) var194  ) (* 1 var195  ) (* 1 var196  ) ) 0 )
)
  (or 
    (> (* 1 var200  )  0 )
)
  (or 
    (> (* 1 var201  )  0 )
)
  (or 
    (> (* 1 var202  )  0 )
)
  (or 
    (> (* 1 var203  )  0 )
)
  (or 
    (> (* 1 var204  )  0 )
)
  (or 
    (> (* 1 var205  )  0 )
)
  (or 
    (> (* 1 var206  )  0 )
)
  (or 
    (> (* 1 var207  )  0 )
)
  (or 
    (> (* 1 var208  )  0 )
)
  (or 
    (> (* 1 var209  )  0 )
)
  (or 
    (> (* 1 var210  )  0 )
)
  (or 
    (> (+ (* 1 var21 var209  ) (* (- 0 1) var199 var210  ) (* 1 var200  ) (* (- 0 1) var201  ) (* 1 var202  ) (* (- 0 1) var203  ) (* 1 var204  ) (* (- 0 1) var205  ) (* (- 0 1) var206  ) (* 1 var207  ) (* 1 var208  ) ) 0 )
)
  (or 
    (> (+ (* 1 var21 var209  ) (* (- 0 1) var199 var210  ) (* 1 var200  ) (* (- 0 1) var201  ) (* 1 var202  ) (* (- 0 1) var203  ) (* 1 var204  ) (* (- 0 1) var205  ) (* (- 0 1) var206  ) (* 1 var207  ) (* 1 var208  ) ) 0 )
)
  (or 
    (> (* 1 var212  )  0 )
)
  (or 
    (> (* 1 var213  )  0 )
)
  (or 
    (> (* 1 var214  )  0 )
)
  (or 
    (> (* 1 var215  )  0 )
)
  (or 
    (> (* 1 var216  )  0 )
)
  (or 
    (> (* 1 var217  )  0 )
)
  (or 
    (> (* 1 var218  )  0 )
)
  (or 
    (> (* 1 var219  )  0 )
)
  (or 
    (> (* 1 var220  )  0 )
)
  (or 
    (> (* 1 var221  )  0 )
)
  (or 
    (> (* 1 var222  )  0 )
)
  (or 
    (> (+ (* 1 var41 var221  ) (* (- 0 1) var211 var222  ) (* 1 var212  ) (* (- 0 1) var213  ) (* 1 var214  ) (* (- 0 1) var215  ) (* 1 var216  ) (* (- 0 1) var217  ) (* (- 0 1) var218  ) (* 1 var219  ) (* 1 var220  ) ) 0 )
)
  (or 
    (> (+ (* 1 var41 var221  ) (* (- 0 1) var211 var222  ) (* 1 var212  ) (* (- 0 1) var213  ) (* 1 var214  ) (* (- 0 1) var215  ) (* 1 var216  ) (* (- 0 1) var217  ) (* (- 0 1) var218  ) (* 1 var219  ) (* 1 var220  ) ) 0 )
)
  (or 
    (> (* 1 var224  )  0 )
)
  (or 
    (> (* 1 var225  )  0 )
)
  (or 
    (> (* 1 var226  )  0 )
)
  (or 
    (> (* 1 var227  )  0 )
)
  (or 
    (> (* 1 var228  )  0 )
)
  (or 
    (> (* 1 var229  )  0 )
)
  (or 
    (> (* 1 var230  )  0 )
)
  (or 
    (> (* 1 var231  )  0 )
)
  (or 
    (> (* 1 var232  )  0 )
)
  (or 
    (> (* 1 var233  )  0 )
)
  (or 
    (> (* 1 var234  )  0 )
)
  (or 
    (> (* 1 var235  )  0 )
)
  (or 
    (> (* 1 var236  )  0 )
)
  (or 
    (> (+ (* 1 var11 var233  ) (* 1 var31 var234  ) (* 1 var51 var235  ) (* (- 0 1) var223 var236  ) (* 1 var224  ) (* (- 0 1) var225  ) (* 1 var226  ) (* (- 0 1) var227  ) (* 1 var228  ) (* (- 0 1) var229  ) (* (- 0 1) var230  ) (* 1 var231  ) (* 1 var232  ) ) 0 )
)
  (or 
    (< (+ (* 1 var223 var236  ) (* (- 0 1) var224  ) (* 1 var225  ) (* (- 0 1) var226  ) (* 1 var227  ) (* (- 0 1) var228  ) (* 1 var229  ) (* 1 var230  ) (* (- 0 1) var231  ) (* (- 0 1) var232  ) ) 0 )
    (> (+ (* 1 var233  ) (* 1 var234  ) (* 1 var235  ) ) 0 )
)
  (or 
    (> (* 1 var237  )  0 )
)
  (or 
    (> (* 1 var238  )  0 )
)
  (or 
    (> (* 1 var61 var238  )  0 )
)
  (or 
    (> (* 1 var238  )  0 )
)
  (or 
    (> (* 1 var239  )  0 )
)
  (or 
    (> (* 1 var240  )  0 )
)
  (or 
    (> (* 1 var241  )  0 )
)
  (or 
    (> (* 1 var242  )  0 )
)
  (or 
    (> (* 1 var243  )  0 )
)
  (or 
    (> (* 1 var244  )  0 )
)
  (or 
    (> (* 1 var245  )  0 )
)
  (or 
    (> (* 1 var246  )  0 )
)
  (or 
    (> (* 1 var247  )  0 )
)
  (or 
    (> (* 1 var248  )  0 )
)
  (or 
    (> (* 1 var249  )  0 )
)
  (or 
    (< (+ (* 1 var61 var248  ) (* (- 0 1) var61 var249  ) (* (- 0 1) var239  ) (* 1 var240  ) (* (- 0 1) var241  ) (* 1 var242  ) (* (- 0 1) var243  ) (* 1 var244  ) (* 1 var245  ) (* (- 0 1) var246  ) (* (- 0 1) var247  ) ) 0 )
)
  (or 
    (< (+ (* 1 var61 var248  ) (* (- 0 1) var239  ) (* 1 var240  ) (* (- 0 1) var241  ) (* 1 var242  ) (* (- 0 1) var243  ) (* 1 var244  ) (* 1 var245  ) (* (- 0 1) var246  ) (* (- 0 1) var247  ) ) 0 )
    (> (* 1 var249  )  0 )
)
  (or 
    (> (* 1 var250  )  0 )
)
  (or 
    (> (* 1 var251  )  0 )
)
  (or 
    (> (* 1 var75 var251  )  0 )
)
  (or 
    (> (* 1 var251  )  0 )
)
  (or 
    (> (* 1 var252  )  0 )
)
  (or 
    (> (* 1 var253  )  0 )
)
  (or 
    (> (* 1 var254  )  0 )
)
  (or 
    (> (* 1 var255  )  0 )
)
  (or 
    (> (* 1 var256  )  0 )
)
  (or 
    (> (* 1 var257  )  0 )
)
  (or 
    (> (* 1 var258  )  0 )
)
  (or 
    (> (* 1 var259  )  0 )
)
  (or 
    (> (* 1 var260  )  0 )
)
  (or 
    (> (* 1 var261  )  0 )
)
  (or 
    (> (* 1 var262  )  0 )
)
  (or 
    (< (+ (* 1 var75 var261  ) (* (- 0 1) var75 var262  ) (* (- 0 1) var252  ) (* 1 var253  ) (* (- 0 1) var254  ) (* 1 var255  ) (* (- 0 1) var256  ) (* 1 var257  ) (* 1 var258  ) (* (- 0 1) var259  ) (* (- 0 1) var260  ) ) 0 )
)
  (or 
    (< (+ (* 1 var75 var261  ) (* (- 0 1) var252  ) (* 1 var253  ) (* (- 0 1) var254  ) (* 1 var255  ) (* (- 0 1) var256  ) (* 1 var257  ) (* 1 var258  ) (* (- 0 1) var259  ) (* (- 0 1) var260  ) ) 0 )
    (> (* 1 var262  )  0 )
)
  (or 
    (> (* 1 var263  )  0 )
)
  (or 
    (> (* 1 var264  )  0 )
)
  (or 
    (> (* 1 var89 var264  )  0 )
)
  (or 
    (> (* 1 var264  )  0 )
)
  (or 
    (> (* 1 var265  )  0 )
)
  (or 
    (> (* 1 var266  )  0 )
)
  (or 
    (> (* 1 var267  )  0 )
)
  (or 
    (> (* 1 var268  )  0 )
)
  (or 
    (> (* 1 var269  )  0 )
)
  (or 
    (> (* 1 var270  )  0 )
)
  (or 
    (> (* 1 var271  )  0 )
)
  (or 
    (> (* 1 var272  )  0 )
)
  (or 
    (> (* 1 var273  )  0 )
)
  (or 
    (> (* 1 var274  )  0 )
)
  (or 
    (> (* 1 var275  )  0 )
)
  (or 
    (< (+ (* 1 var89 var274  ) (* (- 0 1) var89 var275  ) (* (- 0 1) var265  ) (* 1 var266  ) (* (- 0 1) var267  ) (* 1 var268  ) (* (- 0 1) var269  ) (* 1 var270  ) (* 1 var271  ) (* (- 0 1) var272  ) (* (- 0 1) var273  ) ) 0 )
)
  (or 
    (< (+ (* 1 var89 var274  ) (* (- 0 1) var265  ) (* 1 var266  ) (* (- 0 1) var267  ) (* 1 var268  ) (* (- 0 1) var269  ) (* 1 var270  ) (* 1 var271  ) (* (- 0 1) var272  ) (* (- 0 1) var273  ) ) 0 )
    (> (* 1 var275  )  0 )
)
  (or 
    (> (* 1 var276  )  0 )
)
  (or 
    (> (* 1 var277  )  0 )
)
  (or 
    (> (* 1 var103 var277  )  0 )
)
  (or 
    (> (* 1 var277  )  0 )
)
  (or 
    (> (* 1 var278  )  0 )
)
  (or 
    (> (* 1 var279  )  0 )
)
  (or 
    (> (* 1 var280  )  0 )
)
  (or 
    (> (* 1 var281  )  0 )
)
  (or 
    (> (* 1 var282  )  0 )
)
  (or 
    (> (* 1 var283  )  0 )
)
  (or 
    (> (* 1 var284  )  0 )
)
  (or 
    (> (* 1 var285  )  0 )
)
  (or 
    (> (* 1 var286  )  0 )
)
  (or 
    (> (* 1 var287  )  0 )
)
  (or 
    (> (* 1 var288  )  0 )
)
  (or 
    (< (+ (* 1 var103 var287  ) (* (- 0 1) var103 var288  ) (* (- 0 1) var278  ) (* 1 var279  ) (* (- 0 1) var280  ) (* 1 var281  ) (* (- 0 1) var282  ) (* 1 var283  ) (* 1 var284  ) (* (- 0 1) var285  ) (* (- 0 1) var286  ) ) 0 )
)
  (or 
    (< (+ (* 1 var103 var287  ) (* (- 0 1) var278  ) (* 1 var279  ) (* (- 0 1) var280  ) (* 1 var281  ) (* (- 0 1) var282  ) (* 1 var283  ) (* 1 var284  ) (* (- 0 1) var285  ) (* (- 0 1) var286  ) ) 0 )
    (> (* 1 var288  )  0 )
)
  (or 
    (> (* 1 var289  )  0 )
)
  (or 
    (> (* 1 var290  )  0 )
)
  (or 
    (> (* 1 var117 var290  )  0 )
)
  (or 
    (> (* 1 var290  )  0 )
)
  (or 
    (> (* 1 var291  )  0 )
)
  (or 
    (> (* 1 var292  )  0 )
)
  (or 
    (> (* 1 var293  )  0 )
)
  (or 
    (> (* 1 var294  )  0 )
)
  (or 
    (> (* 1 var295  )  0 )
)
  (or 
    (> (* 1 var296  )  0 )
)
  (or 
    (> (* 1 var297  )  0 )
)
  (or 
    (> (* 1 var298  )  0 )
)
  (or 
    (> (* 1 var299  )  0 )
)
  (or 
    (> (* 1 var300  )  0 )
)
  (or 
    (> (* 1 var301  )  0 )
)
  (or 
    (< (+ (* 1 var117 var300  ) (* (- 0 1) var117 var301  ) (* (- 0 1) var291  ) (* 1 var292  ) (* (- 0 1) var293  ) (* 1 var294  ) (* (- 0 1) var295  ) (* 1 var296  ) (* 1 var297  ) (* (- 0 1) var298  ) (* (- 0 1) var299  ) ) 0 )
)
  (or 
    (< (+ (* 1 var117 var300  ) (* (- 0 1) var291  ) (* 1 var292  ) (* (- 0 1) var293  ) (* 1 var294  ) (* (- 0 1) var295  ) (* 1 var296  ) (* 1 var297  ) (* (- 0 1) var298  ) (* (- 0 1) var299  ) ) 0 )
    (> (* 1 var301  )  0 )
)
  (or 
    (> (* 1 var302  )  0 )
)
  (or 
    (> (* 1 var303  )  0 )
)
  (or 
    (> (* 1 var131 var303  )  0 )
)
  (or 
    (> (* 1 var303  )  0 )
)
  (or 
    (> (* 1 var304  )  0 )
)
  (or 
    (> (* 1 var305  )  0 )
)
  (or 
    (> (* 1 var306  )  0 )
)
  (or 
    (> (* 1 var307  )  0 )
)
  (or 
    (> (* 1 var308  )  0 )
)
  (or 
    (> (* 1 var309  )  0 )
)
  (or 
    (> (* 1 var310  )  0 )
)
  (or 
    (> (* 1 var311  )  0 )
)
  (or 
    (> (* 1 var312  )  0 )
)
  (or 
    (> (* 1 var313  )  0 )
)
  (or 
    (> (* 1 var314  )  0 )
)
  (or 
    (< (+ (* 1 var131 var313  ) (* (- 0 1) var131 var314  ) (* (- 0 1) var304  ) (* 1 var305  ) (* (- 0 1) var306  ) (* 1 var307  ) (* (- 0 1) var308  ) (* 1 var309  ) (* 1 var310  ) (* (- 0 1) var311  ) (* (- 0 1) var312  ) ) 0 )
)
  (or 
    (< (+ (* 1 var131 var313  ) (* (- 0 1) var304  ) (* 1 var305  ) (* (- 0 1) var306  ) (* 1 var307  ) (* (- 0 1) var308  ) (* 1 var309  ) (* 1 var310  ) (* (- 0 1) var311  ) (* (- 0 1) var312  ) ) 0 )
    (> (* 1 var314  )  0 )
)
  (or 
    (> (* 1 var315  )  0 )
)
  (or 
    (> (* 1 var316  )  0 )
)
  (or 
    (> (* 1 var145 var316  )  0 )
)
  (or 
    (> (* 1 var316  )  0 )
)
  (or 
    (> (* 1 var317  )  0 )
)
  (or 
    (> (* 1 var318  )  0 )
)
  (or 
    (> (* 1 var319  )  0 )
)
  (or 
    (> (* 1 var320  )  0 )
)
  (or 
    (> (* 1 var321  )  0 )
)
  (or 
    (> (* 1 var322  )  0 )
)
  (or 
    (> (* 1 var323  )  0 )
)
  (or 
    (> (* 1 var324  )  0 )
)
  (or 
    (> (* 1 var325  )  0 )
)
  (or 
    (> (* 1 var326  )  0 )
)
  (or 
    (> (* 1 var327  )  0 )
)
  (or 
    (< (+ (* 1 var145 var326  ) (* (- 0 1) var145 var327  ) (* (- 0 1) var317  ) (* 1 var318  ) (* (- 0 1) var319  ) (* 1 var320  ) (* (- 0 1) var321  ) (* 1 var322  ) (* 1 var323  ) (* (- 0 1) var324  ) (* (- 0 1) var325  ) ) 0 )
)
  (or 
    (< (+ (* 1 var145 var326  ) (* (- 0 1) var317  ) (* 1 var318  ) (* (- 0 1) var319  ) (* 1 var320  ) (* (- 0 1) var321  ) (* 1 var322  ) (* 1 var323  ) (* (- 0 1) var324  ) (* (- 0 1) var325  ) ) 0 )
    (> (* 1 var327  )  0 )
)
  (or 
    (> (* 1 var328  )  0 )
)
  (or 
    (> (* 1 var329  )  0 )
)
  (or 
    (> (* 1 var159 var329  )  0 )
)
  (or 
    (> (* 1 var329  )  0 )
)
  (or 
    (> (* 1 var330  )  0 )
)
  (or 
    (> (* 1 var331  )  0 )
)
  (or 
    (> (* 1 var332  )  0 )
)
  (or 
    (> (* 1 var333  )  0 )
)
  (or 
    (> (* 1 var334  )  0 )
)
  (or 
    (> (* 1 var335  )  0 )
)
  (or 
    (> (* 1 var336  )  0 )
)
  (or 
    (> (* 1 var337  )  0 )
)
  (or 
    (> (* 1 var338  )  0 )
)
  (or 
    (> (* 1 var339  )  0 )
)
  (or 
    (> (* 1 var340  )  0 )
)
  (or 
    (< (+ (* 1 var159 var339  ) (* (- 0 1) var159 var340  ) (* (- 0 1) var330  ) (* 1 var331  ) (* (- 0 1) var332  ) (* 1 var333  ) (* (- 0 1) var334  ) (* 1 var335  ) (* 1 var336  ) (* (- 0 1) var337  ) (* (- 0 1) var338  ) ) 0 )
)
  (or 
    (< (+ (* 1 var159 var339  ) (* (- 0 1) var330  ) (* 1 var331  ) (* (- 0 1) var332  ) (* 1 var333  ) (* (- 0 1) var334  ) (* 1 var335  ) (* 1 var336  ) (* (- 0 1) var337  ) (* (- 0 1) var338  ) ) 0 )
    (> (* 1 var340  )  0 )
)
  (or 
    (> (* 1 var341  )  0 )
)
  (or 
    (> (* 1 var342  )  0 )
)
  (or 
    (> (* 1 var173 var342  )  0 )
)
  (or 
    (> (* 1 var342  )  0 )
)
  (or 
    (> (* 1 var343  )  0 )
)
  (or 
    (> (* 1 var344  )  0 )
)
  (or 
    (> (* 1 var345  )  0 )
)
  (or 
    (> (* 1 var346  )  0 )
)
  (or 
    (> (* 1 var347  )  0 )
)
  (or 
    (> (* 1 var348  )  0 )
)
  (or 
    (> (* 1 var349  )  0 )
)
  (or 
    (> (* 1 var350  )  0 )
)
  (or 
    (> (* 1 var351  )  0 )
)
  (or 
    (> (* 1 var352  )  0 )
)
  (or 
    (> (* 1 var353  )  0 )
)
  (or 
    (< (+ (* 1 var173 var352  ) (* (- 0 1) var173 var353  ) (* (- 0 1) var343  ) (* 1 var344  ) (* (- 0 1) var345  ) (* 1 var346  ) (* (- 0 1) var347  ) (* 1 var348  ) (* 1 var349  ) (* (- 0 1) var350  ) (* (- 0 1) var351  ) ) 0 )
)
  (or 
    (< (+ (* 1 var173 var352  ) (* (- 0 1) var343  ) (* 1 var344  ) (* (- 0 1) var345  ) (* 1 var346  ) (* (- 0 1) var347  ) (* 1 var348  ) (* 1 var349  ) (* (- 0 1) var350  ) (* (- 0 1) var351  ) ) 0 )
    (> (* 1 var353  )  0 )
)
  (or 
    (> (* 1 var354  )  0 )
)
  (or 
    (> (* 1 var355  )  0 )
)
  (or 
    (> (* 1 var187 var355  )  0 )
)
  (or 
    (> (* 1 var355  )  0 )
)
  (or 
    (> (* 1 var356  )  0 )
)
  (or 
    (> (* 1 var357  )  0 )
)
  (or 
    (> (* 1 var358  )  0 )
)
  (or 
    (> (* 1 var359  )  0 )
)
  (or 
    (> (* 1 var360  )  0 )
)
  (or 
    (> (* 1 var361  )  0 )
)
  (or 
    (> (* 1 var362  )  0 )
)
  (or 
    (> (* 1 var363  )  0 )
)
  (or 
    (> (* 1 var364  )  0 )
)
  (or 
    (> (* 1 var365  )  0 )
)
  (or 
    (> (* 1 var366  )  0 )
)
  (or 
    (< (+ (* 1 var187 var365  ) (* (- 0 1) var187 var366  ) (* (- 0 1) var356  ) (* 1 var357  ) (* (- 0 1) var358  ) (* 1 var359  ) (* (- 0 1) var360  ) (* 1 var361  ) (* 1 var362  ) (* (- 0 1) var363  ) (* (- 0 1) var364  ) ) 0 )
)
  (or 
    (< (+ (* 1 var187 var365  ) (* (- 0 1) var356  ) (* 1 var357  ) (* (- 0 1) var358  ) (* 1 var359  ) (* (- 0 1) var360  ) (* 1 var361  ) (* 1 var362  ) (* (- 0 1) var363  ) (* (- 0 1) var364  ) ) 0 )
    (> (* 1 var366  )  0 )
)
  (or 
    (> (* 1 var367  )  0 )
)
  (or 
    (> (* 1 var368  )  0 )
)
  (or 
    (> (* 1 var199 var368  )  0 )
)
  (or 
    (> (* 1 var368  )  0 )
)
  (or 
    (> (* 1 var369  )  0 )
)
  (or 
    (> (* 1 var370  )  0 )
)
  (or 
    (> (* 1 var371  )  0 )
)
  (or 
    (> (* 1 var372  )  0 )
)
  (or 
    (> (* 1 var373  )  0 )
)
  (or 
    (> (* 1 var374  )  0 )
)
  (or 
    (> (* 1 var375  )  0 )
)
  (or 
    (> (* 1 var376  )  0 )
)
  (or 
    (> (* 1 var377  )  0 )
)
  (or 
    (> (* 1 var378  )  0 )
)
  (or 
    (> (* 1 var379  )  0 )
)
  (or 
    (< (+ (* 1 var199 var378  ) (* (- 0 1) var199 var379  ) (* (- 0 1) var369  ) (* 1 var370  ) (* (- 0 1) var371  ) (* 1 var372  ) (* (- 0 1) var373  ) (* 1 var374  ) (* 1 var375  ) (* (- 0 1) var376  ) (* (- 0 1) var377  ) ) 0 )
)
  (or 
    (< (+ (* 1 var199 var378  ) (* (- 0 1) var369  ) (* 1 var370  ) (* (- 0 1) var371  ) (* 1 var372  ) (* (- 0 1) var373  ) (* 1 var374  ) (* 1 var375  ) (* (- 0 1) var376  ) (* (- 0 1) var377  ) ) 0 )
    (> (* 1 var379  )  0 )
)
  (or 
    (> (* 1 var380  )  0 )
)
  (or 
    (> (* 1 var381  )  0 )
)
  (or 
    (> (* 1 var211 var381  )  0 )
)
  (or 
    (> (* 1 var381  )  0 )
)
  (or 
    (> (* 1 var382  )  0 )
)
  (or 
    (> (* 1 var383  )  0 )
)
  (or 
    (> (* 1 var384  )  0 )
)
  (or 
    (> (* 1 var385  )  0 )
)
  (or 
    (> (* 1 var386  )  0 )
)
  (or 
    (> (* 1 var387  )  0 )
)
  (or 
    (> (* 1 var388  )  0 )
)
  (or 
    (> (* 1 var389  )  0 )
)
  (or 
    (> (* 1 var390  )  0 )
)
  (or 
    (> (* 1 var391  )  0 )
)
  (or 
    (> (* 1 var392  )  0 )
)
  (or 
    (< (+ (* 1 var211 var391  ) (* (- 0 1) var211 var392  ) (* (- 0 1) var382  ) (* 1 var383  ) (* (- 0 1) var384  ) (* 1 var385  ) (* (- 0 1) var386  ) (* 1 var387  ) (* 1 var388  ) (* (- 0 1) var389  ) (* (- 0 1) var390  ) ) 0 )
)
  (or 
    (< (+ (* 1 var211 var391  ) (* (- 0 1) var382  ) (* 1 var383  ) (* (- 0 1) var384  ) (* 1 var385  ) (* (- 0 1) var386  ) (* 1 var387  ) (* 1 var388  ) (* (- 0 1) var389  ) (* (- 0 1) var390  ) ) 0 )
    (> (* 1 var392  )  0 )
)
  (or 
    (> (* 1 var393  )  0 )
)
  (or 
    (> (* 1 var394  )  0 )
)
  (or 
    (> (* 1 var223 var394  )  0 )
)
  (or 
    (> (* 1 var394  )  0 )
)
  (or 
    (> (* 1 var395  )  0 )
)
  (or 
    (> (* 1 var396  )  0 )
)
  (or 
    (> (* 1 var397  )  0 )
)
  (or 
    (> (* 1 var398  )  0 )
)
  (or 
    (> (* 1 var399  )  0 )
)
  (or 
    (> (* 1 var400  )  0 )
)
  (or 
    (> (* 1 var401  )  0 )
)
  (or 
    (> (* 1 var402  )  0 )
)
  (or 
    (> (* 1 var403  )  0 )
)
  (or 
    (> (* 1 var404  )  0 )
)
  (or 
    (> (* 1 var405  )  0 )
)
  (or 
    (< (+ (* 1 var223 var404  ) (* (- 0 1) var223 var405  ) (* (- 0 1) var395  ) (* 1 var396  ) (* (- 0 1) var397  ) (* 1 var398  ) (* (- 0 1) var399  ) (* 1 var400  ) (* 1 var401  ) (* (- 0 1) var402  ) (* (- 0 1) var403  ) ) 0 )
)
  (or 
    (< (+ (* 1 var223 var404  ) (* (- 0 1) var395  ) (* 1 var396  ) (* (- 0 1) var397  ) (* 1 var398  ) (* (- 0 1) var399  ) (* 1 var400  ) (* 1 var401  ) (* (- 0 1) var402  ) (* (- 0 1) var403  ) ) 0 )
    (> (* 1 var405  )  0 )
)
))
(check-sat)
(exit)
