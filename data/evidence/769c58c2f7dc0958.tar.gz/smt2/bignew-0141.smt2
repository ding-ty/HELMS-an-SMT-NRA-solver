(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sin/344/3/sin-344-3-chunk-0020.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0 var0 var0  ) (* 3 var0 var0 var1  ) (* 3 var0 var0 var2  ) (* 3 var0 var1 var1  ) (* 6 var0 var1 var2  ) (* 3 var0 var2 var2  ) (* 1 var1 var1 var1  ) (* 3 var1 var1 var2  ) (* 3 var1 var2 var2  ) (* 1 var2 var2 var2  ) (* (- 0 6) var0  ) (* (- 0 6) var1  ) (* (- 0 6) var2  ) ) 0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 3) ) 0 )
)
  (or 
    (> (+ (* 10 var1  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 10 var0  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 10 var2  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
