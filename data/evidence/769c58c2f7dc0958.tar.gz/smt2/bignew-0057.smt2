(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Chua/1/VC2/L/Chua-1-VC2-L-chunk-0067.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 3 var0  ) (* (- 0 13) var1  ) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (+ (* 3 var0  ) (* (- 0 13) var1  ) ) 0 )
)
  (or 
    (> (+ (* 3 var0  ) (* (- 0 13) var1  ) ) 0 )
    (< (+ (* 3 var0  ) (* (- 0 13) var1  ) ) 0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 289) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
))
(check-sat)
(exit)
