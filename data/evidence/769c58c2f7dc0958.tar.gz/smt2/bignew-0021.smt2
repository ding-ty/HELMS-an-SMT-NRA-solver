(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20240407-pPDA-Chiari-Pontiggia-Winkler/certificate_no_hints/schelling_POMC_no_hints.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(declare-fun var8 () Real)
(declare-fun var9 () Real)
(declare-fun var10 () Real)
(declare-fun var11 () Real)
(declare-fun var12 () Real)
(declare-fun var13 () Real)
(declare-fun var14 () Real)
(declare-fun var15 () Real)
(declare-fun var16 () Real)
(declare-fun var17 () Real)
(declare-fun var18 () Real)
(declare-fun var19 () Real)
(declare-fun var20 () Real)
(declare-fun var21 () Real)
(declare-fun var22 () Real)
(declare-fun var23 () Real)
(declare-fun var24 () Real)
(declare-fun var25 () Real)
(declare-fun var26 () Real)
(declare-fun var27 () Real)
(declare-fun var28 () Real)
(declare-fun var29 () Real)
(declare-fun var30 () Real)
(declare-fun var31 () Real)
(declare-fun var32 () Real)
(declare-fun var33 () Real)
(declare-fun var34 () Real)
(declare-fun var35 () Real)
(declare-fun var36 () Real)
(declare-fun var37 () Real)
(declare-fun var38 () Real)
(declare-fun var39 () Real)
(declare-fun var40 () Real)
(declare-fun var41 () Real)
(declare-fun var42 () Real)
(declare-fun var43 () Real)
(declare-fun var44 () Real)
(declare-fun var45 () Real)
(declare-fun var46 () Real)
(declare-fun var47 () Real)
(declare-fun var48 () Real)
(declare-fun var49 () Real)
(declare-fun var50 () Real)
(declare-fun var51 () Real)
(declare-fun var52 () Real)
(declare-fun var53 () Real)
(declare-fun var54 () Real)
(declare-fun var55 () Real)
(declare-fun var56 () Real)
(declare-fun var57 () Real)
(declare-fun var58 () Real)
(declare-fun var59 () Real)
(declare-fun var60 () Real)
(declare-fun var61 () Real)
(declare-fun var62 () Real)
(declare-fun var63 () Real)
(declare-fun var64 () Real)
(declare-fun var65 () Real)
(declare-fun var66 () Real)
(declare-fun var67 () Real)
(declare-fun var68 () Real)
(declare-fun var69 () Real)
(declare-fun var70 () Real)
(declare-fun var71 () Real)
(declare-fun var72 () Real)
(declare-fun var73 () Real)
(declare-fun var74 () Real)
(declare-fun var75 () Real)
(declare-fun var76 () Real)
(declare-fun var77 () Real)
(declare-fun var78 () Real)
(declare-fun var79 () Real)
(declare-fun var80 () Real)
(declare-fun var81 () Real)
(declare-fun var82 () Real)
(declare-fun var83 () Real)
(declare-fun var84 () Real)
(declare-fun var85 () Real)
(declare-fun var86 () Real)
(declare-fun var87 () Real)
(declare-fun var88 () Real)
(declare-fun var89 () Real)
(declare-fun var90 () Real)
(declare-fun var91 () Real)
(declare-fun var92 () Real)
(declare-fun var93 () Real)
(declare-fun var94 () Real)
(declare-fun var95 () Real)
(declare-fun var96 () Real)
(declare-fun var97 () Real)
(declare-fun var98 () Real)
(declare-fun var99 () Real)
(declare-fun var100 () Real)
(declare-fun var101 () Real)
(declare-fun var102 () Real)
(declare-fun var103 () Real)
(declare-fun var104 () Real)
(declare-fun var105 () Real)
(declare-fun var106 () Real)
(declare-fun var107 () Real)
(declare-fun var108 () Real)
(declare-fun var109 () Real)
(declare-fun var110 () Real)
(declare-fun var111 () Real)
(declare-fun var112 () Real)
(declare-fun var113 () Real)
(declare-fun var114 () Real)
(declare-fun var115 () Real)
(declare-fun var116 () Real)
(declare-fun var117 () Real)
(declare-fun var118 () Real)
(declare-fun var119 () Real)
(declare-fun var120 () Real)
(declare-fun var121 () Real)
(declare-fun var122 () Real)
(declare-fun var123 () Real)
(declare-fun var124 () Real)
(declare-fun var125 () Real)
(declare-fun var126 () Real)
(declare-fun var127 () Real)
(declare-fun var128 () Real)
(declare-fun var129 () Real)
(declare-fun var130 () Real)
(declare-fun var131 () Real)
(declare-fun var132 () Real)
(declare-fun var133 () Real)
(declare-fun var134 () Real)
(declare-fun var135 () Real)
(declare-fun var136 () Real)
(declare-fun var137 () Real)
(declare-fun var138 () Real)
(declare-fun var139 () Real)
(declare-fun var140 () Real)
(declare-fun var141 () Real)
(declare-fun var142 () Real)
(declare-fun var143 () Real)
(declare-fun var144 () Real)
(declare-fun var145 () Real)
(declare-fun var146 () Real)
(declare-fun var147 () Real)
(declare-fun var148 () Real)
(declare-fun var149 () Real)
(declare-fun var150 () Real)
(declare-fun var151 () Real)
(declare-fun var152 () Real)
(declare-fun var153 () Real)
(declare-fun var154 () Real)
(declare-fun var155 () Real)
(declare-fun var156 () Real)
(declare-fun var157 () Real)
(declare-fun var158 () Real)
(declare-fun var159 () Real)
(declare-fun var160 () Real)
(declare-fun var161 () Real)
(declare-fun var162 () Real)
(declare-fun var163 () Real)
(declare-fun var164 () Real)
(declare-fun var165 () Real)
(declare-fun var166 () Real)
(declare-fun var167 () Real)
(declare-fun var168 () Real)
(declare-fun var169 () Real)
(declare-fun var170 () Real)
(declare-fun var171 () Real)
(declare-fun var172 () Real)
(declare-fun var173 () Real)
(declare-fun var174 () Real)
(declare-fun var175 () Real)
(declare-fun var176 () Real)
(declare-fun var177 () Real)
(declare-fun var178 () Real)
(declare-fun var179 () Real)
(declare-fun var180 () Real)
(declare-fun var181 () Real)
(declare-fun var182 () Real)
(declare-fun var183 () Real)
(declare-fun var184 () Real)
(declare-fun var185 () Real)
(declare-fun var186 () Real)
(declare-fun var187 () Real)
(declare-fun var188 () Real)
(declare-fun var189 () Real)
(declare-fun var190 () Real)
(declare-fun var191 () Real)
(declare-fun var192 () Real)
(declare-fun var193 () Real)
(declare-fun var194 () Real)
(declare-fun var195 () Real)
(declare-fun var196 () Real)
(declare-fun var197 () Real)
(declare-fun var198 () Real)
(declare-fun var199 () Real)
(declare-fun var200 () Real)
(declare-fun var201 () Real)
(declare-fun var202 () Real)
(declare-fun var203 () Real)
(declare-fun var204 () Real)
(declare-fun var205 () Real)
(declare-fun var206 () Real)
(declare-fun var207 () Real)
(declare-fun var208 () Real)
(declare-fun var209 () Real)
(declare-fun var210 () Real)
(declare-fun var211 () Real)
(declare-fun var212 () Real)
(declare-fun var213 () Real)
(declare-fun var214 () Real)
(declare-fun var215 () Real)
(declare-fun var216 () Real)
(declare-fun var217 () Real)
(declare-fun var218 () Real)
(declare-fun var219 () Real)
(declare-fun var220 () Real)
(declare-fun var221 () Real)
(declare-fun var222 () Real)
(declare-fun var223 () Real)
(declare-fun var224 () Real)
(declare-fun var225 () Real)
(declare-fun var226 () Real)
(declare-fun var227 () Real)
(declare-fun var228 () Real)
(declare-fun var229 () Real)
(declare-fun var230 () Real)
(declare-fun var231 () Real)
(declare-fun var232 () Real)
(declare-fun var233 () Real)
(declare-fun var234 () Real)
(declare-fun var235 () Real)
(declare-fun var236 () Real)
(declare-fun var237 () Real)
(declare-fun var238 () Real)
(declare-fun var239 () Real)
(declare-fun var240 () Real)
(declare-fun var241 () Real)
(declare-fun var242 () Real)
(declare-fun var243 () Real)
(declare-fun var244 () Real)
(declare-fun var245 () Real)
(declare-fun var246 () Real)
(declare-fun var247 () Real)
(declare-fun var248 () Real)
(declare-fun var249 () Real)
(declare-fun var250 () Real)
(declare-fun var251 () Real)
(declare-fun var252 () Real)
(declare-fun var253 () Real)
(declare-fun var254 () Real)
(declare-fun var255 () Real)
(declare-fun var256 () Real)
(declare-fun var257 () Real)
(declare-fun var258 () Real)
(declare-fun var259 () Real)
(declare-fun var260 () Real)
(declare-fun var261 () Real)
(declare-fun var262 () Real)
(declare-fun var263 () Real)
(declare-fun var264 () Real)
(declare-fun var265 () Real)
(declare-fun var266 () Real)
(declare-fun var267 () Real)
(declare-fun var268 () Real)
(declare-fun var269 () Real)
(declare-fun var270 () Real)
(declare-fun var271 () Real)
(declare-fun var272 () Real)
(declare-fun var273 () Real)
(declare-fun var274 () Real)
(declare-fun var275 () Real)
(declare-fun var276 () Real)
(declare-fun var277 () Real)
(declare-fun var278 () Real)
(declare-fun var279 () Real)
(declare-fun var280 () Real)
(declare-fun var281 () Real)
(declare-fun var282 () Real)
(declare-fun var283 () Real)
(declare-fun var284 () Real)
(declare-fun var285 () Real)
(declare-fun var286 () Real)
(declare-fun var287 () Real)
(declare-fun var288 () Real)
(declare-fun var289 () Real)
(declare-fun var290 () Real)
(declare-fun var291 () Real)
(declare-fun var292 () Real)
(declare-fun var293 () Real)
(declare-fun var294 () Real)
(declare-fun var295 () Real)
(declare-fun var296 () Real)
(declare-fun var297 () Real)
(declare-fun var298 () Real)
(declare-fun var299 () Real)
(declare-fun var300 () Real)
(declare-fun var301 () Real)
(declare-fun var302 () Real)
(declare-fun var303 () Real)
(declare-fun var304 () Real)
(declare-fun var305 () Real)
(declare-fun var306 () Real)
(declare-fun var307 () Real)
(declare-fun var308 () Real)
(declare-fun var309 () Real)
(declare-fun var310 () Real)
(declare-fun var311 () Real)
(declare-fun var312 () Real)
(declare-fun var313 () Real)
(declare-fun var314 () Real)
(declare-fun var315 () Real)
(declare-fun var316 () Real)
(declare-fun var317 () Real)
(declare-fun var318 () Real)
(declare-fun var319 () Real)
(declare-fun var320 () Real)
(declare-fun var321 () Real)
(declare-fun var322 () Real)
(declare-fun var323 () Real)
(declare-fun var324 () Real)
(declare-fun var325 () Real)
(declare-fun var326 () Real)
(declare-fun var327 () Real)
(declare-fun var328 () Real)
(declare-fun var329 () Real)
(declare-fun var330 () Real)
(declare-fun var331 () Real)
(declare-fun var332 () Real)
(declare-fun var333 () Real)
(declare-fun var334 () Real)
(declare-fun var335 () Real)
(declare-fun var336 () Real)
(declare-fun var337 () Real)
(declare-fun var338 () Real)
(declare-fun var339 () Real)
(declare-fun var340 () Real)
(declare-fun var341 () Real)
(declare-fun var342 () Real)
(declare-fun var343 () Real)
(declare-fun var344 () Real)
(declare-fun var345 () Real)
(declare-fun var346 () Real)
(declare-fun var347 () Real)
(declare-fun var348 () Real)
(declare-fun var349 () Real)
(declare-fun var350 () Real)
(declare-fun var351 () Real)
(declare-fun var352 () Real)
(declare-fun var353 () Real)
(declare-fun var354 () Real)
(declare-fun var355 () Real)
(declare-fun var356 () Real)
(declare-fun var357 () Real)
(declare-fun var358 () Real)
(declare-fun var359 () Real)
(declare-fun var360 () Real)
(declare-fun var361 () Real)
(declare-fun var362 () Real)
(declare-fun var363 () Real)
(declare-fun var364 () Real)
(declare-fun var365 () Real)
(declare-fun var366 () Real)
(declare-fun var367 () Real)
(declare-fun var368 () Real)
(declare-fun var369 () Real)
(declare-fun var370 () Real)
(declare-fun var371 () Real)
(declare-fun var372 () Real)
(declare-fun var373 () Real)
(declare-fun var374 () Real)
(declare-fun var375 () Real)
(declare-fun var376 () Real)
(declare-fun var377 () Real)
(declare-fun var378 () Real)
(declare-fun var379 () Real)
(declare-fun var380 () Real)
(declare-fun var381 () Real)
(declare-fun var382 () Real)
(declare-fun var383 () Real)
(declare-fun var384 () Real)
(declare-fun var385 () Real)
(declare-fun var386 () Real)
(declare-fun var387 () Real)
(declare-fun var388 () Real)
(declare-fun var389 () Real)
(declare-fun var390 () Real)
(declare-fun var391 () Real)
(declare-fun var392 () Real)
(declare-fun var393 () Real)
(declare-fun var394 () Real)
(declare-fun var395 () Real)
(declare-fun var396 () Real)
(declare-fun var397 () Real)
(declare-fun var398 () Real)
(declare-fun var399 () Real)
(declare-fun var400 () Real)
(declare-fun var401 () Real)
(declare-fun var402 () Real)
(declare-fun var403 () Real)
(declare-fun var404 () Real)
(declare-fun var405 () Real)
(declare-fun var406 () Real)
(declare-fun var407 () Real)
(declare-fun var408 () Real)
(declare-fun var409 () Real)
(declare-fun var410 () Real)
(declare-fun var411 () Real)
(declare-fun var412 () Real)
(declare-fun var413 () Real)
(declare-fun var414 () Real)
(declare-fun var415 () Real)
(declare-fun var416 () Real)
(declare-fun var417 () Real)
(declare-fun var418 () Real)
(declare-fun var419 () Real)
(declare-fun var420 () Real)
(declare-fun var421 () Real)
(declare-fun var422 () Real)
(declare-fun var423 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0  ) (* (- 0 1) var1  ) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (< (+ (* 1 var2  ) (* (- 0 1) var3  ) ) 0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (< (+ (* 1 var4 var5  ) (* 1 var6 var7  ) (* (- 0 1) var8  ) ) 0 )
)
  (or 
    (> (* 1 var8  )  0 )
)
  (or 
    (< (+ (* 1 var9 var10  ) (* 1 var11 var12  ) (* (- 0 1) var7  ) (* 1 var13  ) ) 0 )
)
  (or 
    (> (* 1 var7  )  0 )
)
  (or 
    (< (+ (* 9 var14 var17  ) (* 11 var15 var16  ) (* (- 0 20) var13  ) (* 11 var14  ) (* 9 var15  ) ) 0 )
)
  (or 
    (> (* 1 var13  )  0 )
)
  (or 
    (< (+ (* 1 var18 var19  ) (* 1 var20 var21  ) (* (- 0 1) var15  ) ) 0 )
)
  (or 
    (> (* 1 var15  )  0 )
)
  (or 
    (< (+ (* 1 var22 var23  ) (* 1 var24 var25  ) (* 1 var26 var27  ) (* (- 0 1) var21  ) (* 1 var28  ) (* 1 var29  ) ) 0 )
)
  (or 
    (> (* 1 var21  )  0 )
)
  (or 
    (< (+ (* 11 var30 var31  ) (* 9 var32 var33  ) (* (- 0 20) var29  ) (* 9 var30  ) (* 11 var32  ) ) 0 )
)
  (or 
    (> (* 1 var29  )  0 )
)
  (or 
    (< (+ (* 1 var34 var35  ) (* 9 var36 var37  ) (* (- 0 10) var32  ) (* 9 var34  ) (* 1 var36  ) ) 0 )
)
  (or 
    (> (* 1 var32  )  0 )
)
  (or 
    (< (+ (* 1 var38 var39  ) (* (- 0 1) var36  ) (* 1 var40  ) ) 0 )
)
  (or 
    (> (* 1 var36  )  0 )
)
  (or 
    (< (+ (* 1 var41 var42  ) (* 1 var43 var44  ) (* (- 0 1) var40  ) (* 1 var45  ) ) 0 )
)
  (or 
    (> (* 1 var40  )  0 )
)
  (or 
    (> (+ (* 20 var45  ) (* (- 0 11) var46  ) (* (- 0 9) var47  ) ) 0 )
)
  (or 
    (> (* 1 var45  )  0 )
)
  (or 
    (< (+ (* 1 var0 var48  ) (* 1 var2  ) (* (- 0 1) var46  ) ) 0 )
)
  (or 
    (> (* 1 var46  )  0 )
)
  (or 
    (< (+ (* 1 var19 var49  ) (* 1 var21 var50  ) (* (- 0 1) var47  ) ) 0 )
)
  (or 
    (> (* 1 var47  )  0 )
)
  (or 
    (> (+ (* 1 var49  ) (* (- 0 1) var51  ) ) 0 )
)
  (or 
    (> (* 1 var49  )  0 )
)
  (or 
    (> (+ (* 1 var51  ) (* (- 0 1) var52  ) ) 0 )
)
  (or 
    (> (* 1 var51  )  0 )
)
  (or 
    (> (+ (* 20 var44  ) (* (- 0 11) var53  ) (* (- 0 9) var54  ) ) 0 )
)
  (or 
    (> (* 1 var44  )  0 )
)
  (or 
    (< (+ (* 1 var2 var55  ) (* 1 var0  ) (* (- 0 1) var53  ) ) 0 )
)
  (or 
    (> (* 1 var53  )  0 )
)
  (or 
    (> (+ (* 1 var55  ) (* (- 0 1) var56  ) ) 0 )
)
  (or 
    (> (* 1 var55  )  0 )
)
  (or 
    (> (+ (* 1 var56  ) (* (- 0 1) var57  ) ) 0 )
)
  (or 
    (> (* 1 var56  )  0 )
)
  (or 
    (< (+ (* 1 var19 var58  ) (* 1 var21  ) (* (- 0 1) var54  ) ) 0 )
)
  (or 
    (> (* 1 var54  )  0 )
)
  (or 
    (> (+ (* 1 var58  ) (* (- 0 1) var59  ) ) 0 )
)
  (or 
    (> (* 1 var58  )  0 )
)
  (or 
    (> (+ (* 1 var59  ) (* (- 0 1) var60  ) ) 0 )
)
  (or 
    (> (* 1 var59  )  0 )
)
  (or 
    (< (+ (* 1 var40  ) (* (- 0 1) var43  ) ) 0 )
)
  (or 
    (> (* 1 var43  )  0 )
)
  (or 
    (> (+ (* 20 var42  ) (* (- 0 11) var61  ) (* (- 0 9) var62  ) ) 0 )
)
  (or 
    (> (* 1 var42  )  0 )
)
  (or 
    (< (+ (* 1 var0 var63  ) (* 1 var2 var64  ) (* (- 0 1) var61  ) ) 0 )
)
  (or 
    (> (* 1 var61  )  0 )
)
  (or 
    (> (+ (* 1 var64  ) (* (- 0 1) var65  ) ) 0 )
)
  (or 
    (> (* 1 var64  )  0 )
)
  (or 
    (> (+ (* 1 var65  ) (* (- 0 1) var66  ) ) 0 )
)
  (or 
    (> (* 1 var65  )  0 )
)
  (or 
    (< (+ (* 1 var21 var67  ) (* 1 var19  ) (* (- 0 1) var62  ) ) 0 )
)
  (or 
    (> (* 1 var62  )  0 )
)
  (or 
    (> (+ (* 1 var41  ) (* (- 0 1) var68  ) ) 0 )
)
  (or 
    (> (* 1 var41  )  0 )
)
  (or 
    (< (+ (* 1 var44 var69  ) (* 1 var45 var70  ) (* (- 0 1) var39  ) (* 1 var42  ) ) 0 )
)
  (or 
    (> (* 1 var39  )  0 )
)
  (or 
    (> (+ (* 1 var70  ) (* (- 0 1) var71  ) ) 0 )
)
  (or 
    (> (* 1 var70  )  0 )
)
  (or 
    (< (+ (* 1 var39  ) (* (- 0 1) var69  ) ) 0 )
)
  (or 
    (> (* 1 var69  )  0 )
)
  (or 
    (> (+ (* 1 var34  ) (* (- 0 1) var72  ) ) 0 )
)
  (or 
    (> (* 1 var34  )  0 )
)
  (or 
    (> (+ (* 1 var72  ) (* (- 0 1) var73  ) ) 0 )
)
  (or 
    (> (* 1 var72  )  0 )
)
  (or 
    (< (+ (* 9 var74 var77  ) (* 1 var75 var76  ) (* (- 0 10) var30  ) (* 1 var74  ) (* 9 var75  ) ) 0 )
)
  (or 
    (> (* 1 var30  )  0 )
)
  (or 
    (> (+ (* 1 var75  ) (* (- 0 1) var78  ) ) 0 )
)
  (or 
    (> (* 1 var75  )  0 )
)
  (or 
    (> (+ (* 1 var78  ) (* (- 0 1) var79  ) ) 0 )
)
  (or 
    (> (* 1 var78  )  0 )
)
  (or 
    (< (+ (* 1 var5 var80  ) (* 1 var7 var81  ) (* (- 0 1) var74  ) ) 0 )
)
  (or 
    (> (* 1 var74  )  0 )
)
  (or 
    (> (+ (* 1 var80  ) (* (- 0 1) var82  ) ) 0 )
)
  (or 
    (> (* 1 var80  )  0 )
)
  (or 
    (> (+ (* 1 var82  ) (* (- 0 1) var83  ) ) 0 )
)
  (or 
    (> (* 1 var82  )  0 )
)
  (or 
    (> (+ (* 20 var28  ) (* (- 0 11) var84  ) (* (- 0 9) var85  ) ) 0 )
)
  (or 
    (> (* 1 var28  )  0 )
)
  (or 
    (> (+ (* 10 var84  ) (* (- 0 1) var86  ) (- 0 9) ) 0 )
)
  (or 
    (> (* 1 var84  )  0 )
)
  (or 
    (< (+ (* 1 var39 var87  ) (* 1 var40 var88  ) (* (- 0 1) var86  ) ) 0 )
)
  (or 
    (> (* 1 var86  )  0 )
)
  (or 
    (> (+ (* 1 var88  ) (* (- 0 1) var89  ) ) 0 )
)
  (or 
    (> (* 1 var88  )  0 )
)
  (or 
    (> (+ (* 1 var89  ) (* (- 0 1) var90  ) ) 0 )
)
  (or 
    (> (* 1 var89  )  0 )
)
  (or 
    (> (+ (* 10 var85  ) (* (- 0 1) var91  ) (* (- 0 9) var92  ) ) 0 )
)
  (or 
    (> (* 1 var85  )  0 )
)
  (or 
    (> (+ (* 1 var92  ) (* (- 0 1) var93  ) ) 0 )
)
  (or 
    (> (* 1 var92  )  0 )
)
  (or 
    (> (+ (* 1 var93  ) (* (- 0 1) var94  ) ) 0 )
)
  (or 
    (> (* 1 var93  )  0 )
)
  (or 
    (< (+ (* 1 var5 var95  ) (* 1 var7 var96  ) (* (- 0 1) var91  ) ) 0 )
)
  (or 
    (> (* 1 var91  )  0 )
)
  (or 
    (> (+ (* 1 var95  ) (* (- 0 1) var97  ) ) 0 )
)
  (or 
    (> (* 1 var95  )  0 )
)
  (or 
    (> (+ (* 1 var97  ) (* (- 0 1) var98  ) ) 0 )
)
  (or 
    (> (* 1 var97  )  0 )
)
  (or 
    (> (+ (* 20 var27  ) (* (- 0 11) var99  ) (* (- 0 9) var100  ) ) 0 )
)
  (or 
    (> (* 1 var27  )  0 )
)
  (or 
    (> (+ (* 10 var99  ) (* (- 0 1) var101  ) (* (- 0 9) var102  ) ) 0 )
)
  (or 
    (> (* 1 var99  )  0 )
)
  (or 
    (< (+ (* 1 var40 var103  ) (* 1 var39  ) (* (- 0 1) var101  ) ) 0 )
)
  (or 
    (> (* 1 var101  )  0 )
)
  (or 
    (> (+ (* 1 var103  ) (* (- 0 1) var104  ) ) 0 )
)
  (or 
    (> (* 1 var103  )  0 )
)
  (or 
    (> (+ (* 1 var104  ) (* (- 0 1) var105  ) ) 0 )
)
  (or 
    (> (* 1 var104  )  0 )
)
  (or 
    (> (+ (* 1 var102  ) (* (- 0 1) var106  ) ) 0 )
)
  (or 
    (> (* 1 var102  )  0 )
)
  (or 
    (> (+ (* 1 var106  ) (* (- 0 1) var107  ) ) 0 )
)
  (or 
    (> (* 1 var106  )  0 )
)
  (or 
    (> (+ (* 10 var100  ) (* (- 0 1) var108  ) (* (- 0 9) var109  ) ) 0 )
)
  (or 
    (> (* 1 var100  )  0 )
)
  (or 
    (> (+ (* 1 var109  ) (* (- 0 1) var110  ) ) 0 )
)
  (or 
    (> (* 1 var109  )  0 )
)
  (or 
    (> (+ (* 1 var110  ) (* (- 0 1) var111  ) ) 0 )
)
  (or 
    (> (* 1 var110  )  0 )
)
  (or 
    (< (+ (* 1 var5 var112  ) (* 1 var7  ) (* (- 0 1) var108  ) ) 0 )
)
  (or 
    (> (* 1 var108  )  0 )
)
  (or 
    (> (+ (* 1 var112  ) (* (- 0 1) var113  ) ) 0 )
)
  (or 
    (> (* 1 var112  )  0 )
)
  (or 
    (> (+ (* 1 var113  ) (* (- 0 1) var114  ) ) 0 )
)
  (or 
    (> (* 1 var113  )  0 )
)
  (or 
    (< (+ (* 1 var21  ) (* (- 0 1) var26  ) ) 0 )
)
  (or 
    (> (* 1 var26  )  0 )
)
  (or 
    (> (+ (* 20 var25  ) (* (- 0 11) var115  ) (* (- 0 9) var116  ) ) 0 )
)
  (or 
    (> (* 1 var25  )  0 )
)
  (or 
    (> (+ (* 10 var115  ) (* (- 0 1) var117  ) (* (- 0 9) var118  ) ) 0 )
)
  (or 
    (> (* 1 var115  )  0 )
)
  (or 
    (< (+ (* 1 var39 var119  ) (* 1 var40 var120  ) (* (- 0 1) var117  ) ) 0 )
)
  (or 
    (> (* 1 var117  )  0 )
)
  (or 
    (> (+ (* 1 var120  ) (* (- 0 1) var121  ) ) 0 )
)
  (or 
    (> (* 1 var120  )  0 )
)
  (or 
    (> (+ (* 1 var121  ) (* (- 0 1) var122  ) ) 0 )
)
  (or 
    (> (* 1 var121  )  0 )
)
  (or 
    (> (+ (* 1 var118  ) (* (- 0 1) var123  ) ) 0 )
)
  (or 
    (> (* 1 var118  )  0 )
)
  (or 
    (> (+ (* 1 var123  ) (* (- 0 1) var124  ) ) 0 )
)
  (or 
    (> (* 1 var123  )  0 )
)
  (or 
    (> (+ (* 10 var116  ) (* (- 0 1) var125  ) (* (- 0 9) var126  ) ) 0 )
)
  (or 
    (> (* 1 var116  )  0 )
)
  (or 
    (> (+ (* 1 var126  ) (* (- 0 1) var127  ) ) 0 )
)
  (or 
    (> (* 1 var126  )  0 )
)
  (or 
    (> (+ (* 1 var127  ) (* (- 0 1) var128  ) ) 0 )
)
  (or 
    (> (* 1 var127  )  0 )
)
  (or 
    (< (+ (* 1 var7 var129  ) (* 1 var5  ) (* (- 0 1) var125  ) ) 0 )
)
  (or 
    (> (* 1 var125  )  0 )
)
  (or 
    (> (+ (* 1 var24  ) (* (- 0 1) var130  ) ) 0 )
)
  (or 
    (> (* 1 var24  )  0 )
)
  (or 
    (> (+ (* 20 var23  ) (* (- 0 11) var131  ) (* (- 0 9) var132  ) ) 0 )
)
  (or 
    (> (* 1 var23  )  0 )
)
  (or 
    (> (+ (* 10 var131  ) (* (- 0 1) var133  ) (* (- 0 9) var134  ) ) 0 )
)
  (or 
    (> (* 1 var131  )  0 )
)
  (or 
    (< (+ (* 1 var39 var135  ) (* 1 var40 var136  ) (* (- 0 1) var133  ) ) 0 )
)
  (or 
    (> (* 1 var133  )  0 )
)
  (or 
    (> (+ (* 1 var136  ) (* (- 0 1) var137  ) ) 0 )
)
  (or 
    (> (* 1 var136  )  0 )
)
  (or 
    (> (+ (* 1 var137  ) (* (- 0 1) var138  ) ) 0 )
)
  (or 
    (> (* 1 var137  )  0 )
)
  (or 
    (> (+ (* 1 var134  ) (* (- 0 1) var139  ) ) 0 )
)
  (or 
    (> (* 1 var134  )  0 )
)
  (or 
    (> (+ (* 1 var139  ) (* (- 0 1) var140  ) ) 0 )
)
  (or 
    (> (* 1 var139  )  0 )
)
  (or 
    (> (+ (* 10 var132  ) (* (- 0 1) var141  ) (- 0 9) ) 0 )
)
  (or 
    (> (* 1 var132  )  0 )
)
  (or 
    (< (+ (* 1 var5 var142  ) (* 1 var7 var143  ) (* (- 0 1) var141  ) ) 0 )
)
  (or 
    (> (* 1 var141  )  0 )
)
  (or 
    (> (+ (* 1 var142  ) (* (- 0 1) var144  ) ) 0 )
)
  (or 
    (> (* 1 var142  )  0 )
)
  (or 
    (> (+ (* 1 var144  ) (* (- 0 1) var145  ) ) 0 )
)
  (or 
    (> (* 1 var144  )  0 )
)
  (or 
    (> (+ (* 1 var22  ) (* (- 0 1) var146  ) ) 0 )
)
  (or 
    (> (* 1 var22  )  0 )
)
  (or 
    (< (+ (* 1 var27 var147  ) (* 1 var28 var148  ) (* 1 var29 var149  ) (* (- 0 1) var19  ) (* 1 var23  ) (* 1 var25  ) ) 0 )
)
  (or 
    (> (* 1 var19  )  0 )
)
  (or 
    (> (+ (* 1 var149  ) (* (- 0 1) var150  ) ) 0 )
)
  (or 
    (> (* 1 var149  )  0 )
)
  (or 
    (> (+ (* 1 var148  ) (* (- 0 1) var151  ) ) 0 )
)
  (or 
    (> (* 1 var148  )  0 )
)
  (or 
    (< (+ (* 1 var19  ) (* (- 0 1) var147  ) ) 0 )
)
  (or 
    (> (* 1 var147  )  0 )
)
  (or 
    (> (+ (* 1 var18  ) (* (- 0 1) var152  ) ) 0 )
)
  (or 
    (> (* 1 var18  )  0 )
)
  (or 
    (> (+ (* 1 var152  ) (* (- 0 1) var153  ) ) 0 )
)
  (or 
    (> (* 1 var152  )  0 )
)
  (or 
    (< (+ (* 1 var0 var154  ) (* 1 var2  ) (* (- 0 1) var14  ) ) 0 )
)
  (or 
    (> (* 1 var14  )  0 )
)
  (or 
    (> (+ (* 20 var12  ) (* (- 0 11) var155  ) (* (- 0 9) var156  ) ) 0 )
)
  (or 
    (> (* 1 var12  )  0 )
)
  (or 
    (< (+ (* 1 var21 var157  ) (* 1 var19  ) (* (- 0 1) var156  ) ) 0 )
)
  (or 
    (> (* 1 var156  )  0 )
)
  (or 
    (< (+ (* 1 var0 var158  ) (* 1 var2 var159  ) (* (- 0 1) var155  ) ) 0 )
)
  (or 
    (> (* 1 var155  )  0 )
)
  (or 
    (> (+ (* 1 var159  ) (* (- 0 1) var160  ) ) 0 )
)
  (or 
    (> (* 1 var159  )  0 )
)
  (or 
    (> (+ (* 1 var160  ) (* (- 0 1) var161  ) ) 0 )
)
  (or 
    (> (* 1 var160  )  0 )
)
  (or 
    (> (+ (* 1 var11  ) (* (- 0 1) var162  ) ) 0 )
)
  (or 
    (> (* 1 var11  )  0 )
)
  (or 
    (> (+ (* 20 var10  ) (* (- 0 11) var163  ) (* (- 0 9) var164  ) ) 0 )
)
  (or 
    (> (* 1 var10  )  0 )
)
  (or 
    (< (+ (* 1 var19 var165  ) (* 1 var21  ) (* (- 0 1) var164  ) ) 0 )
)
  (or 
    (> (* 1 var164  )  0 )
)
  (or 
    (> (+ (* 1 var165  ) (* (- 0 1) var166  ) ) 0 )
)
  (or 
    (> (* 1 var165  )  0 )
)
  (or 
    (> (+ (* 1 var166  ) (* (- 0 1) var167  ) ) 0 )
)
  (or 
    (> (* 1 var166  )  0 )
)
  (or 
    (< (+ (* 1 var2 var168  ) (* 1 var0  ) (* (- 0 1) var163  ) ) 0 )
)
  (or 
    (> (* 1 var163  )  0 )
)
  (or 
    (> (+ (* 1 var168  ) (* (- 0 1) var169  ) ) 0 )
)
  (or 
    (> (* 1 var168  )  0 )
)
  (or 
    (> (+ (* 1 var169  ) (* (- 0 1) var170  ) ) 0 )
)
  (or 
    (> (* 1 var169  )  0 )
)
  (or 
    (< (+ (* 1 var7  ) (* (- 0 1) var9  ) ) 0 )
)
  (or 
    (> (* 1 var9  )  0 )
)
  (or 
    (< (+ (* 1 var10 var171  ) (* 1 var13 var172  ) (* (- 0 1) var5  ) (* 1 var12  ) ) 0 )
)
  (or 
    (> (* 1 var5  )  0 )
)
  (or 
    (> (+ (* 1 var172  ) (* (- 0 1) var173  ) ) 0 )
)
  (or 
    (> (* 1 var172  )  0 )
)
  (or 
    (< (+ (* 1 var5  ) (* (- 0 1) var171  ) ) 0 )
)
  (or 
    (> (* 1 var171  )  0 )
)
  (or 
    (> (+ (* 1 var4  ) (* (- 0 1) var174  ) ) 0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
  (or 
    (> (+ (* 1 var174  ) (* (- 0 1) var175  ) ) 0 )
)
  (or 
    (> (* 1 var174  )  0 )
)
  (or 
    (< (+ (* 1 var5 var176  ) (* 1 var7 var177  ) (* (- 0 1) var178  ) ) 0 )
)
  (or 
    (> (* 1 var178  )  0 )
)
  (or 
    (> (+ (* 1 var176  ) (* (- 0 1) var179  ) ) 0 )
)
  (or 
    (> (* 1 var176  )  0 )
)
  (or 
    (> (+ (* 1 var179  ) (* (- 0 1) var180  ) ) 0 )
)
  (or 
    (> (* 1 var179  )  0 )
)
  (or 
    (< (+ (* 1 var8  ) (* 9 var181  ) (* (- 0 10) var182  ) ) 0 )
)
  (or 
    (> (* 1 var182  )  0 )
)
  (or 
    (> (+ (* 1 var181  ) (* (- 0 1) var183  ) ) 0 )
)
  (or 
    (> (* 1 var181  )  0 )
)
  (or 
    (> (+ (* 1 var183  ) (* (- 0 1) var184  ) ) 0 )
)
  (or 
    (> (* 1 var183  )  0 )
)
  (or 
    (< (+ (* 1 var178  ) (* 9 var185  ) (* (- 0 10) var186  ) ) 0 )
)
  (or 
    (> (* 1 var186  )  0 )
)
  (or 
    (> (+ (* 1 var185  ) (* (- 0 1) var187  ) ) 0 )
)
  (or 
    (> (* 1 var185  )  0 )
)
  (or 
    (> (+ (* 1 var187  ) (* (- 0 1) var188  ) ) 0 )
)
  (or 
    (> (* 1 var187  )  0 )
)
  (or 
    (< (+ (* 1 var189  ) (* (- 0 1) var190  ) ) 0 )
)
  (or 
    (> (* 1 var190  )  0 )
)
  (or 
    (< (+ (* 1 var191  ) (* (- 0 1) var192  ) ) 0 )
)
  (or 
    (> (* 1 var192  )  0 )
)
  (or 
    (< (+ (* 1 var0 var193  ) (* 1 var2 var194  ) (* (- 0 1) var195  ) ) 0 )
)
  (or 
    (> (* 1 var195  )  0 )
)
  (or 
    (> (+ (* 1 var194  ) (* (- 0 1) var196  ) ) 0 )
)
  (or 
    (> (* 1 var194  )  0 )
)
  (or 
    (> (+ (* 1 var196  ) (* (- 0 1) var197  ) ) 0 )
)
  (or 
    (> (* 1 var196  )  0 )
)
  (or 
    (< (+ (* 1 var0 var198  ) (* 1 var2 var199  ) (* (- 0 1) var200  ) ) 0 )
)
  (or 
    (> (* 1 var200  )  0 )
)
  (or 
    (> (+ (* 1 var199  ) (* (- 0 1) var201  ) ) 0 )
)
  (or 
    (> (* 1 var199  )  0 )
)
  (or 
    (> (+ (* 1 var201  ) (* (- 0 1) var202  ) ) 0 )
)
  (or 
    (> (* 1 var201  )  0 )
)
  (or 
    (< (+ (* 1 var203  ) (* (- 0 1) var204  ) ) 0 )
)
  (or 
    (> (* 1 var204  )  0 )
)
  (or 
    (< (+ (* 1 var205  ) (* (- 0 1) var206  ) ) 0 )
)
  (or 
    (> (* 1 var206  )  0 )
)
  (or 
    (< (+ (* 1 var39 var207  ) (* 1 var40 var208  ) (* (- 0 1) var209  ) ) 0 )
)
  (or 
    (> (* 1 var209  )  0 )
)
  (or 
    (> (+ (* 1 var208  ) (* (- 0 1) var210  ) ) 0 )
)
  (or 
    (> (* 1 var208  )  0 )
)
  (or 
    (> (+ (* 1 var210  ) (* (- 0 1) var211  ) ) 0 )
)
  (or 
    (> (* 1 var210  )  0 )
)
  (or 
    (< (+ (* 1 var39 var212  ) (* 1 var40 var213  ) (* (- 0 1) var214  ) ) 0 )
)
  (or 
    (> (* 1 var214  )  0 )
)
  (or 
    (> (+ (* 1 var213  ) (* (- 0 1) var215  ) ) 0 )
)
  (or 
    (> (* 1 var213  )  0 )
)
  (or 
    (> (+ (* 1 var215  ) (* (- 0 1) var216  ) ) 0 )
)
  (or 
    (> (* 1 var215  )  0 )
)
  (or 
    (< (+ (* 1 var209  ) (* 9 var217  ) (* (- 0 10) var218  ) ) 0 )
)
  (or 
    (> (* 1 var218  )  0 )
)
  (or 
    (> (+ (* 1 var217  ) (* (- 0 1) var219  ) ) 0 )
)
  (or 
    (> (* 1 var217  )  0 )
)
  (or 
    (> (+ (* 1 var219  ) (* (- 0 1) var220  ) ) 0 )
)
  (or 
    (> (* 1 var219  )  0 )
)
  (or 
    (< (+ (* 1 var214  ) (* 9 var221  ) (* (- 0 10) var222  ) ) 0 )
)
  (or 
    (> (* 1 var222  )  0 )
)
  (or 
    (> (+ (* 1 var221  ) (* (- 0 1) var223  ) ) 0 )
)
  (or 
    (> (* 1 var221  )  0 )
)
  (or 
    (> (+ (* 1 var223  ) (* (- 0 1) var224  ) ) 0 )
)
  (or 
    (> (* 1 var223  )  0 )
)
  (or 
    (< (+ (* 1 var225  ) (* (- 0 1) var226  ) ) 0 )
)
  (or 
    (> (* 1 var226  )  0 )
)
  (or 
    (< (+ (* 1 var227  ) (* (- 0 1) var228  ) ) 0 )
)
  (or 
    (> (* 1 var228  )  0 )
)
  (or 
    (< (+ (* 1 var19 var229  ) (* 1 var21 var230  ) (* (- 0 1) var231  ) ) 0 )
)
  (or 
    (> (* 1 var231  )  0 )
)
  (or 
    (> (+ (* 1 var229  ) (* (- 0 1) var232  ) ) 0 )
)
  (or 
    (> (* 1 var229  )  0 )
)
  (or 
    (> (+ (* 1 var232  ) (* (- 0 1) var233  ) ) 0 )
)
  (or 
    (> (* 1 var232  )  0 )
)
  (or 
    (< (+ (* 1 var19 var234  ) (* 1 var21 var235  ) (* (- 0 1) var236  ) ) 0 )
)
  (or 
    (> (* 1 var236  )  0 )
)
  (or 
    (> (+ (* 1 var234  ) (* (- 0 1) var237  ) ) 0 )
)
  (or 
    (> (* 1 var234  )  0 )
)
  (or 
    (> (+ (* 1 var237  ) (* (- 0 1) var238  ) ) 0 )
)
  (or 
    (> (* 1 var237  )  0 )
)
  (or 
    (< (+ (* 1 var0 var239  ) (* 1 var2 var240  ) (* (- 0 1) var241  ) ) 0 )
)
  (or 
    (> (* 1 var241  )  0 )
)
  (or 
    (> (+ (* 1 var240  ) (* (- 0 1) var242  ) ) 0 )
)
  (or 
    (> (* 1 var240  )  0 )
)
  (or 
    (> (+ (* 1 var242  ) (* (- 0 1) var243  ) ) 0 )
)
  (or 
    (> (* 1 var242  )  0 )
)
  (or 
    (< (+ (* 1 var0 var244  ) (* 1 var2 var245  ) (* (- 0 1) var246  ) ) 0 )
)
  (or 
    (> (* 1 var246  )  0 )
)
  (or 
    (> (+ (* 1 var245  ) (* (- 0 1) var247  ) ) 0 )
)
  (or 
    (> (* 1 var245  )  0 )
)
  (or 
    (> (+ (* 1 var247  ) (* (- 0 1) var248  ) ) 0 )
)
  (or 
    (> (* 1 var247  )  0 )
)
  (or 
    (< (+ (* 9 var231  ) (* 11 var241  ) (* (- 0 20) var249  ) ) 0 )
)
  (or 
    (> (* 1 var249  )  0 )
)
  (or 
    (< (+ (* 9 var236  ) (* 11 var246  ) (* (- 0 20) var250  ) ) 0 )
)
  (or 
    (> (* 1 var250  )  0 )
)
  (or 
    (< (+ (* 1 var10 var226  ) (* 1 var12 var251  ) (* 1 var13 var252  ) (* (- 0 1) var225  ) ) 0 )
)
  (or 
    (> (* 1 var225  )  0 )
)
  (or 
    (> (+ (* 1 var252  ) (* (- 0 1) var253  ) ) 0 )
)
  (or 
    (> (* 1 var252  )  0 )
)
  (or 
    (> (+ (* 1 var251  ) (* (- 0 1) var254  ) ) 0 )
)
  (or 
    (> (* 1 var251  )  0 )
)
  (or 
    (< (+ (* 1 var10 var228  ) (* 1 var12 var255  ) (* 1 var13 var256  ) (* (- 0 1) var227  ) ) 0 )
)
  (or 
    (> (* 1 var227  )  0 )
)
  (or 
    (> (+ (* 1 var256  ) (* (- 0 1) var257  ) ) 0 )
)
  (or 
    (> (* 1 var256  )  0 )
)
  (or 
    (> (+ (* 1 var255  ) (* (- 0 1) var258  ) ) 0 )
)
  (or 
    (> (* 1 var255  )  0 )
)
  (or 
    (< (+ (* 1 var5 var259  ) (* 1 var7 var260  ) (* (- 0 1) var261  ) ) 0 )
)
  (or 
    (> (* 1 var261  )  0 )
)
  (or 
    (> (+ (* 1 var259  ) (* (- 0 1) var262  ) ) 0 )
)
  (or 
    (> (* 1 var259  )  0 )
)
  (or 
    (> (+ (* 1 var262  ) (* (- 0 1) var263  ) ) 0 )
)
  (or 
    (> (* 1 var262  )  0 )
)
  (or 
    (< (+ (* 1 var5 var264  ) (* 1 var7 var265  ) (* (- 0 1) var266  ) ) 0 )
)
  (or 
    (> (* 1 var266  )  0 )
)
  (or 
    (> (+ (* 1 var264  ) (* (- 0 1) var267  ) ) 0 )
)
  (or 
    (> (* 1 var264  )  0 )
)
  (or 
    (> (+ (* 1 var267  ) (* (- 0 1) var268  ) ) 0 )
)
  (or 
    (> (* 1 var267  )  0 )
)
  (or 
    (< (+ (* 1 var261  ) (* 9 var269  ) (* (- 0 10) var270  ) ) 0 )
)
  (or 
    (> (* 1 var270  )  0 )
)
  (or 
    (> (+ (* 1 var269  ) (* (- 0 1) var271  ) ) 0 )
)
  (or 
    (> (* 1 var269  )  0 )
)
  (or 
    (> (+ (* 1 var271  ) (* (- 0 1) var272  ) ) 0 )
)
  (or 
    (> (* 1 var271  )  0 )
)
  (or 
    (< (+ (* 1 var266  ) (* 9 var273  ) (* (- 0 10) var274  ) ) 0 )
)
  (or 
    (> (* 1 var274  )  0 )
)
  (or 
    (> (+ (* 1 var273  ) (* (- 0 1) var275  ) ) 0 )
)
  (or 
    (> (* 1 var273  )  0 )
)
  (or 
    (> (+ (* 1 var275  ) (* (- 0 1) var276  ) ) 0 )
)
  (or 
    (> (* 1 var275  )  0 )
)
  (or 
    (< (+ (* 11 var218  ) (* 9 var270  ) (* (- 0 20) var277  ) ) 0 )
)
  (or 
    (> (* 1 var277  )  0 )
)
  (or 
    (< (+ (* 11 var222  ) (* 9 var274  ) (* (- 0 20) var278  ) ) 0 )
)
  (or 
    (> (* 1 var278  )  0 )
)
  (or 
    (< (+ (* 1 var23 var279  ) (* 1 var25 var280  ) (* 1 var27 var204  ) (* 1 var28 var281  ) (* 1 var29 var282  ) (* (- 0 1) var203  ) ) 0 )
)
  (or 
    (> (* 1 var203  )  0 )
)
  (or 
    (> (+ (* 1 var282  ) (* (- 0 1) var283  ) ) 0 )
)
  (or 
    (> (* 1 var282  )  0 )
)
  (or 
    (> (+ (* 1 var281  ) (* (- 0 1) var284  ) ) 0 )
)
  (or 
    (> (* 1 var281  )  0 )
)
  (or 
    (> (+ (* 1 var280  ) (* (- 0 1) var285  ) ) 0 )
)
  (or 
    (> (* 1 var280  )  0 )
)
  (or 
    (> (+ (* 1 var279  ) (* (- 0 1) var286  ) ) 0 )
)
  (or 
    (> (* 1 var279  )  0 )
)
  (or 
    (< (+ (* 1 var23 var287  ) (* 1 var25 var288  ) (* 1 var27 var206  ) (* 1 var28 var289  ) (* 1 var29 var290  ) (* (- 0 1) var205  ) ) 0 )
)
  (or 
    (> (* 1 var205  )  0 )
)
  (or 
    (> (+ (* 1 var290  ) (* (- 0 1) var291  ) ) 0 )
)
  (or 
    (> (* 1 var290  )  0 )
)
  (or 
    (> (+ (* 1 var289  ) (* (- 0 1) var292  ) ) 0 )
)
  (or 
    (> (* 1 var289  )  0 )
)
  (or 
    (> (+ (* 1 var288  ) (* (- 0 1) var293  ) ) 0 )
)
  (or 
    (> (* 1 var288  )  0 )
)
  (or 
    (> (+ (* 1 var287  ) (* (- 0 1) var294  ) ) 0 )
)
  (or 
    (> (* 1 var287  )  0 )
)
  (or 
    (< (+ (* 1 var19 var295  ) (* 1 var21 var296  ) (* (- 0 1) var297  ) ) 0 )
)
  (or 
    (> (* 1 var297  )  0 )
)
  (or 
    (> (+ (* 1 var295  ) (* (- 0 1) var298  ) ) 0 )
)
  (or 
    (> (* 1 var295  )  0 )
)
  (or 
    (> (+ (* 1 var298  ) (* (- 0 1) var299  ) ) 0 )
)
  (or 
    (> (* 1 var298  )  0 )
)
  (or 
    (< (+ (* 1 var19 var300  ) (* 1 var21 var301  ) (* (- 0 1) var302  ) ) 0 )
)
  (or 
    (> (* 1 var302  )  0 )
)
  (or 
    (> (+ (* 1 var300  ) (* (- 0 1) var303  ) ) 0 )
)
  (or 
    (> (* 1 var300  )  0 )
)
  (or 
    (> (+ (* 1 var303  ) (* (- 0 1) var304  ) ) 0 )
)
  (or 
    (> (* 1 var303  )  0 )
)
  (or 
    (< (+ (* 11 var195  ) (* 9 var297  ) (* (- 0 20) var305  ) ) 0 )
)
  (or 
    (> (* 1 var305  )  0 )
)
  (or 
    (< (+ (* 11 var200  ) (* 9 var302  ) (* (- 0 20) var306  ) ) 0 )
)
  (or 
    (> (* 1 var306  )  0 )
)
  (or 
    (< (+ (* 1 var42 var307  ) (* 1 var44 var190  ) (* 1 var45 var308  ) (* (- 0 1) var189  ) ) 0 )
)
  (or 
    (> (* 1 var189  )  0 )
)
  (or 
    (> (+ (* 1 var308  ) (* (- 0 1) var309  ) ) 0 )
)
  (or 
    (> (* 1 var308  )  0 )
)
  (or 
    (> (+ (* 1 var307  ) (* (- 0 1) var310  ) ) 0 )
)
  (or 
    (> (* 1 var307  )  0 )
)
  (or 
    (< (+ (* 1 var42 var311  ) (* 1 var44 var192  ) (* 1 var45 var312  ) (* (- 0 1) var191  ) ) 0 )
)
  (or 
    (> (* 1 var191  )  0 )
)
  (or 
    (> (+ (* 1 var312  ) (* (- 0 1) var313  ) ) 0 )
)
  (or 
    (> (* 1 var312  )  0 )
)
  (or 
    (> (+ (* 1 var311  ) (* (- 0 1) var314  ) ) 0 )
)
  (or 
    (> (* 1 var311  )  0 )
)
  (or 
    (< (+ (* 1 var39 var315  ) (* 1 var40 var316  ) (* (- 0 1) var317  ) ) 0 )
)
  (or 
    (> (* 1 var317  )  0 )
)
  (or 
    (> (+ (* 1 var316  ) (* (- 0 1) var318  ) ) 0 )
)
  (or 
    (> (* 1 var316  )  0 )
)
  (or 
    (> (+ (* 1 var318  ) (* (- 0 1) var319  ) ) 0 )
)
  (or 
    (> (* 1 var318  )  0 )
)
  (or 
    (< (+ (* 1 var39 var320  ) (* 1 var40 var321  ) (* (- 0 1) var322  ) ) 0 )
)
  (or 
    (> (* 1 var322  )  0 )
)
  (or 
    (> (+ (* 1 var321  ) (* (- 0 1) var323  ) ) 0 )
)
  (or 
    (> (* 1 var321  )  0 )
)
  (or 
    (> (+ (* 1 var323  ) (* (- 0 1) var324  ) ) 0 )
)
  (or 
    (> (* 1 var323  )  0 )
)
  (or 
    (< (+ (* 1 var317  ) (* 9 var325  ) (* (- 0 10) var326  ) ) 0 )
)
  (or 
    (> (* 1 var326  )  0 )
)
  (or 
    (> (+ (* 1 var325  ) (* (- 0 1) var327  ) ) 0 )
)
  (or 
    (> (* 1 var325  )  0 )
)
  (or 
    (> (+ (* 1 var327  ) (* (- 0 1) var328  ) ) 0 )
)
  (or 
    (> (* 1 var327  )  0 )
)
  (or 
    (< (+ (* 1 var322  ) (* 9 var329  ) (* (- 0 10) var330  ) ) 0 )
)
  (or 
    (> (* 1 var330  )  0 )
)
  (or 
    (> (+ (* 1 var329  ) (* (- 0 1) var331  ) ) 0 )
)
  (or 
    (> (* 1 var329  )  0 )
)
  (or 
    (> (+ (* 1 var331  ) (* (- 0 1) var332  ) ) 0 )
)
  (or 
    (> (* 1 var331  )  0 )
)
  (or 
    (< (+ (* 9 var182  ) (* 11 var326  ) (* (- 0 20) var333  ) ) 0 )
)
  (or 
    (> (* 1 var333  )  0 )
)
  (or 
    (< (+ (* 9 var186  ) (* 11 var330  ) (* (- 0 20) var334  ) ) 0 )
)
  (or 
    (> (* 1 var334  )  0 )
)
  (or 
    (< (+ (* 1 var1 var339  ) (* 1 var337 var338  ) (* 1 var340 var341  ) (* (- 0 1) var0  ) (* 1 var335  ) (* 1 var336  ) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (+ (* 20 var341  ) (* (- 0 11) var342  ) (* (- 0 9) var343  ) ) 0 )
)
  (or 
    (> (* 1 var341  )  0 )
)
  (or 
    (> (+ (* 10 var343  ) (* (- 0 1) var344  ) (* (- 0 9) var345  ) ) 0 )
)
  (or 
    (> (* 1 var343  )  0 )
)
  (or 
    (> (+ (* 1 var345  ) (* (- 0 1) var346  ) ) 0 )
)
  (or 
    (> (* 1 var345  )  0 )
)
  (or 
    (> (+ (* 1 var346  ) (* (- 0 1) var347  ) ) 0 )
)
  (or 
    (> (* 1 var346  )  0 )
)
  (or 
    (< (+ (* 1 var5 var348  ) (* 1 var7 var349  ) (* (- 0 1) var344  ) ) 0 )
)
  (or 
    (> (* 1 var344  )  0 )
)
  (or 
    (> (+ (* 1 var348  ) (* (- 0 1) var350  ) ) 0 )
)
  (or 
    (> (* 1 var348  )  0 )
)
  (or 
    (> (+ (* 1 var350  ) (* (- 0 1) var351  ) ) 0 )
)
  (or 
    (> (* 1 var350  )  0 )
)
  (or 
    (> (+ (* 10 var342  ) (* (- 0 1) var352  ) (* (- 0 9) var353  ) ) 0 )
)
  (or 
    (> (* 1 var342  )  0 )
)
  (or 
    (> (+ (* 1 var353  ) (* (- 0 1) var354  ) ) 0 )
)
  (or 
    (> (* 1 var353  )  0 )
)
  (or 
    (> (+ (* 1 var354  ) (* (- 0 1) var355  ) ) 0 )
)
  (or 
    (> (* 1 var354  )  0 )
)
  (or 
    (< (+ (* 1 var39 var356  ) (* 1 var40  ) (* (- 0 1) var352  ) ) 0 )
)
  (or 
    (> (* 1 var352  )  0 )
)
  (or 
    (> (+ (* 1 var340  ) (* (- 0 1) var357  ) ) 0 )
)
  (or 
    (> (* 1 var340  )  0 )
)
  (or 
    (> (+ (* 20 var339  ) (* (- 0 11) var358  ) (* (- 0 9) var359  ) ) 0 )
)
  (or 
    (> (* 1 var339  )  0 )
)
  (or 
    (> (+ (* 10 var359  ) (* (- 0 1) var360  ) (* (- 0 9) var361  ) ) 0 )
)
  (or 
    (> (* 1 var359  )  0 )
)
  (or 
    (> (+ (* 1 var361  ) (* (- 0 1) var362  ) ) 0 )
)
  (or 
    (> (* 1 var361  )  0 )
)
  (or 
    (> (+ (* 1 var362  ) (* (- 0 1) var363  ) ) 0 )
)
  (or 
    (> (* 1 var362  )  0 )
)
  (or 
    (< (+ (* 1 var5 var364  ) (* 1 var7  ) (* (- 0 1) var360  ) ) 0 )
)
  (or 
    (> (* 1 var360  )  0 )
)
  (or 
    (> (+ (* 1 var364  ) (* (- 0 1) var365  ) ) 0 )
)
  (or 
    (> (* 1 var364  )  0 )
)
  (or 
    (> (+ (* 1 var365  ) (* (- 0 1) var366  ) ) 0 )
)
  (or 
    (> (* 1 var365  )  0 )
)
  (or 
    (> (+ (* 10 var358  ) (* (- 0 1) var367  ) (* (- 0 9) var368  ) ) 0 )
)
  (or 
    (> (* 1 var358  )  0 )
)
  (or 
    (> (+ (* 1 var368  ) (* (- 0 1) var369  ) ) 0 )
)
  (or 
    (> (* 1 var368  )  0 )
)
  (or 
    (> (+ (* 1 var369  ) (* (- 0 1) var370  ) ) 0 )
)
  (or 
    (> (* 1 var369  )  0 )
)
  (or 
    (< (+ (* 1 var40 var371  ) (* 1 var39  ) (* (- 0 1) var367  ) ) 0 )
)
  (or 
    (> (* 1 var367  )  0 )
)
  (or 
    (> (+ (* 1 var371  ) (* (- 0 1) var372  ) ) 0 )
)
  (or 
    (> (* 1 var371  )  0 )
)
  (or 
    (> (+ (* 1 var372  ) (* (- 0 1) var373  ) ) 0 )
)
  (or 
    (> (* 1 var372  )  0 )
)
  (or 
    (> (+ (* 20 var338  ) (* (- 0 11) var374  ) (* (- 0 9) var375  ) ) 0 )
)
  (or 
    (> (* 1 var338  )  0 )
)
  (or 
    (> (+ (* 10 var375  ) (* (- 0 1) var376  ) (* (- 0 9) var377  ) ) 0 )
)
  (or 
    (> (* 1 var375  )  0 )
)
  (or 
    (> (+ (* 1 var377  ) (* (- 0 1) var378  ) ) 0 )
)
  (or 
    (> (* 1 var377  )  0 )
)
  (or 
    (> (+ (* 1 var378  ) (* (- 0 1) var379  ) ) 0 )
)
  (or 
    (> (* 1 var378  )  0 )
)
  (or 
    (< (+ (* 1 var5 var380  ) (* 1 var7 var381  ) (* (- 0 1) var376  ) ) 0 )
)
  (or 
    (> (* 1 var376  )  0 )
)
  (or 
    (> (+ (* 1 var380  ) (* (- 0 1) var382  ) ) 0 )
)
  (or 
    (> (* 1 var380  )  0 )
)
  (or 
    (> (+ (* 1 var382  ) (* (- 0 1) var383  ) ) 0 )
)
  (or 
    (> (* 1 var382  )  0 )
)
  (or 
    (> (+ (* 10 var374  ) (* (- 0 1) var384  ) (- 0 9) ) 0 )
)
  (or 
    (> (* 1 var374  )  0 )
)
  (or 
    (< (+ (* 1 var39 var385  ) (* 1 var40 var386  ) (* (- 0 1) var384  ) ) 0 )
)
  (or 
    (> (* 1 var384  )  0 )
)
  (or 
    (> (+ (* 1 var386  ) (* (- 0 1) var387  ) ) 0 )
)
  (or 
    (> (* 1 var386  )  0 )
)
  (or 
    (> (+ (* 1 var387  ) (* (- 0 1) var388  ) ) 0 )
)
  (or 
    (> (* 1 var387  )  0 )
)
  (or 
    (> (+ (* 1 var337  ) (* (- 0 1) var389  ) ) 0 )
)
  (or 
    (> (* 1 var337  )  0 )
)
  (or 
    (> (+ (* 20 var336  ) (* (- 0 11) var390  ) (* (- 0 9) var391  ) ) 0 )
)
  (or 
    (> (* 1 var336  )  0 )
)
  (or 
    (> (+ (* 10 var391  ) (* (- 0 1) var392  ) (* (- 0 9) var393  ) ) 0 )
)
  (or 
    (> (* 1 var391  )  0 )
)
  (or 
    (> (+ (* 1 var393  ) (* (- 0 1) var394  ) ) 0 )
)
  (or 
    (> (* 1 var393  )  0 )
)
  (or 
    (> (+ (* 1 var394  ) (* (- 0 1) var395  ) ) 0 )
)
  (or 
    (> (* 1 var394  )  0 )
)
  (or 
    (< (+ (* 1 var7 var396  ) (* 1 var5  ) (* (- 0 1) var392  ) ) 0 )
)
  (or 
    (> (* 1 var392  )  0 )
)
  (or 
    (> (+ (* 10 var390  ) (* (- 0 1) var397  ) (* (- 0 9) var398  ) ) 0 )
)
  (or 
    (> (* 1 var390  )  0 )
)
  (or 
    (> (+ (* 1 var398  ) (* (- 0 1) var399  ) ) 0 )
)
  (or 
    (> (* 1 var398  )  0 )
)
  (or 
    (> (+ (* 1 var399  ) (* (- 0 1) var400  ) ) 0 )
)
  (or 
    (> (* 1 var399  )  0 )
)
  (or 
    (< (+ (* 1 var39 var401  ) (* 1 var40 var402  ) (* (- 0 1) var397  ) ) 0 )
)
  (or 
    (> (* 1 var397  )  0 )
)
  (or 
    (> (+ (* 1 var402  ) (* (- 0 1) var403  ) ) 0 )
)
  (or 
    (> (* 1 var402  )  0 )
)
  (or 
    (> (+ (* 1 var403  ) (* (- 0 1) var404  ) ) 0 )
)
  (or 
    (> (* 1 var403  )  0 )
)
  (or 
    (> (+ (* 20 var335  ) (* (- 0 11) var405  ) (* (- 0 9) var406  ) ) 0 )
)
  (or 
    (> (* 1 var335  )  0 )
)
  (or 
    (> (+ (* 10 var406  ) (* (- 0 1) var407  ) (- 0 9) ) 0 )
)
  (or 
    (> (* 1 var406  )  0 )
)
  (or 
    (< (+ (* 1 var5 var408  ) (* 1 var7 var409  ) (* (- 0 1) var407  ) ) 0 )
)
  (or 
    (> (* 1 var407  )  0 )
)
  (or 
    (> (+ (* 1 var408  ) (* (- 0 1) var410  ) ) 0 )
)
  (or 
    (> (* 1 var408  )  0 )
)
  (or 
    (> (+ (* 1 var410  ) (* (- 0 1) var411  ) ) 0 )
)
  (or 
    (> (* 1 var410  )  0 )
)
  (or 
    (> (+ (* 10 var405  ) (* (- 0 1) var412  ) (* (- 0 9) var413  ) ) 0 )
)
  (or 
    (> (* 1 var405  )  0 )
)
  (or 
    (> (+ (* 1 var413  ) (* (- 0 1) var414  ) ) 0 )
)
  (or 
    (> (* 1 var413  )  0 )
)
  (or 
    (> (+ (* 1 var414  ) (* (- 0 1) var415  ) ) 0 )
)
  (or 
    (> (* 1 var414  )  0 )
)
  (or 
    (< (+ (* 1 var39 var416  ) (* 1 var40 var417  ) (* (- 0 1) var412  ) ) 0 )
)
  (or 
    (> (* 1 var412  )  0 )
)
  (or 
    (> (+ (* 1 var417  ) (* (- 0 1) var418  ) ) 0 )
)
  (or 
    (> (* 1 var417  )  0 )
)
  (or 
    (> (+ (* 1 var418  ) (* (- 0 1) var419  ) ) 0 )
)
  (or 
    (> (* 1 var418  )  0 )
)
  (or 
    (< (+ (* 1 var3 var339  ) (* 1 var335 var420  ) (* 1 var336 var421  ) (* (- 0 1) var2  ) (* 1 var338  ) (* 1 var341  ) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (+ (* 1 var421  ) (* (- 0 1) var422  ) ) 0 )
)
  (or 
    (> (* 1 var421  )  0 )
)
  (or 
    (> (+ (* 1 var420  ) (* (- 0 1) var423  ) ) 0 )
)
  (or 
    (> (* 1 var420  )  0 )
)
))
(check-sat)
(exit)
