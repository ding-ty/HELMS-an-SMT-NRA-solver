(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/asin/8/vars4/asin-8-vars4-chunk-0050.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (> (+ (* 126 var0 var0 var1 var3  ) (* (- 0 126) var0 var0 var2 var3  ) (* 65 var0 var0 var1  ) (* (- 0 61) var0 var0 var2  ) (* 8 var0 var0  ) (* 40 var0 var1  ) (* 40 var0 var2  ) (* (- 0 126) var1 var3  ) (* 126 var2 var3  ) (* 160 var0  ) (* (- 0 65) var1  ) (* 61 var2  ) (- 0 8) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
