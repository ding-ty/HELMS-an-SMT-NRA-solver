(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Nichols-Plot/Inverted-Pendulum/Nichols-Plot-Inverted-Pendulum-Fails-1-6-chunk-0029.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (* 1 var1  )  0 )
)
  (or 
    (> (+ (* 5000000 var2  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10000000 var2  ) (- 0 31415927) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
))
(check-sat)
(exit)
