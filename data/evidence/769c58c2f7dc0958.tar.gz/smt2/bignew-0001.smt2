(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20161105-Sturm-MBO/mbo_E23E24.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(assert (and
  (or 
    (> (* 1 var5  )  0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
