(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20180501-Economics-Mulligan/MulliganEconomicsModel0085a.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(assert (and
  (or 
    (> (* 1 var2 var4  )  0 )
)
  (or 
    (< (+ (* 1 var2 var2  ) (* (- 0 1) var2 var3  ) ) 0 )
)
  (or 
    (> (* 1 var5  )  0 )
)
  (or 
    (> (* 1 var7  )  0 )
)
  (or 
    (> (+ (* 1 var5 var7  ) (* (- 0 1) var6 var6  ) ) 0 )
)
  (or 
    (> (+ (* 1 var2  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var2 var5  ) (* (- 0 1) var3 var3  ) ) 0 )
)
  (or 
    (> (+ (* 1 var2 var7  ) (* (- 0 1) var4 var4  ) ) 0 )
)
))
(check-sat)
(exit)
