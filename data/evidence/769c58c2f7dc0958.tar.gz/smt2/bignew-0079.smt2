(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/asin/8/asin-8-chunk-0044.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(assert (and
  (or 
    (< (+ (* 20 var0 var2 var3  ) (* (- 0 20) var1 var2 var3  ) (* 10 var0 var3  ) (* (- 0 10) var1 var3  ) (* (- 0 1) var0  ) (* (- 0 1) var1  ) (- 0 4) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var4  ) (* 1 var1 var4  ) (* 4 var4  ) ) 0 )
)
  (or 
    (> (+ (* 5000000 var3  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10000000 var3  ) (- 0 31415927) ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
  (or 
    (< (+ (* 1 var4  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
