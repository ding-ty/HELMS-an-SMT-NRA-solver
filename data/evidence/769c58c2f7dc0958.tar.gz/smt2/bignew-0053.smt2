(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Chua/1/VC1/L/Chua-1-VC1-L-chunk-0145.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 531441 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 106288200000) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 11514555000000000 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 856210500000000000000) var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 47608256250000000000000000 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 2066715000000000000000000000000) var0 var0 var0 var0 var0 var0 var0  ) (* 71350875000000000000000000000000000 var0 var0 var0 var0 var0 var0  ) (* (- 0 1968300000000000000000000000000000000000) var0 var0 var0 var0 var0  ) (* 43056562500000000000000000000000000000000000 var0 var0 var0 var0  ) (* (- 0 729000000000000000000000000000000000000000000000) var0 var0 var0  ) (* 9112500000000000000000000000000000000000000000000000 var0 var0  ) (* (- 0 75937500000000000000000000000000000000000000000000000000) var0  ) 316406250000000000000000000000000000000000000000000000000000 ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 689 var1  ) (* (- 0 1770) var2  ) ) 0 )
)
  (or 
    (< (+ (* 689 var1  ) (* (- 0 1770) var2  ) ) 0 )
)
  (or 
    (< (+ (* 689 var1  ) (* (- 0 1770) var2  ) ) 0 )
    (< (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 689 var1  ) (* (- 0 1770) var2  ) ) 0 )
    (< (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 289) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
