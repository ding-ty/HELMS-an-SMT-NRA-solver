(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Chua/2/IL/U/Chua-2-IL-U-chunk-0051.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (* 1 var0  )  0 )
)
  (or 
    (> (+ (* 451729667968489 var0 var0 var0 var0 var0 var0  ) (* (- 0 195695163018840000) var0 var0 var0 var0 var0  ) (* 49453651304400000000 var0 var0 var0 var0  ) (* (- 0 8161510272000000000000) var0 var0 var0  ) (* 883918080000000000000000 var0 var0  ) (* (- 0 63820800000000000000000000) var0  ) 2286028800000000000000000000 ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 75) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
