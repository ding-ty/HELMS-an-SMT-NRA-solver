(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/CMOS/CMOS-opamp-chunk-0118.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 150000000 var0 var0 var0 var0 var1 var1  ) (* 150000000000000000000000 var0 var0 var0 var0  ) (* (- 0 1800000000) var0 var0 var1 var1  ) (* (- 0 1800000000000000000000000) var0 var0  ) (* 3600120000 var1 var1  ) 3600120000000000000000000 ) 0 )
)
  (or 
    (> (+ (* 1 var1  ) (- 0 100) ) 0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 120) ) 0 )
)
  (or 
    (> (+ (* 4 var0  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (< (+ (* 3 var0  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (< (+ (* 10000000 var2  ) (- 0 31415927) ) 0 )
)
  (or 
    (> (+ (* 5000000 var2  ) (- 0 15707963) ) 0 )
)
))
(check-sat)
(exit)
