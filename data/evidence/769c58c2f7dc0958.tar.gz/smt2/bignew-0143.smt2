(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sin/344/4/sin-344-4-chunk-0045.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(assert (and
  (or 
    (< (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var0 var0 var0 var0 var0  ) (* (- 0 40) var0 var0 var0  ) (* (- 0 60) var0 var0 var1  ) (* (- 0 60) var0 var0 var2  ) (* (- 0 60) var0 var0 var3  ) (* (- 0 60) var0 var1 var1  ) (* (- 0 120) var0 var1 var2  ) (* (- 0 120) var0 var1 var3  ) (* (- 0 60) var0 var2 var2  ) (* (- 0 120) var0 var2 var3  ) (* (- 0 60) var0 var3 var3  ) (* (- 0 40) var1 var1 var1  ) (* (- 0 60) var1 var1 var2  ) (* (- 0 60) var1 var1 var3  ) (* (- 0 60) var1 var2 var2  ) (* (- 0 120) var1 var2 var3  ) (* (- 0 60) var1 var3 var3  ) (* (- 0 40) var2 var2 var2  ) (* (- 0 60) var2 var2 var3  ) (* (- 0 60) var2 var3 var3  ) (* (- 0 40) var3 var3 var3  ) (* 240 var0  ) (* 240 var1  ) (* 240 var2  ) (* 240 var3  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 1 var1  ) (- 0 3) ) 0 )
)
  (or 
    (< (+ (* 1 var3  ) (- 0 3) ) 0 )
)
  (or 
    (> (+ (* 10 var0  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 10 var2  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 10 var1  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 10 var3  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
