(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20170501-Heizmann-UltimateInvariantSynthesis/overflow1.i_3_8_2.bpl_9.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(declare-fun var8 () Real)
(declare-fun var9 () Real)
(declare-fun var10 () Real)
(declare-fun var11 () Real)
(declare-fun var12 () Real)
(declare-fun var13 () Real)
(declare-fun var14 () Real)
(declare-fun var15 () Real)
(declare-fun var16 () Real)
(declare-fun var17 () Real)
(declare-fun var18 () Real)
(declare-fun var19 () Real)
(declare-fun var20 () Real)
(declare-fun var21 () Real)
(declare-fun var22 () Real)
(declare-fun var23 () Real)
(declare-fun var24 () Real)
(declare-fun var25 () Real)
(declare-fun var26 () Real)
(declare-fun var27 () Real)
(declare-fun var28 () Real)
(declare-fun var29 () Real)
(declare-fun var30 () Real)
(declare-fun var31 () Real)
(declare-fun var32 () Real)
(declare-fun var33 () Real)
(declare-fun var34 () Real)
(declare-fun var35 () Real)
(declare-fun var36 () Real)
(declare-fun var37 () Real)
(declare-fun var38 () Real)
(declare-fun var39 () Real)
(declare-fun var40 () Real)
(declare-fun var41 () Real)
(declare-fun var42 () Real)
(declare-fun var43 () Real)
(declare-fun var44 () Real)
(declare-fun var45 () Real)
(declare-fun var46 () Real)
(declare-fun var47 () Real)
(declare-fun var48 () Real)
(declare-fun var49 () Real)
(declare-fun var50 () Real)
(declare-fun var51 () Real)
(declare-fun var52 () Real)
(declare-fun var53 () Real)
(declare-fun var54 () Real)
(declare-fun var55 () Real)
(declare-fun var56 () Real)
(declare-fun var57 () Real)
(declare-fun var58 () Real)
(declare-fun var59 () Real)
(declare-fun var60 () Real)
(declare-fun var61 () Real)
(declare-fun var62 () Real)
(declare-fun var63 () Real)
(declare-fun var64 () Real)
(declare-fun var65 () Real)
(declare-fun var66 () Real)
(declare-fun var67 () Real)
(declare-fun var68 () Real)
(declare-fun var69 () Real)
(declare-fun var70 () Real)
(declare-fun var71 () Real)
(declare-fun var72 () Real)
(declare-fun var73 () Real)
(declare-fun var74 () Real)
(declare-fun var75 () Real)
(declare-fun var76 () Real)
(declare-fun var77 () Real)
(declare-fun var78 () Real)
(declare-fun var79 () Real)
(declare-fun var80 () Real)
(declare-fun var81 () Real)
(declare-fun var82 () Real)
(declare-fun var83 () Real)
(declare-fun var84 () Real)
(declare-fun var85 () Real)
(declare-fun var86 () Real)
(declare-fun var87 () Real)
(declare-fun var88 () Real)
(declare-fun var89 () Real)
(declare-fun var90 () Real)
(declare-fun var91 () Real)
(declare-fun var92 () Real)
(declare-fun var93 () Real)
(declare-fun var94 () Real)
(declare-fun var95 () Real)
(declare-fun var96 () Real)
(declare-fun var97 () Real)
(declare-fun var98 () Real)
(declare-fun var99 () Real)
(declare-fun var100 () Real)
(declare-fun var101 () Real)
(declare-fun var102 () Real)
(declare-fun var103 () Real)
(declare-fun var104 () Real)
(declare-fun var105 () Real)
(declare-fun var106 () Real)
(declare-fun var107 () Real)
(assert (and
  (or 
    (> (* 1 var8  )  0 )
)
  (or 
    (> (* 1 var9  )  0 )
)
  (or 
    (> (* 1 var10  )  0 )
)
  (or 
    (> (* 1 var11  )  0 )
)
  (or 
    (> (+ (* 1 var0 var10  ) (* 1 var4 var11  ) (* (- 0 10) var8  ) (* 10 var9  ) ) 0 )
)
  (or 
    (< (+ (* 10 var8  ) (* (- 0 10) var9  ) ) 0 )
    (> (+ (* 1 var10  ) (* 1 var11  ) ) 0 )
)
  (or 
    (> (* 1 var12  )  0 )
)
  (or 
    (> (* 1 var13  )  0 )
)
  (or 
    (> (* 1 var14  )  0 )
)
  (or 
    (> (* 1 var15  )  0 )
)
  (or 
    (> (+ (* 1 var0 var14  ) (* 1 var6 var15  ) (* (- 0 10) var12  ) (* 10 var13  ) ) 0 )
)
  (or 
    (< (+ (* 10 var12  ) (* (- 0 10) var13  ) ) 0 )
    (> (+ (* 1 var14  ) (* 1 var15  ) ) 0 )
)
  (or 
    (> (* 1 var16  )  0 )
)
  (or 
    (> (* 1 var17  )  0 )
)
  (or 
    (> (* 1 var18  )  0 )
)
  (or 
    (> (* 1 var19  )  0 )
)
  (or 
    (> (+ (* 1 var2 var18  ) (* 1 var4 var19  ) (* (- 0 10) var16  ) (* 10 var17  ) ) 0 )
)
  (or 
    (< (+ (* 10 var16  ) (* (- 0 10) var17  ) ) 0 )
    (> (+ (* 1 var18  ) (* 1 var19  ) ) 0 )
)
  (or 
    (> (* 1 var20  )  0 )
)
  (or 
    (> (* 1 var21  )  0 )
)
  (or 
    (> (* 1 var22  )  0 )
)
  (or 
    (> (* 1 var23  )  0 )
)
  (or 
    (> (+ (* 1 var2 var22  ) (* 1 var6 var23  ) (* (- 0 10) var20  ) (* 10 var21  ) ) 0 )
)
  (or 
    (< (+ (* 10 var20  ) (* (- 0 10) var21  ) ) 0 )
    (> (+ (* 1 var22  ) (* 1 var23  ) ) 0 )
)
  (or 
    (> (* 1 var24  )  0 )
)
  (or 
    (> (* 1 var25  )  0 )
)
  (or 
    (> (* 1 var26  )  0 )
)
  (or 
    (> (* 1 var27  )  0 )
)
  (or 
    (> (* 1 var28  )  0 )
)
  (or 
    (> (* 1 var29  )  0 )
)
  (or 
    (> (* 1 var30  )  0 )
)
  (or 
    (> (* 1 var31  )  0 )
)
  (or 
    (> (+ (* 1 var0 var28  ) (* (- 0 1) var0 var30  ) (* (- 0 1) var2 var31  ) (* 1 var4 var29  ) (* (- 0 2) var24  ) (* 10 var25  ) (* 2 var26  ) (* (- 0 4294967295) var27  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var30  ) (* 1 var2 var31  ) (* 2 var24  ) (* (- 0 10) var25  ) (* (- 0 2) var26  ) (* 4294967295 var27  ) ) 0 )
    (> (+ (* 1 var28  ) (* 1 var29  ) ) 0 )
)
  (or 
    (> (* 1 var32  )  0 )
)
  (or 
    (> (* 1 var33  )  0 )
)
  (or 
    (> (* 1 var34  )  0 )
)
  (or 
    (> (* 1 var35  )  0 )
)
  (or 
    (> (* 1 var36  )  0 )
)
  (or 
    (> (* 1 var37  )  0 )
)
  (or 
    (> (* 1 var38  )  0 )
)
  (or 
    (> (* 1 var39  )  0 )
)
  (or 
    (> (+ (* 1 var0 var36  ) (* 1 var4 var37  ) (* (- 0 1) var4 var38  ) (* (- 0 1) var6 var39  ) (* (- 0 2) var32  ) (* 10 var33  ) (* 2 var34  ) (* (- 0 4294967295) var35  ) ) 0 )
)
  (or 
    (< (+ (* 1 var4 var38  ) (* 1 var6 var39  ) (* 2 var32  ) (* (- 0 10) var33  ) (* (- 0 2) var34  ) (* 4294967295 var35  ) ) 0 )
    (> (+ (* 1 var36  ) (* 1 var37  ) ) 0 )
)
  (or 
    (> (* 1 var40  )  0 )
)
  (or 
    (> (* 1 var41  )  0 )
)
  (or 
    (> (* 1 var42  )  0 )
)
  (or 
    (> (* 1 var43  )  0 )
)
  (or 
    (> (* 1 var44  )  0 )
)
  (or 
    (> (* 1 var45  )  0 )
)
  (or 
    (> (* 1 var46  )  0 )
)
  (or 
    (> (* 1 var47  )  0 )
)
  (or 
    (> (+ (* 1 var0 var44  ) (* (- 0 1) var0 var46  ) (* (- 0 1) var2 var47  ) (* 1 var6 var45  ) (* (- 0 2) var40  ) (* 10 var41  ) (* 2 var42  ) (* (- 0 4294967295) var43  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var46  ) (* 1 var2 var47  ) (* 2 var40  ) (* (- 0 10) var41  ) (* (- 0 2) var42  ) (* 4294967295 var43  ) ) 0 )
    (> (+ (* 1 var44  ) (* 1 var45  ) ) 0 )
)
  (or 
    (> (* 1 var48  )  0 )
)
  (or 
    (> (* 1 var49  )  0 )
)
  (or 
    (> (* 1 var50  )  0 )
)
  (or 
    (> (* 1 var51  )  0 )
)
  (or 
    (> (* 1 var52  )  0 )
)
  (or 
    (> (* 1 var53  )  0 )
)
  (or 
    (> (* 1 var54  )  0 )
)
  (or 
    (> (* 1 var55  )  0 )
)
  (or 
    (> (+ (* 1 var0 var52  ) (* (- 0 1) var4 var54  ) (* 1 var6 var53  ) (* (- 0 1) var6 var55  ) (* (- 0 2) var48  ) (* 10 var49  ) (* 2 var50  ) (* (- 0 4294967295) var51  ) ) 0 )
)
  (or 
    (< (+ (* 1 var4 var54  ) (* 1 var6 var55  ) (* 2 var48  ) (* (- 0 10) var49  ) (* (- 0 2) var50  ) (* 4294967295 var51  ) ) 0 )
    (> (+ (* 1 var52  ) (* 1 var53  ) ) 0 )
)
  (or 
    (> (* 1 var56  )  0 )
)
  (or 
    (> (* 1 var57  )  0 )
)
  (or 
    (> (* 1 var58  )  0 )
)
  (or 
    (> (* 1 var59  )  0 )
)
  (or 
    (> (* 1 var60  )  0 )
)
  (or 
    (> (* 1 var61  )  0 )
)
  (or 
    (> (* 1 var62  )  0 )
)
  (or 
    (> (* 1 var63  )  0 )
)
  (or 
    (< (+ (* 1 var0 var62  ) (* (- 0 1) var2 var60  ) (* 1 var2 var63  ) (* (- 0 1) var4 var61  ) (* 2 var56  ) (* (- 0 10) var57  ) (* (- 0 2) var58  ) (* 4294967295 var59  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var62  ) (* 1 var2 var63  ) (* 2 var56  ) (* (- 0 10) var57  ) (* (- 0 2) var58  ) (* 4294967295 var59  ) ) 0 )
    (> (+ (* 1 var60  ) (* 1 var61  ) ) 0 )
)
  (or 
    (> (* 1 var64  )  0 )
)
  (or 
    (> (* 1 var65  )  0 )
)
  (or 
    (> (* 1 var66  )  0 )
)
  (or 
    (> (* 1 var67  )  0 )
)
  (or 
    (> (* 1 var68  )  0 )
)
  (or 
    (> (* 1 var69  )  0 )
)
  (or 
    (> (* 1 var70  )  0 )
)
  (or 
    (> (* 1 var71  )  0 )
)
  (or 
    (> (+ (* 1 var2 var68  ) (* 1 var4 var69  ) (* (- 0 1) var4 var70  ) (* (- 0 1) var6 var71  ) (* (- 0 2) var64  ) (* 10 var65  ) (* 2 var66  ) (* (- 0 4294967295) var67  ) ) 0 )
)
  (or 
    (< (+ (* 1 var4 var70  ) (* 1 var6 var71  ) (* 2 var64  ) (* (- 0 10) var65  ) (* (- 0 2) var66  ) (* 4294967295 var67  ) ) 0 )
    (> (+ (* 1 var68  ) (* 1 var69  ) ) 0 )
)
  (or 
    (> (* 1 var72  )  0 )
)
  (or 
    (> (* 1 var73  )  0 )
)
  (or 
    (> (* 1 var74  )  0 )
)
  (or 
    (> (* 1 var75  )  0 )
)
  (or 
    (> (* 1 var76  )  0 )
)
  (or 
    (> (* 1 var77  )  0 )
)
  (or 
    (> (* 1 var78  )  0 )
)
  (or 
    (> (* 1 var79  )  0 )
)
  (or 
    (< (+ (* 1 var0 var78  ) (* (- 0 1) var2 var76  ) (* 1 var2 var79  ) (* (- 0 1) var6 var77  ) (* 2 var72  ) (* (- 0 10) var73  ) (* (- 0 2) var74  ) (* 4294967295 var75  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var78  ) (* 1 var2 var79  ) (* 2 var72  ) (* (- 0 10) var73  ) (* (- 0 2) var74  ) (* 4294967295 var75  ) ) 0 )
    (> (+ (* 1 var76  ) (* 1 var77  ) ) 0 )
)
  (or 
    (> (* 1 var80  )  0 )
)
  (or 
    (> (* 1 var81  )  0 )
)
  (or 
    (> (* 1 var82  )  0 )
)
  (or 
    (> (* 1 var83  )  0 )
)
  (or 
    (> (* 1 var84  )  0 )
)
  (or 
    (> (* 1 var85  )  0 )
)
  (or 
    (> (* 1 var86  )  0 )
)
  (or 
    (> (* 1 var87  )  0 )
)
  (or 
    (> (+ (* 1 var2 var84  ) (* (- 0 1) var4 var86  ) (* 1 var6 var85  ) (* (- 0 1) var6 var87  ) (* (- 0 2) var80  ) (* 10 var81  ) (* 2 var82  ) (* (- 0 4294967295) var83  ) ) 0 )
)
  (or 
    (< (+ (* 1 var4 var86  ) (* 1 var6 var87  ) (* 2 var80  ) (* (- 0 10) var81  ) (* (- 0 2) var82  ) (* 4294967295 var83  ) ) 0 )
    (> (+ (* 1 var84  ) (* 1 var85  ) ) 0 )
)
  (or 
    (> (* 1 var88  )  0 )
)
  (or 
    (> (* 1 var89  )  0 )
)
  (or 
    (> (* 1 var90  )  0 )
)
  (or 
    (> (* 1 var91  )  0 )
)
  (or 
    (> (* 1 var92  )  0 )
)
  (or 
    (> (* 1 var93  )  0 )
)
  (or 
    (> (* 1 var94  )  0 )
)
  (or 
    (> (* 1 var95  )  0 )
)
  (or 
    (> (* 1 var96  )  0 )
)
  (or 
    (> (* 1 var97  )  0 )
)
  (or 
    (< (+ (* 1 var0 var96  ) (* 1 var2 var97  ) (* 4294967305 var92  ) (* (- 0 4294967296) var95  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0 var96  ) (* 1 var2 var97  ) (* 4294967305 var92  ) (* (- 0 4294967296) var95  ) ) 0 )
)
  (or 
    (> (* 1 var98  )  0 )
)
  (or 
    (> (* 1 var99  )  0 )
)
  (or 
    (> (* 1 var100  )  0 )
)
  (or 
    (> (* 1 var101  )  0 )
)
  (or 
    (> (* 1 var102  )  0 )
)
  (or 
    (> (* 1 var103  )  0 )
)
  (or 
    (> (* 1 var104  )  0 )
)
  (or 
    (> (* 1 var105  )  0 )
)
  (or 
    (> (* 1 var106  )  0 )
)
  (or 
    (> (* 1 var107  )  0 )
)
  (or 
    (< (+ (* 1 var4 var106  ) (* 1 var6 var107  ) (* 4294967305 var102  ) (* (- 0 4294967296) var105  ) ) 0 )
)
  (or 
    (< (+ (* 1 var4 var106  ) (* 1 var6 var107  ) (* 4294967305 var102  ) (* (- 0 4294967296) var105  ) ) 0 )
)
))
(check-sat)
(exit)
