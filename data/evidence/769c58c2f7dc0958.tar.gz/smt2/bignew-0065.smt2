(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Chua/2/VC1/L/Chua-2-VC1-L-chunk-0055.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 400 var0  ) (* (- 0 441) var1  ) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (< (+ (* 400 var0  ) (* (- 0 441) var1  ) ) 0 )
)
  (or 
    (> (+ (* 400 var0  ) (* (- 0 441) var1  ) ) 0 )
    (< (+ (* 400 var0  ) (* (- 0 441) var1  ) ) 0 )
)
  (or 
    (< (* 1 var2  )  0 )
    (> (+ (* 21 var2  ) (- 0 1570) ) 0 )
    (> (* 1 var1  )  0 )
)
  (or 
    (< (* 1 var2  )  0 )
    (> (+ (* 21 var2  ) (- 0 1570) ) 0 )
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var2  ) (- 0 75) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
))
(check-sat)
(exit)
