(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sqrt/1mcosq/7/sqrt-1mcosq-7-chunk-0225.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 1 var1 var1 var1 var1  ) (* (- 0 12) var1 var1  ) 24 ) 0 )
)
  (or 
    (> (+ (* 5000000 var2  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10000000 var2  ) (- 0 31415927) ) 0 )
)
  (or 
    (< (+ (* 2 var0  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (> (+ (* 20 var1  ) (- 0 1) ) 0 )
)
  (or 
    (> (+ (* 1 var0  ) (* (- 0 1) var1  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (* (- 0 10) var1  ) ) 0 )
    (> (+ (* 1 var0  ) (* (- 0 10) var1  ) ) 0 )
    (< (* 1 var0  )  0 )
)
  (or 
    (> (+ (* 1 var0 var0  ) (- 0 2) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0  ) (* (- 0 30) var0 var0 var0 var0  ) (* 360 var0 var0  ) (- 0 720) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 90) var0 var0 var0 var0 var0 var0 var0 var0  ) (* 5040 var0 var0 var0 var0 var0 var0  ) (* (- 0 151200) var0 var0 var0 var0  ) (* 1814400 var0 var0  ) (- 0 3628800) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 132) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 11880 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 665280) var0 var0 var0 var0 var0 var0  ) (* 19958400 var0 var0 var0 var0  ) (* (- 0 239500800) var0 var0  ) 479001600 ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 182) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 24024 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 2162160) var0 var0 var0 var0 var0 var0 var0 var0  ) (* 121080960 var0 var0 var0 var0 var0 var0  ) (* (- 0 3632428800) var0 var0 var0 var0  ) (* 43589145600 var0 var0  ) (- 0 87178291200) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 240) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 43680 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 5765760) var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 518918400 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 29059430400) var0 var0 var0 var0 var0 var0  ) (* 871782912000 var0 var0 var0 var0  ) (* (- 0 10461394944000) var0 var0  ) 20922789888000 ) 0 )
)
))
(check-sat)
(exit)
