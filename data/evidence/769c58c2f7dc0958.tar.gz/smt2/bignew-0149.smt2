(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sin/problem/7/sin-problem-7-chunk-0339.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (> (* 1 var0 var0 var1  )  0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 110) var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* 110 var0 var1 var1 var1 var1 var1 var1 var1 var1  ) (* 7920 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 7920) var0 var1 var1 var1 var1 var1 var1  ) (* (- 0 332640) var0 var0 var0 var0 var0  ) (* 332640 var0 var1 var1 var1 var1  ) (* 6652800 var0 var0 var0  ) (* (- 0 6652800) var0 var1 var1  ) ) 0 )
)
  (or 
    (> (+ (* 1 var1 var1 var1 var1 var1 var1 var1 var1 var1  ) (* 72 var0 var0 var0 var0 var0 var0 var1  ) (* (- 0 72) var1 var1 var1 var1 var1 var1 var1  ) (* (- 0 3024) var0 var0 var0 var0 var1  ) (* 3024 var1 var1 var1 var1 var1  ) (* 60480 var0 var0 var1  ) (* (- 0 60480) var1 var1 var1  ) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 42) var0 var0 var0 var0 var0  ) (* 42 var0 var1 var1 var1 var1  ) (* 840 var0 var0 var0  ) (* (- 0 840) var0 var1 var1  ) ) 0 )
)
  (or 
    (> (+ (* 1 var1 var1 var1 var1 var1  ) (* 20 var0 var0 var1  ) (* (- 0 20) var1 var1 var1  ) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (+ (* 5000000 var2  ) (- 0 15707963) ) 0 )
)
  (or 
    (< (+ (* 10000000 var2  ) (- 0 31415927) ) 0 )
)
  (or 
    (< (+ (* 2 var1  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var0  ) (* (- 0 1) var1  ) ) 0 )
)
))
(check-sat)
(exit)
