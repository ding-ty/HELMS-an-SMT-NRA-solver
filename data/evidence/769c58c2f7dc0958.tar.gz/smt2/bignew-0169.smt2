(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/sqrt/problem/12vars3/sqrt-problem-12vars3-chunk-0104.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (> (+ (* 3 var0 var0 var0 var0 var0 var0 var0 var0 var0 var1  ) (* 3 var0 var0 var0 var0 var0 var0 var0 var0 var0 var2  ) (* 12 var0 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 60) var0 var0 var0 var0 var0 var0 var0 var0 var1  ) (* 60 var0 var0 var0 var0 var0 var0 var0 var0 var2  ) (* (- 0 96) var0 var0 var0 var0 var0 var0 var0 var1  ) (* (- 0 96) var0 var0 var0 var0 var0 var0 var0 var2  ) (* (- 0 384) var0 var0 var0 var0 var0 var0 var0  ) (* 912 var0 var0 var0 var0 var0 var0 var1  ) (* (- 0 912) var0 var0 var0 var0 var0 var0 var2  ) (* 480 var0 var0 var0 var0 var0 var1  ) (* 480 var0 var0 var0 var0 var0 var2  ) (* 1920 var0 var0 var0 var0 var0  ) (* (- 0 3552) var0 var0 var0 var0 var1  ) (* 3552 var0 var0 var0 var0 var2  ) (* (- 0 768) var0 var0 var0 var1  ) (* (- 0 768) var0 var0 var0 var2  ) (* (- 0 3072) var0 var0 var0  ) (* 4992 var0 var0 var1  ) (* (- 0 4992) var0 var0 var2  ) (* 384 var0 var1  ) (* 384 var0 var2  ) (* 1536 var0  ) (* (- 0 2304) var1  ) (* 2304 var2  ) ) 0 )
)
  (or 
    (> (+ (* 1 var0 var0 var0 var0 var0 var0 var0 var0  ) (* (- 0 32) var0 var0 var0 var0 var0 var0  ) (* 160 var0 var0 var0 var0  ) (* (- 0 256) var0 var0  ) 128 ) 0 )
)
  (or 
    (< (+ (* 3 var0 var0 var0 var1  ) (* 3 var0 var0 var0 var2  ) (* 12 var0 var0 var0  ) (* (- 0 24) var0 var0 var1  ) (* 24 var0 var0 var2  ) (* (- 0 6) var0 var1  ) (* (- 0 6) var0 var2  ) (* (- 0 24) var0  ) (* 36 var1  ) (* (- 0 36) var2  ) ) 0 )
)
  (or 
    (> (+ (* 6 var0 var0 var1  ) (* (- 0 6) var0 var0 var2  ) (* 3 var0 var1  ) (* 3 var0 var2  ) (* 12 var0  ) (* (- 0 18) var1  ) (* 18 var2  ) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 1) ) 0 )
)
))
(check-sat)
(exit)
