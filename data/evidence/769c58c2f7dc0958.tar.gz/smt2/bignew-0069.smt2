(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
meti-tarski/Chua/2/VC2/L/Chua-2-VC2-L-chunk-0058.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(assert (and
  (or 
    (< (+ (* 2499 var0 var0  ) (* (- 0 514500) var0  ) 38250000 ) 0 )
)
  (or 
    (> (+ (* 735 var0 var0 var1  ) (* (- 0 3724) var0 var0 var2  ) (* (- 0 157500) var0 var1  ) (* 798000 var0 var2  ) (* 11250000 var1  ) (* (- 0 57000000) var2  ) ) 0 )
)
  (or 
    (< (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 15 var1  ) (* (- 0 76) var2  ) ) 0 )
)
  (or 
    (< (+ (* 15 var1  ) (* (- 0 76) var2  ) ) 0 )
    (> (+ (* 15 var1  ) (* (- 0 76) var2  ) ) 0 )
)
  (or 
    (< (+ (* 1 var0  ) (- 0 75) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
))
(check-sat)
(exit)
