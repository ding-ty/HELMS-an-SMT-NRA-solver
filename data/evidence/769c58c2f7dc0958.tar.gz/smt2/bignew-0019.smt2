(set-info :smt-lib-version 2.6)
(set-logic QF_NRA)
(set-info :source |
20240407-pPDA-Chiari-Pontiggia-Winkler/certificate_hints/mod5_POMC_hints.smt2
|)
(set-info :category "random")
(set-info :status unknown)
(declare-fun var0 () Real)
(declare-fun var1 () Real)
(declare-fun var2 () Real)
(declare-fun var3 () Real)
(declare-fun var4 () Real)
(declare-fun var5 () Real)
(declare-fun var6 () Real)
(declare-fun var7 () Real)
(declare-fun var8 () Real)
(declare-fun var9 () Real)
(declare-fun var10 () Real)
(declare-fun var11 () Real)
(declare-fun var12 () Real)
(declare-fun var13 () Real)
(declare-fun var14 () Real)
(declare-fun var15 () Real)
(declare-fun var16 () Real)
(declare-fun var17 () Real)
(declare-fun var18 () Real)
(declare-fun var19 () Real)
(declare-fun var20 () Real)
(declare-fun var21 () Real)
(declare-fun var22 () Real)
(declare-fun var23 () Real)
(declare-fun var24 () Real)
(declare-fun var25 () Real)
(declare-fun var26 () Real)
(declare-fun var27 () Real)
(declare-fun var28 () Real)
(declare-fun var29 () Real)
(declare-fun var30 () Real)
(declare-fun var31 () Real)
(declare-fun var32 () Real)
(declare-fun var33 () Real)
(declare-fun var34 () Real)
(declare-fun var35 () Real)
(declare-fun var36 () Real)
(declare-fun var37 () Real)
(declare-fun var38 () Real)
(declare-fun var39 () Real)
(declare-fun var40 () Real)
(declare-fun var41 () Real)
(declare-fun var42 () Real)
(declare-fun var43 () Real)
(declare-fun var44 () Real)
(declare-fun var45 () Real)
(declare-fun var46 () Real)
(declare-fun var47 () Real)
(declare-fun var48 () Real)
(declare-fun var49 () Real)
(declare-fun var50 () Real)
(declare-fun var51 () Real)
(declare-fun var52 () Real)
(declare-fun var53 () Real)
(declare-fun var54 () Real)
(declare-fun var55 () Real)
(declare-fun var56 () Real)
(declare-fun var57 () Real)
(declare-fun var58 () Real)
(declare-fun var59 () Real)
(declare-fun var60 () Real)
(declare-fun var61 () Real)
(declare-fun var62 () Real)
(declare-fun var63 () Real)
(declare-fun var64 () Real)
(declare-fun var65 () Real)
(declare-fun var66 () Real)
(declare-fun var67 () Real)
(declare-fun var68 () Real)
(declare-fun var69 () Real)
(declare-fun var70 () Real)
(declare-fun var71 () Real)
(declare-fun var72 () Real)
(declare-fun var73 () Real)
(declare-fun var74 () Real)
(declare-fun var75 () Real)
(declare-fun var76 () Real)
(declare-fun var77 () Real)
(declare-fun var78 () Real)
(declare-fun var79 () Real)
(declare-fun var80 () Real)
(declare-fun var81 () Real)
(declare-fun var82 () Real)
(declare-fun var83 () Real)
(declare-fun var84 () Real)
(declare-fun var85 () Real)
(declare-fun var86 () Real)
(declare-fun var87 () Real)
(declare-fun var88 () Real)
(declare-fun var89 () Real)
(declare-fun var90 () Real)
(declare-fun var91 () Real)
(declare-fun var92 () Real)
(declare-fun var93 () Real)
(declare-fun var94 () Real)
(declare-fun var95 () Real)
(declare-fun var96 () Real)
(declare-fun var97 () Real)
(declare-fun var98 () Real)
(declare-fun var99 () Real)
(declare-fun var100 () Real)
(declare-fun var101 () Real)
(declare-fun var102 () Real)
(declare-fun var103 () Real)
(declare-fun var104 () Real)
(declare-fun var105 () Real)
(declare-fun var106 () Real)
(declare-fun var107 () Real)
(declare-fun var108 () Real)
(declare-fun var109 () Real)
(declare-fun var110 () Real)
(declare-fun var111 () Real)
(declare-fun var112 () Real)
(declare-fun var113 () Real)
(declare-fun var114 () Real)
(declare-fun var115 () Real)
(declare-fun var116 () Real)
(declare-fun var117 () Real)
(declare-fun var118 () Real)
(declare-fun var119 () Real)
(declare-fun var120 () Real)
(declare-fun var121 () Real)
(declare-fun var122 () Real)
(declare-fun var123 () Real)
(assert (and
  (or 
    (< (+ (* 1 var0  ) (* (- 0 3) var1  ) 2 ) 0 )
)
  (or 
    (> (* 1 var1  )  0 )
)
  (or 
    (< (+ (* 1 var1  ) (* (- 0 1) var2  ) ) 0 )
)
  (or 
    (> (* 1 var2  )  0 )
)
  (or 
    (< (+ (* 2 var3  ) (* 1 var4  ) (* (- 0 3) var5  ) ) 0 )
)
  (or 
    (> (* 1 var5  )  0 )
)
  (or 
    (< (+ (* 1 var5  ) (* (- 0 1) var6  ) ) 0 )
)
  (or 
    (> (* 1 var6  )  0 )
)
  (or 
    (< (+ (* 2 var7  ) (* 1 var8  ) (* (- 0 3) var9  ) ) 0 )
)
  (or 
    (> (* 1 var9  )  0 )
)
  (or 
    (< (+ (* 1 var9  ) (* (- 0 1) var10  ) ) 0 )
)
  (or 
    (> (* 1 var10  )  0 )
)
  (or 
    (< (+ (* 1 var10  ) (* (- 0 1) var11  ) ) 0 )
)
  (or 
    (> (* 1 var11  )  0 )
)
  (or 
    (< (+ (* 2 var12  ) (* 1 var13  ) (* (- 0 3) var14  ) ) 0 )
)
  (or 
    (> (* 1 var14  )  0 )
)
  (or 
    (< (+ (* 1 var14  ) (* (- 0 1) var15  ) ) 0 )
)
  (or 
    (> (* 1 var15  )  0 )
)
  (or 
    (< (+ (* 1 var15 var16  ) (* (- 0 1) var8  ) ) 0 )
)
  (or 
    (> (* 1 var8  )  0 )
)
  (or 
    (> (+ (* 3 var16  ) (* (- 0 2) var17  ) (* (- 0 1) var18  ) ) 0 )
)
  (or 
    (> (* 1 var16  )  0 )
)
  (or 
    (> (+ (* 1 var18  ) (* (- 0 1) var19  ) ) 0 )
)
  (or 
    (> (* 1 var18  )  0 )
)
  (or 
    (> (+ (* 1 var19  ) (* (- 0 1) var20  ) ) 0 )
)
  (or 
    (> (* 1 var19  )  0 )
)
  (or 
    (> (+ (* 3 var20  ) (* (- 0 2) var21  ) (* (- 0 1) var22  ) ) 0 )
)
  (or 
    (> (* 1 var20  )  0 )
)
  (or 
    (< (+ (* 1 var16 var23  ) (* (- 0 1) var22  ) ) 0 )
)
  (or 
    (> (* 1 var22  )  0 )
)
  (or 
    (> (+ (* 1 var23  ) (* (- 0 1) var24  ) ) 0 )
)
  (or 
    (> (* 1 var23  )  0 )
)
  (or 
    (> (+ (* 3 var24  ) (* (- 0 2) var25  ) (* (- 0 1) var26  ) ) 0 )
)
  (or 
    (> (* 1 var24  )  0 )
)
  (or 
    (< (+ (* 1 var27 var28  ) (* (- 0 1) var26  ) ) 0 )
)
  (or 
    (> (* 1 var26  )  0 )
)
  (or 
    (> (+ (* 3 var28  ) (* (- 0 2) var29  ) (* (- 0 1) var30  ) ) 0 )
)
  (or 
    (> (* 1 var28  )  0 )
)
  (or 
    (< (+ (* 1 var16 var31  ) (* (- 0 1) var30  ) ) 0 )
)
  (or 
    (> (* 1 var30  )  0 )
)
  (or 
    (> (+ (* 1 var31  ) (* (- 0 1) var32  ) ) 0 )
)
  (or 
    (> (* 1 var31  )  0 )
)
  (or 
    (> (+ (* 3 var32  ) (* (- 0 2) var33  ) (* (- 0 1) var34  ) ) 0 )
)
  (or 
    (> (* 1 var32  )  0 )
)
  (or 
    (< (+ (* 1 var28 var35  ) (* (- 0 1) var34  ) ) 0 )
)
  (or 
    (> (* 1 var34  )  0 )
)
  (or 
    (> (+ (* 1 var35  ) (* (- 0 1) var36  ) ) 0 )
)
  (or 
    (> (* 1 var35  )  0 )
)
  (or 
    (> (+ (* 3 var36  ) (* (- 0 1) var37  ) (- 0 2) ) 0 )
)
  (or 
    (> (* 1 var36  )  0 )
)
  (or 
    (> (+ (* 1 var37  ) (* (- 0 1) var38  ) ) 0 )
)
  (or 
    (> (* 1 var37  )  0 )
)
  (or 
    (< (+ (* 1 var39 var40  ) (* (- 0 1) var33  ) ) 0 )
)
  (or 
    (> (* 1 var33  )  0 )
)
  (or 
    (> (+ (* 3 var40  ) (* (- 0 1) var41  ) (- 0 2) ) 0 )
)
  (or 
    (> (* 1 var40  )  0 )
)
  (or 
    (< (+ (* 1 var38  ) (* (- 0 1) var41  ) ) 0 )
)
  (or 
    (> (* 1 var41  )  0 )
)
  (or 
    (> (+ (* 1 var39  ) (* (- 0 1) var42  ) ) 0 )
)
  (or 
    (> (* 1 var39  )  0 )
)
  (or 
    (< (+ (* 1 var37  ) (* (- 0 3) var42  ) 2 ) 0 )
)
  (or 
    (> (* 1 var42  )  0 )
)
  (or 
    (< (+ (* 1 var43 var44  ) (* (- 0 1) var29  ) ) 0 )
)
  (or 
    (> (* 1 var29  )  0 )
)
  (or 
    (> (+ (* 3 var44  ) (* (- 0 2) var45  ) (* (- 0 1) var46  ) ) 0 )
)
  (or 
    (> (* 1 var44  )  0 )
)
  (or 
    (< (+ (* 1 var28 var47  ) (* (- 0 1) var46  ) ) 0 )
)
  (or 
    (> (* 1 var46  )  0 )
)
  (or 
    (> (+ (* 1 var47  ) (* (- 0 1) var48  ) ) 0 )
)
  (or 
    (> (* 1 var47  )  0 )
)
  (or 
    (> (+ (* 3 var48  ) (* (- 0 1) var49  ) (- 0 2) ) 0 )
)
  (or 
    (> (* 1 var48  )  0 )
)
  (or 
    (< (+ (* 1 var38  ) (* (- 0 1) var49  ) ) 0 )
)
  (or 
    (> (* 1 var49  )  0 )
)
  (or 
    (< (+ (* 1 var40 var50  ) (* (- 0 1) var45  ) ) 0 )
)
  (or 
    (> (* 1 var45  )  0 )
)
  (or 
    (> (+ (* 1 var50  ) (* (- 0 1) var51  ) ) 0 )
)
  (or 
    (> (* 1 var50  )  0 )
)
  (or 
    (< (+ (* 1 var49  ) (* (- 0 3) var51  ) 2 ) 0 )
)
  (or 
    (> (* 1 var51  )  0 )
)
  (or 
    (> (+ (* 1 var43  ) (* (- 0 1) var52  ) ) 0 )
)
  (or 
    (> (* 1 var43  )  0 )
)
  (or 
    (< (+ (* 2 var33  ) (* 1 var34  ) (* (- 0 3) var52  ) ) 0 )
)
  (or 
    (> (* 1 var52  )  0 )
)
  (or 
    (> (+ (* 1 var27  ) (* (- 0 1) var53  ) ) 0 )
)
  (or 
    (> (* 1 var27  )  0 )
)
  (or 
    (> (+ (* 3 var53  ) (* (- 0 1) var54  ) (- 0 2) ) 0 )
)
  (or 
    (> (* 1 var53  )  0 )
)
  (or 
    (< (+ (* 1 var38  ) (* (- 0 1) var54  ) ) 0 )
)
  (or 
    (> (* 1 var54  )  0 )
)
  (or 
    (< (+ (* 1 var40 var55  ) (* (- 0 1) var25  ) ) 0 )
)
  (or 
    (> (* 1 var25  )  0 )
)
  (or 
    (> (+ (* 1 var55  ) (* (- 0 1) var56  ) ) 0 )
)
  (or 
    (> (* 1 var55  )  0 )
)
  (or 
    (< (+ (* 1 var54  ) (* (- 0 3) var56  ) 2 ) 0 )
)
  (or 
    (> (* 1 var56  )  0 )
)
  (or 
    (< (+ (* 1 var44 var57  ) (* (- 0 1) var21  ) ) 0 )
)
  (or 
    (> (* 1 var21  )  0 )
)
  (or 
    (> (+ (* 1 var57  ) (* (- 0 1) var58  ) ) 0 )
)
  (or 
    (> (* 1 var57  )  0 )
)
  (or 
    (< (+ (* 2 var25  ) (* 1 var26  ) (* (- 0 3) var58  ) ) 0 )
)
  (or 
    (> (* 1 var58  )  0 )
)
  (or 
    (< (+ (* 1 var59 var60  ) (* (- 0 1) var17  ) ) 0 )
)
  (or 
    (> (* 1 var17  )  0 )
)
  (or 
    (> (+ (* 3 var60  ) (* (- 0 2) var61  ) (* (- 0 1) var62  ) ) 0 )
)
  (or 
    (> (* 1 var60  )  0 )
)
  (or 
    (< (+ (* 1 var16 var63  ) (* (- 0 1) var62  ) ) 0 )
)
  (or 
    (> (* 1 var62  )  0 )
)
  (or 
    (> (+ (* 1 var63  ) (* (- 0 1) var64  ) ) 0 )
)
  (or 
    (> (* 1 var63  )  0 )
)
  (or 
    (> (+ (* 3 var64  ) (* (- 0 2) var65  ) (* (- 0 1) var66  ) ) 0 )
)
  (or 
    (> (* 1 var64  )  0 )
)
  (or 
    (< (+ (* 1 var28 var67  ) (* (- 0 1) var66  ) ) 0 )
)
  (or 
    (> (* 1 var66  )  0 )
)
  (or 
    (> (+ (* 1 var67  ) (* (- 0 1) var68  ) ) 0 )
)
  (or 
    (> (* 1 var67  )  0 )
)
  (or 
    (> (+ (* 3 var68  ) (* (- 0 1) var69  ) (- 0 2) ) 0 )
)
  (or 
    (> (* 1 var68  )  0 )
)
  (or 
    (< (+ (* 1 var38  ) (* (- 0 1) var69  ) ) 0 )
)
  (or 
    (> (* 1 var69  )  0 )
)
  (or 
    (< (+ (* 1 var40 var70  ) (* (- 0 1) var65  ) ) 0 )
)
  (or 
    (> (* 1 var65  )  0 )
)
  (or 
    (> (+ (* 1 var70  ) (* (- 0 1) var71  ) ) 0 )
)
  (or 
    (> (* 1 var70  )  0 )
)
  (or 
    (< (+ (* 1 var69  ) (* (- 0 3) var71  ) 2 ) 0 )
)
  (or 
    (> (* 1 var71  )  0 )
)
  (or 
    (< (+ (* 1 var44 var72  ) (* (- 0 1) var61  ) ) 0 )
)
  (or 
    (> (* 1 var61  )  0 )
)
  (or 
    (> (+ (* 1 var72  ) (* (- 0 1) var73  ) ) 0 )
)
  (or 
    (> (* 1 var72  )  0 )
)
  (or 
    (< (+ (* 2 var65  ) (* 1 var66  ) (* (- 0 3) var73  ) ) 0 )
)
  (or 
    (> (* 1 var73  )  0 )
)
  (or 
    (> (+ (* 1 var59  ) (* (- 0 1) var74  ) ) 0 )
)
  (or 
    (> (* 1 var59  )  0 )
)
  (or 
    (< (+ (* 2 var21  ) (* 1 var22  ) (* (- 0 3) var74  ) ) 0 )
)
  (or 
    (> (* 1 var74  )  0 )
)
  (or 
    (< (+ (* 1 var75  ) (* (- 0 3) var76  ) ) 0 )
)
  (or 
    (> (* 1 var76  )  0 )
)
  (or 
    (< (+ (* 1 var76  ) (* (- 0 1) var77  ) ) 0 )
)
  (or 
    (> (* 1 var77  )  0 )
)
  (or 
    (< (+ (* 1 var28 var77  ) (* (- 0 1) var13  ) ) 0 )
)
  (or 
    (> (* 1 var13  )  0 )
)
  (or 
    (> (* 1 var78  )  0 )
)
  (or 
    (> (* 1 var78  )  0 )
)
  (or 
    (< (+ (* 1 var78  ) (* (- 0 1) var79  ) ) 0 )
)
  (or 
    (> (* 1 var79  )  0 )
)
  (or 
    (< (+ (* 1 var40 var79  ) (* (- 0 1) var12  ) ) 0 )
)
  (or 
    (> (* 1 var12  )  0 )
)
  (or 
    (< (+ (* 2 var12  ) (* 1 var13  ) (* (- 0 3) var80  ) ) 0 )
)
  (or 
    (> (* 1 var80  )  0 )
)
  (or 
    (< (+ (* 1 var80  ) (* (- 0 1) var81  ) ) 0 )
)
  (or 
    (> (* 1 var81  )  0 )
)
  (or 
    (< (+ (* 1 var44 var81  ) (* (- 0 1) var7  ) ) 0 )
)
  (or 
    (> (* 1 var7  )  0 )
)
  (or 
    (< (+ (* 2 var7  ) (* 1 var8  ) (* (- 0 3) var82  ) ) 0 )
)
  (or 
    (> (* 1 var82  )  0 )
)
  (or 
    (< (+ (* 1 var82  ) (* (- 0 1) var83  ) ) 0 )
)
  (or 
    (> (* 1 var83  )  0 )
)
  (or 
    (< (+ (* 2 var84  ) (* 1 var85  ) (* (- 0 3) var86  ) ) 0 )
)
  (or 
    (> (* 1 var86  )  0 )
)
  (or 
    (< (+ (* 1 var86  ) (* (- 0 1) var87  ) ) 0 )
)
  (or 
    (> (* 1 var87  )  0 )
)
  (or 
    (< (+ (* 1 var16 var87  ) (* (- 0 1) var88  ) ) 0 )
)
  (or 
    (> (* 1 var88  )  0 )
)
  (or 
    (< (+ (* 1 var89  ) (* (- 0 3) var90  ) ) 0 )
)
  (or 
    (> (* 1 var90  )  0 )
)
  (or 
    (< (+ (* 1 var90  ) (* (- 0 1) var91  ) ) 0 )
)
  (or 
    (> (* 1 var91  )  0 )
)
  (or 
    (< (+ (* 1 var28 var91  ) (* (- 0 1) var85  ) ) 0 )
)
  (or 
    (> (* 1 var85  )  0 )
)
  (or 
    (> (* 1 var92  )  0 )
)
  (or 
    (> (* 1 var92  )  0 )
)
  (or 
    (< (+ (* 1 var92  ) (* (- 0 1) var93  ) ) 0 )
)
  (or 
    (> (* 1 var93  )  0 )
)
  (or 
    (< (+ (* 1 var40 var93  ) (* (- 0 1) var84  ) ) 0 )
)
  (or 
    (> (* 1 var84  )  0 )
)
  (or 
    (< (+ (* 2 var84  ) (* 1 var85  ) (* (- 0 3) var94  ) ) 0 )
)
  (or 
    (> (* 1 var94  )  0 )
)
  (or 
    (< (+ (* 1 var94  ) (* (- 0 1) var95  ) ) 0 )
)
  (or 
    (> (* 1 var95  )  0 )
)
  (or 
    (< (+ (* 1 var44 var95  ) (* (- 0 1) var96  ) ) 0 )
)
  (or 
    (> (* 1 var96  )  0 )
)
  (or 
    (< (+ (* 1 var88  ) (* 2 var96  ) (* (- 0 3) var97  ) ) 0 )
)
  (or 
    (> (* 1 var97  )  0 )
)
  (or 
    (< (+ (* 1 var60 var83  ) (* (- 0 1) var98  ) ) 0 )
)
  (or 
    (> (* 1 var98  )  0 )
)
  (or 
    (< (+ (* 1 var11  ) (* 2 var98  ) (* (- 0 3) var99  ) ) 0 )
)
  (or 
    (> (* 1 var99  )  0 )
)
  (or 
    (< (+ (* 1 var6 var16  ) (* (- 0 1) var100  ) ) 0 )
)
  (or 
    (> (* 1 var100  )  0 )
)
  (or 
    (< (+ (* 1 var101  ) (* (- 0 3) var102  ) ) 0 )
)
  (or 
    (> (* 1 var102  )  0 )
)
  (or 
    (< (+ (* 1 var102  ) (* (- 0 1) var103  ) ) 0 )
)
  (or 
    (> (* 1 var103  )  0 )
)
  (or 
    (< (+ (* 1 var28 var103  ) (* (- 0 1) var4  ) ) 0 )
)
  (or 
    (> (* 1 var4  )  0 )
)
  (or 
    (> (* 1 var104  )  0 )
)
  (or 
    (> (* 1 var104  )  0 )
)
  (or 
    (< (+ (* 1 var104  ) (* (- 0 1) var105  ) ) 0 )
)
  (or 
    (> (* 1 var105  )  0 )
)
  (or 
    (< (+ (* 1 var40 var105  ) (* (- 0 1) var3  ) ) 0 )
)
  (or 
    (> (* 1 var3  )  0 )
)
  (or 
    (< (+ (* 2 var3  ) (* 1 var4  ) (* (- 0 3) var106  ) ) 0 )
)
  (or 
    (> (* 1 var106  )  0 )
)
  (or 
    (< (+ (* 1 var106  ) (* (- 0 1) var107  ) ) 0 )
)
  (or 
    (> (* 1 var107  )  0 )
)
  (or 
    (< (+ (* 1 var108  ) (* (- 0 3) var109  ) ) 0 )
)
  (or 
    (> (* 1 var109  )  0 )
)
  (or 
    (< (+ (* 1 var109  ) (* (- 0 1) var110  ) ) 0 )
)
  (or 
    (> (* 1 var110  )  0 )
)
  (or 
    (< (+ (* 1 var28 var110  ) (* (- 0 1) var111  ) ) 0 )
)
  (or 
    (> (* 1 var111  )  0 )
)
  (or 
    (> (* 1 var112  )  0 )
)
  (or 
    (> (* 1 var112  )  0 )
)
  (or 
    (< (+ (* 1 var112  ) (* (- 0 1) var113  ) ) 0 )
)
  (or 
    (> (* 1 var113  )  0 )
)
  (or 
    (< (+ (* 1 var40 var113  ) (* (- 0 1) var114  ) ) 0 )
)
  (or 
    (> (* 1 var114  )  0 )
)
  (or 
    (< (+ (* 1 var111  ) (* 2 var114  ) (* (- 0 3) var115  ) ) 0 )
)
  (or 
    (> (* 1 var115  )  0 )
)
  (or 
    (< (+ (* 1 var44 var107  ) (* (- 0 1) var116  ) ) 0 )
)
  (or 
    (> (* 1 var116  )  0 )
)
  (or 
    (< (+ (* 1 var100  ) (* 2 var116  ) (* (- 0 3) var117  ) ) 0 )
)
  (or 
    (> (* 1 var117  )  0 )
)
  (or 
    (< (+ (* 1 var2 var28  ) (* (- 0 1) var118  ) ) 0 )
)
  (or 
    (> (* 1 var118  )  0 )
)
  (or 
    (> (+ (* 1 var0  ) (* (- 0 1) var38  ) ) 0 )
)
  (or 
    (> (* 1 var0  )  0 )
)
  (or 
    (< (+ (* 1 var0  ) (* (- 0 3) var119  ) 2 ) 0 )
)
  (or 
    (> (* 1 var119  )  0 )
)
  (or 
    (< (+ (* 1 var119  ) (* (- 0 1) var120  ) ) 0 )
)
  (or 
    (> (* 1 var120  )  0 )
)
  (or 
    (> (* 1 var122  )  0 )
)
  (or 
    (> (* 1 var122  )  0 )
)
  (or 
    (< (+ (* 1 var40 var120  ) (* (- 0 1) var123  ) ) 0 )
)
  (or 
    (> (* 1 var123  )  0 )
)
  (or 
    (> (+ (* 3 var38  ) (* (- 0 1) var118  ) (* (- 0 2) var123  ) ) 0 )
)
  (or 
    (> (* 1 var38  )  0 )
)
  (or 
    (> (+ (* 3209 var26  ) (- 0 563) ) 0 )
)
  (or 
    (< (+ (* 53838086144 var26  ) (- 0 9445575817) ) 0 )
)
  (or 
    (> (+ (* 20397 var56  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var56  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 6799 var57  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var57  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 6799 var69  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var69  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 20397 var68  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var68  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 20397 var27  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var27  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 20397 var48  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var48  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 6799 var49  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var49  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 8797 var16  ) (- 0 862) ) 0 )
)
  (or 
    (< (+ (* 147589169152 var16  ) (- 0 14461968989) ) 0 )
)
  (or 
    (> (+ (* 6799 var41  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var41  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 22283 var20  ) (- 0 4628) ) 0 )
)
  (or 
    (< (+ (* 373846704128 var20  ) (- 0 77644977931) ) 0 )
)
  (or 
    (> (+ (* 6799 var38  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var38  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 11413 var65  ) (- 0 8144) ) 0 )
)
  (or 
    (< (+ (* 191478366208 var65  ) (- 0 136633658517) ) 0 )
)
  (or 
    (> (+ (* 20397 var42  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var42  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 3209 var34  ) (- 0 563) ) 0 )
)
  (or 
    (< (+ (* 53838086144 var34  ) (- 0 9445575817) ) 0 )
)
  (or 
    (> (+ (* 6056 var62  ) (- 0 317) ) 0 )
)
  (or 
    (< (+ (* 12700352512 var62  ) (- 0 664797941) ) 0 )
)
  (or 
    (> (+ (* 6799 var43  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var43  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 6056 var22  ) (- 0 317) ) 0 )
)
  (or 
    (< (+ (* 12700352512 var22  ) (- 0 664797941) ) 0 )
)
  (or 
    (> (+ (* 11413 var45  ) (- 0 8144) ) 0 )
)
  (or 
    (< (+ (* 191478366208 var45  ) (- 0 136633658517) ) 0 )
)
  (or 
    (> (+ (* 20397 var40  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var40  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 6799 var32  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var32  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 22283 var19  ) (- 0 4628) ) 0 )
)
  (or 
    (< (+ (* 373846704128 var19  ) (- 0 77644977931) ) 0 )
)
  (or 
    (> (+ (* 20397 var119  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var119  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 8603 var61  ) (- 0 2455) ) 0 )
)
  (or 
    (< (+ (* 144334389248 var61  ) (- 0 41188073883) ) 0 )
)
  (or 
    (> (+ (* 6799 var58  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var58  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 3209 var66  ) (- 0 563) ) 0 )
)
  (or 
    (< (+ (* 53838086144 var66  ) (- 0 9445575817) ) 0 )
)
  (or 
    (> (+ (* 20397 var53  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var53  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 20938 var70  ) (- 0 17687) ) 0 )
)
  (or 
    (< (+ (* 175640674304 var70  ) (- 0 148369320165) ) 0 )
)
  (or 
    (> (+ (* 11413 var25  ) (- 0 8144) ) 0 )
)
  (or 
    (< (+ (* 191478366208 var25  ) (- 0 136633658517) ) 0 )
)
  (or 
    (> (+ (* 3209 var46  ) (- 0 563) ) 0 )
)
  (or 
    (< (+ (* 53838086144 var46  ) (- 0 9445575817) ) 0 )
)
  (or 
    (> (+ (* 20397 var1  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var1  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 20938 var50  ) (- 0 17687) ) 0 )
)
  (or 
    (< (+ (* 175640674304 var50  ) (- 0 148369320165) ) 0 )
)
  (or 
    (> (+ (* 6799 var63  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var63  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 8603 var21  ) (- 0 2455) ) 0 )
)
  (or 
    (< (+ (* 144334389248 var21  ) (- 0 41188073883) ) 0 )
)
  (or 
    (> (+ (* 22283 var59  ) (- 0 4628) ) 0 )
)
  (or 
    (< (+ (* 373846704128 var59  ) (- 0 77644977931) ) 0 )
)
  (or 
    (> (+ (* 9018 var17  ) (- 0 389) ) 0 )
)
  (or 
    (< (+ (* 75648466944 var17  ) (- 0 3263173021) ) 0 )
)
  (or 
    (> (+ (* 6799 var54  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var54  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 6799 var72  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var72  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 11413 var33  ) (- 0 8144) ) 0 )
)
  (or 
    (< (+ (* 191478366208 var33  ) (- 0 136633658517) ) 0 )
)
  (or 
    (> (+ (* 6799 var23  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var23  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 8603 var29  ) (- 0 2455) ) 0 )
)
  (or 
    (< (+ (* 144334389248 var29  ) (- 0 41188073883) ) 0 )
)
  (or 
    (> (+ (* 20397 var67  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var67  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 22153 var18  ) (- 0 4601) ) 0 )
)
  (or 
    (< (+ (* 371665666048 var18  ) (- 0 77191992969) ) 0 )
)
  (or 
    (> (+ (* 6799 var31  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var31  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 6799 var24  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var24  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 20397 var47  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var47  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 20397 var35  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var35  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 3209 var118  ) (- 0 563) ) 0 )
)
  (or 
    (< (+ (* 53838086144 var118  ) (- 0 9445575817) ) 0 )
)
  (or 
    (> (+ (* 6799 var37  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var37  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 20397 var51  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var51  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 20397 var55  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var55  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 6799 var73  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var73  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 6056 var30  ) (- 0 317) ) 0 )
)
  (or 
    (< (+ (* 12700352512 var30  ) (- 0 664797941) ) 0 )
)
  (or 
    (> (+ (* 11413 var123  ) (- 0 8144) ) 0 )
)
  (or 
    (< (+ (* 191478366208 var123  ) (- 0 136633658517) ) 0 )
)
  (or 
    (> (+ (* 20397 var39  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var39  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 20397 var120  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var120  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 6799 var44  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var44  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 20397 var2  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var2  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 22283 var74  ) (- 0 4628) ) 0 )
)
  (or 
    (< (+ (* 373846704128 var74  ) (- 0 77644977931) ) 0 )
)
  (or 
    (> (+ (* 22283 var60  ) (- 0 4628) ) 0 )
)
  (or 
    (< (+ (* 373846704128 var60  ) (- 0 77644977931) ) 0 )
)
  (or 
    (> (+ (* 20397 var71  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var71  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 6799 var0  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var0  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 6799 var52  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var52  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 20397 var36  ) (- 0 17230) ) 0 )
)
  (or 
    (< (+ (* 342204874752 var36  ) (- 0 289071452077) ) 0 )
)
  (or 
    (> (+ (* 6799 var64  ) (- 0 3632) ) 0 )
)
  (or 
    (< (+ (* 114068291584 var64  ) (- 0 60934855311) ) 0 )
)
  (or 
    (> (+ (* 22283 var28  ) (- 0 4628) ) 0 )
)
  (or 
    (< (+ (* 373846704128 var28  ) (- 0 77644977931) ) 0 )
)
))
(check-sat)
(exit)
